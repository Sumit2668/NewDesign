﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Foundation;
using GFDT.CustomViews;
using GFDT.iOS.Renderers;
using UIKit;
using Xamarin.Forms;
using Xamarin.Forms.Platform.iOS;

[assembly: ExportRenderer(typeof(BorderlessEntry), typeof(BorderlessEntryRenderer))]
namespace GFDT.iOS.Renderers
{
   public class BorderlessEntryRenderer:EntryRenderer
    {
        protected override void OnElementChanged(ElementChangedEventArgs<Entry> e)
        {
            base.OnElementChanged(e);
            if (Control != null)
            {
                this.Control.BorderStyle = UITextBorderStyle.None;
                this.Control.Layer.BorderColor = UIColor.Clear.CGColor;
                this.Control.Layer.CornerRadius = 0;
                this.Control.Layer.BorderWidth = new nfloat(0);
            }
        }
    }
}