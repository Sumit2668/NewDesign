﻿using GFDT.iOS.Renderers;
using UIKit;
using Xamarin.Forms;
using Xamarin.Forms.Platform.iOS;

[assembly: Xamarin.Forms.ExportRenderer(typeof(TabbedPage), typeof(TabRenderer))]
namespace GFDT.iOS.Renderers
{
    public class TabRenderer : TabbedRenderer
    {  
        public override void ViewWillAppear(bool animated)
        {
            base.ViewWillAppear(animated);
            if (true)
            {
                if (TabBar?.Items == null)
                    return;

                var tabs = Element as TabbedPage;

                if (tabs != null)
                {
                    
                    TabBar.Items[0].Image = UIImage.FromBundle("feed.png");
                    TabBar.Items[0].SelectedImage = UIImage.FromBundle("feed_select.png");
                    TabBar.UnselectedItemTintColor = Color.LightGray.ToUIColor();
                    
                    TabBar.Items[1].Image = UIImage.FromBundle("friend.png");
                    TabBar.Items[1].SelectedImage = UIImage.FromBundle("friend_select.png");
                    TabBar.UnselectedItemTintColor = Color.LightGray.ToUIColor();
                    TabBar.Items[3].Image = UIImage.FromBundle("wishlist.png");
                    TabBar.Items[3].SelectedImage = UIImage.FromBundle("wishlist_select.png");
                    TabBar.UnselectedItemTintColor = Color.LightGray.ToUIColor();
                    TabBar.Items[4].Image = UIImage.FromBundle("more.png");
                    TabBar.Items[4].SelectedImage = UIImage.FromBundle("more.png");

                    TabBar.UnselectedItemTintColor = Color.LightGray.ToUIColor();
                    var btn = new UIImageView(new CoreGraphics.CGRect((TabBar.Bounds.Width / 2) - 36, TabBar.Bounds.Y - 24, 72, 72));
                    btn.Image = UIImage.FromBundle("sendgft.png");
                    TabBar.AddSubview(btn);
                    UITapGestureRecognizer tapGestureRecognizer = new UITapGestureRecognizer((obj) =>
                    {
                        TabBar.SelectedItem = TabBar.Items[2];
                    });
                    btn.AddGestureRecognizer(tapGestureRecognizer);
                }
            }
        }
        protected override void Dispose(bool disposing)
        {
            base.Dispose(disposing);
            DismissViewController(true, () => Dispose(true));
        }
    }
}