﻿using System;
using GFDT.CustomViews;
using GFDT.iOS.Renderers;
using UIKit;
using Xamarin.Forms;
using Xamarin.Forms.Platform.iOS;

[assembly: ExportRenderer(typeof(CustomListView), typeof(CustomListViewRenderer))]
namespace GFDT.iOS.Renderers
{
    public class CustomListViewRenderer : ListViewRenderer
    {
        UITableView tableView;
        protected override void OnElementChanged(ElementChangedEventArgs<ListView> e)
        {
            base.OnElementChanged(e);
           if (e.NewElement != null)
            {
                tableView = (UITableView)Control;
                // tableView.SeparatorStyle = UITableViewCellSeparatorStyle.SingleLineEtched;
                tableView.SeparatorColor = UIColor.Clear;
                tableView.SeparatorStyle = UITableViewCellSeparatorStyle.None;
                // tableView.ContentInset = new UIEdgeInsets(20, 4, 40, 4);
                tableView.ScrollEnabled = true;
                //tableView.ScrollIndicatorInsets = new UIEdgeInsets(0, 0, 0, 0);
                //tableView.LayoutMargins = new UIEdgeInsets(20, 4, 40, 4); 

            }
        }
    }
}