using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using CoreGraphics;
using Foundation;
using GFDT.CustomViews;
using GFDT.iOS.Renderers;
using UIKit;
using Xamarin.Forms;
using Xamarin.Forms.Platform.iOS;

[assembly: ExportRenderer(typeof(RoundedEntry), typeof(RoundedEntryRenderer))]
namespace GFDT.iOS.Renderers
{


    public class RoundedEntryRenderer : EntryRenderer
    {
        IElementController ElementController => Element as IElementController;


        protected override void OnElementChanged(ElementChangedEventArgs<Entry> e)
        {
            base.OnElementChanged(e);

            if (e.NewElement != null)
            {
                var view = (RoundedEntry)Element;

                Control.KeyboardAppearance = UIKeyboardAppearance.Default;
                Control.ReturnKeyType = UIReturnKeyType.Done;
                Control.LeftView = new UIView(new CGRect(0f, 0f, 10f, 12f));
                Control.LeftViewMode = UITextFieldViewMode.Always;

                //Control.Layer.CornerRadius = Convert.ToSingle(view.CornerRadius);
                //Control.Layer.BorderColor = view.BorderColor.ToCGColor();
                //Control.Layer.BorderWidth = view.BorderWidth;

                Control.Layer.BorderColor = Color.LightGray.ToCGColor();
                Control.Layer.BorderWidth = 0.5f; 
                Control.Layer.CornerRadius = Convert.ToSingle(view.CornerRadius);


                Control.ClipsToBounds = true;
               // Control.BorderStyle = UITextBorderStyle.Line;
                if(!string.IsNullOrEmpty(view.LeftImage))
                {
                    Control.LeftView = new UIView(new CGRect(0f, 0f, 10f, 12f));
                    Control.LeftViewMode = UITextFieldViewMode.Always;

                    Control.LeftView=new UIImageView(UIImage.FromBundle(view.LeftImage));

                }
            }
        }
    }
}
