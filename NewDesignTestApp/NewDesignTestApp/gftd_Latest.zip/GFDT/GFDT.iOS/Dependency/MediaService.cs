﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using CoreFoundation;
using CoreGraphics;
using Foundation;
using GFDT.iOS.Dependency;
using GFDT.Services;
using QuickLook;
using SystemConfiguration;
using UIKit;
using Xamarin.Forms;

[assembly: Xamarin.Forms.Dependency(typeof(MediaService))]
namespace GFDT.iOS.Dependency
{
    public class MediaService : IMediaService
    {
        FileStream fs;
        private readonly string _rootDir = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.Personal), "pdfjs");

        public MediaService()
        {

        }
        public async Task<bool> CheckNewworkConnectivity()
        {
            return InternetConnectionStatus();
        }
        //public SQLiteConnection SQLiteConnection()
        //{
        //    var sqliteFilename = "dbField.db3";
        //    string documentsPath = Environment.GetFolderPath(Environment.SpecialFolder.Personal); // Documents folder
        //    string libraryPath = Path.Combine(documentsPath, "..", "Library"); // Library folder
        //    var path = Path.Combine(libraryPath, sqliteFilename);
        //    //var plat = new SQLite.Net.Platform.XamarinIOS.SQLitePlatformIOS();
        //    var conn = new SQLiteConnection(path);
        //    // Return the database connection 
        //    return conn;
        //}
        public string ViewMediaInPdf(byte[] fileStream, string fileName)
        {
            try
            {
                //UIDocumentInteractionController documentInteractionController=new UIDocumentInteractionController();
                var localFileStore = System.Environment.GetFolderPath(System.Environment.SpecialFolder.Personal);
                var externalPath = localFileStore + "/" + fileName + ".pdf";
                string newFilename = "File Not Found";
                if (fileStream != null)
                {
                    File.WriteAllBytes(externalPath, fileStream);
                    newFilename = fileName + ".pdf";
                }

                QLPreviewItemFileSystem prevItem = new QLPreviewItemFileSystem(newFilename, localFileStore + "/");
                Device.BeginInvokeOnMainThread(() =>
                {
                    QLPreviewController previewController = new QLPreviewController();
                    previewController.DataSource = new PreviewControllerDS(prevItem);
                    UIApplication.SharedApplication.KeyWindow.RootViewController.PresentViewController(previewController, true, null);
                });

                return (externalPath);
            }
            catch (Exception ex)
            {
                return string.Empty;
            }

        }
        public byte[] GetMediaInBytes(string filePath)
        {
            return File.ReadAllBytes(filePath);
        }


        public async Task<string> SaveFileToDisk(Stream stream, string fileName)
        {
            if (!Directory.Exists(_rootDir))
                Directory.CreateDirectory(_rootDir);

            var filePath = Path.Combine(_rootDir, fileName);

            using (var memoryStream = new MemoryStream())
            {
                await stream.CopyToAsync(memoryStream);
                File.WriteAllBytes(filePath, memoryStream.ToArray());
            }

            return filePath;
        }
        public string ViewMediaInPNG(byte[] fileStream, string fileName)
        {
            try
            {
                //UIDocumentInteractionController documentInteractionController=new UIDocumentInteractionController();
                var localFileStore = System.Environment.GetFolderPath(System.Environment.SpecialFolder.Personal);
                var externalPath = localFileStore + "/" + fileName + ".png";
                string newFilename = "File Not Found";
                if (fileStream != null)
                {
                    File.WriteAllBytes(externalPath, fileStream);
                    newFilename = fileName + ".png";
                }

                QLPreviewItemFileSystem prevItem = new QLPreviewItemFileSystem(newFilename, localFileStore + "/");
                Device.BeginInvokeOnMainThread(() =>
                {
                    QLPreviewController previewController = new QLPreviewController();
                    previewController.DataSource = new PreviewControllerDS(prevItem);
                    UIApplication.SharedApplication.KeyWindow.RootViewController.PresentViewController(previewController, true, null);
                });

                return (externalPath);
            }
            catch (Exception ex)
            {
                return string.Empty;
            }
        }
        public byte[] ResizeImage(byte[] imageStream, float width, float height)
        {
            UIImage originalImage = ImageFromByteArray(imageStream);
            //create a 24bit RGB image
            using (CGBitmapContext context = new CGBitmapContext(IntPtr.Zero,
                (int)width, (int)height, 8,
                (int)(4 * width), CGColorSpace.CreateDeviceRGB(),
                CGImageAlphaInfo.PremultipliedFirst))
            {
                CGImage imgRef = originalImage.CGImage;
                float wd = imgRef.Width;
                float ht = imgRef.Height;
                CGAffineTransform transform = CGAffineTransform.MakeIdentity();
                RectangleF bounds = new RectangleF(0, 0, wd, ht);

                float scaleRatio = bounds.Size.Width / wd;
                SizeF imageSize = new SizeF(imgRef.Width, imgRef.Height);
                UIImageOrientation orient = originalImage.Orientation;
                float boundHeight;

                switch (orient)
                {
                    case UIImageOrientation.Up:                                        //EXIF = 
                        transform = CGAffineTransform.MakeIdentity();
                        break;
                    // TODO: Add other Orientation
                    case UIImageOrientation.Right:                                     //EXIF = 
                        boundHeight = bounds.Size.Height;
                        bounds.Size = new SizeF(boundHeight, bounds.Size.Width);
                        transform = CGAffineTransform.MakeTranslation(imageSize.Height, 0);
                        transform = CGAffineTransform.Rotate(transform, (float)Math.PI / 2.0f);
                        break;
                    case UIImageOrientation.Down:                                      //EXIF = 
                        boundHeight = bounds.Size.Height;
                        bounds.Size = new SizeF(boundHeight, bounds.Size.Width);
                        transform = CGAffineTransform.MakeTranslation(imageSize.Height, imageSize.Height);
                        transform = CGAffineTransform.Rotate(transform, (float)Math.PI);
                        break;
                    default:
                        break;
                }

                UIGraphics.BeginImageContext(bounds.Size);

                CGContext ctx = UIGraphics.GetCurrentContext();

                if (orient == UIImageOrientation.Right || orient == UIImageOrientation.Left)
                {
                    ctx.ScaleCTM(-scaleRatio, scaleRatio);
                    ctx.TranslateCTM(-ht, 0);
                }
                else
                {
                    ctx.ScaleCTM(scaleRatio, -scaleRatio);
                    ctx.TranslateCTM(0, -ht);
                }

                ctx.ConcatCTM(transform);

                ctx.DrawImage(new RectangleF(0, 0, wd, ht), imgRef);
                UIImage imageCopy = UIGraphics.GetImageFromCurrentImageContext();
                UIGraphics.EndImageContext();

                RectangleF imageRect = new RectangleF(0, 0, width, height);

                // draw the image
                context.DrawImage(imageRect, imageCopy.CGImage);

                UIKit.UIImage resizedImage = UIKit.UIImage.FromImage(context.ToImage());

                // save the image as a jpeg
                return resizedImage.AsJPEG().ToArray();
            }
        }
        public static UIKit.UIImage ImageFromByteArray(byte[] data)
        {
            if (data == null)
            {
                return null;
            }

            UIKit.UIImage image;
            try
            {
                image = new UIKit.UIImage(Foundation.NSData.FromArray(data));
            }
            catch (Exception e)
            {
                Console.WriteLine("Image load failed: " + e.Message);
                return null;
            }
            return image;
        }

        #region Network Connectivity


        private event EventHandler ReachabilityChanged;
        private void OnChange(NetworkReachabilityFlags flags)
        {
            var h = ReachabilityChanged;
            if (h != null)
                h(null, EventArgs.Empty);
        }

        private NetworkReachability defaultRouteReachability;
        private bool IsNetworkAvailable(out NetworkReachabilityFlags flags)
        {
            if (defaultRouteReachability == null)
            {
                defaultRouteReachability = new NetworkReachability(new IPAddress(0));

                //defaultRouteReachability.SetCallback(OnChange);
                defaultRouteReachability.Schedule(CFRunLoop.Current, CFRunLoop.ModeDefault);
            }
            if (!defaultRouteReachability.TryGetFlags(out flags))
                return false;
            return IsReachableWithoutRequiringConnection(flags);
        }

        private NetworkReachability adHocWiFiNetworkReachability;
        private bool IsAdHocWiFiNetworkAvailable(out NetworkReachabilityFlags flags)
        {
            if (adHocWiFiNetworkReachability == null)
            {
                adHocWiFiNetworkReachability = new NetworkReachability(new IPAddress(new byte[] { 169, 254, 0, 0 }));
                //adHocWiFiNetworkReachability.SetCallback(OnChange);
                adHocWiFiNetworkReachability.Schedule(CFRunLoop.Current, CFRunLoop.ModeDefault);
            }

            if (!adHocWiFiNetworkReachability.TryGetFlags(out flags))
                return false;

            return IsReachableWithoutRequiringConnection(flags);
        }

        public static bool IsReachableWithoutRequiringConnection(NetworkReachabilityFlags flags)
        {
            // Is it reachable with the current network configuration?
            bool isReachable = (flags & NetworkReachabilityFlags.Reachable) != 0;

            // Do we need a connection to reach it?
            bool noConnectionRequired = (flags & NetworkReachabilityFlags.ConnectionRequired) == 0;

            // Since the network stack will automatically try to get the WAN up,
            // probe that
            if ((flags & NetworkReachabilityFlags.IsWWAN) != 0)
                noConnectionRequired = true;

            return isReachable && noConnectionRequired;
        }

        private bool InternetConnectionStatus()
        {
            NetworkReachabilityFlags flags;
            bool defaultNetworkAvailable = IsNetworkAvailable(out flags);
            if (defaultNetworkAvailable && ((flags & NetworkReachabilityFlags.IsDirect) != 0))
            {
                return false;
            }
            else if ((flags & NetworkReachabilityFlags.IsWWAN) != 0)
            {
                return true;
            }
            else if (flags == 0)
            {
                return false;
            }

            return true;
        }

        private bool LocalWifiConnectionStatus()
        {
            NetworkReachabilityFlags flags;
            if (IsAdHocWiFiNetworkAvailable(out flags))
            {
                if ((flags & NetworkReachabilityFlags.IsDirect) != 0)
                    return true;
            }
            return false;
        }
        #endregion
    }

    public class PreviewControllerDS : QLPreviewControllerDataSource
    {
        private QLPreviewItem _item;

        public PreviewControllerDS(QLPreviewItem item)
        {
            _item = item;
        }

        public override nint PreviewItemCount(QLPreviewController controller)
        {
            return 1;
        }

        public override IQLPreviewItem GetPreviewItem(QLPreviewController controller, nint index)
        {
            return _item;
        }


    }

    public class QLPreviewItemFileSystem : QLPreviewItem
    {
        string _fileName, _filePath;

        public QLPreviewItemFileSystem(string fileName, string filePath)
        {
            _fileName = fileName;
            _filePath = filePath;
        }

        public override string ItemTitle
        {
            get
            {
                return _fileName;
            }
        }
        public override NSUrl ItemUrl
        {
            get
            {
                return NSUrl.FromFilename(_filePath + "" + _fileName);
            }
        }
    }

    public class QLPreviewItemBundle : QLPreviewItem
    {
        string _fileName, _filePath;
        public QLPreviewItemBundle(string fileName, string filePath)
        {
            _fileName = fileName;
            _filePath = filePath;
        }

        public override string ItemTitle
        {
            get
            {
                return _fileName;
            }
        }
        public override NSUrl ItemUrl
        {
            get
            {
                var documents = NSBundle.MainBundle.BundlePath;
                var lib = Path.Combine(documents, _filePath);
                var url = NSUrl.FromFilename(lib);
                return url;
            }
        }
    }
}