﻿using System;
using System.IO;
using GFDT.iOS.Dependency;
using SQLite;

[assembly:Xamarin.Forms.Dependency(typeof(Database))]
namespace GFDT.iOS.Dependency
{
    public class Database:Services.IDatabase
    {
        public Database()
        {
        }

        public SQLiteConnection SQLiteConnection()
        {
            string sqlfile = "gfdt.db3";
string doc =  Environment.GetFolderPath(Environment.SpecialFolder.Personal);
            string libPath = Path.Combine(doc, "..", "Library");
            string path = Path.Combine(libPath, sqlfile);
            var conn = new SQLite.SQLiteConnection(path);

            return conn;
        }
    }
}
