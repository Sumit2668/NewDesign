﻿using GFDT.Views;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Xamarin.Forms;
using Xamarin.Forms.PlatformConfiguration.AndroidSpecific;
using Xamarin.Forms.Xaml;

namespace GFDT.CustomControls
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class ButtomTab : Xamarin.Forms.TabbedPage
    {
        public ButtomTab()
        {
            InitializeComponent();

            //var tab = new Xamarin.Forms.TabbedPage();
            //tab.Children.Add(new NavigationPage(new ContentPage() { Content = new Label { Text = "One" } }) { Title = "Tab 1" });
            //tab.Children.Add(new NavigationPage(new ContentPage() { Content = new Label { Text = "Two" } }) { Title = "Tab 2" });
            //tab.Children.Add(new NavigationPage(new ContentPage() { Content = new Label { Text = "Three" } }) { Title = "Tab 3" });



            this.Children.Add(new NavigationPage(new ContentPage() { Content = new Label { Text = "One" }, }) { Title = "Feed", Icon = "feed.png" });
            this.Children.Add(new NavigationPage(new ContentPage() { Content = new Label { Text = "Two" } }) { Title = "Friends", Icon = "friend.png" });
            this.Children.Add(new NavigationPage(new SendAGFTView() ) { Title = "Send a Gift", Icon = "sendgft.png" });
            this.Children.Add(new NavigationPage(new ContentPage() { Content = new Label { Text = "Four" } }) { Title = "My Wish List", Icon = "wishlist_select.png" });
            this.Children.Add(new NavigationPage(new ContentPage() { Content = new Label { Text = "Five" } }) { Title = "More", Icon = "more.png" });
            On<Xamarin.Forms.PlatformConfiguration.Android>().SetToolbarPlacement(ToolbarPlacement.Bottom);
            BarBackgroundColor =Color.WhiteSmoke;
            BarTextColor = Color.FromHex("#0080B1");
            NavigationPage.SetHasNavigationBar(this, false);
        }
    }
}