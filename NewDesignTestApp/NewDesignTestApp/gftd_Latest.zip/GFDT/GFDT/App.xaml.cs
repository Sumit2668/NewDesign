﻿using CommonServiceLocator;
using GalaSoft.MvvmLight.Ioc;
using GFDT.Models;
using GFDT.Services;
using GFTD.ViewModel;
using Plugin.FirebasePushNotification;
using Xamarin.Forms;

namespace GFDT
{
    public partial class App : Application
    {
        public static string Devicetoken = "cOA9jx7_cTI:APA91bGlBW3nrKPGVjffsG06dLu3zjmEIZ4kU-IYiY1BW1tU2jx83rsCPS9juKx6IqgnwsUArKl1A7IS1u4aEoA4rr0rTekEukuYGeOQWidpItOwmCq9P1V0-8bm6_wbkVfLagvZ-8KB"; //string.Empty;
        public static string MyAccesstoken = "MTMyMTU0NTYxMA==";
        public static CurrentUser CurrentUser { get; set; }

        private static LocalDatabase localDatabase;
        public static LocalDatabase LocalDatabase;

        #region Set App Properties
        private static ViewModelLocator locator { get; set; }
        public static ViewModelLocator Locator => locator;
        public static NavigationPage FeedNavigationPage;
        public static NavigationPage FriendNavigationPage;

        public static NavigationPage SendGiftNavigationPage;

       // public static NavigationPage MyWishNavigationPage;

        public static Page MoreNavigationPage;


        public static Views.HomeTabbedView MainTabbedPage;
        public static string UserId;
        public static string UserAccessToken;


        #endregion
        public App()
        {
            InitializeComponent();
            // localDatabase = new LocalDatabase();
            // CurrentUser = localDatabase?.GetCurrentUser();
            ServiceLocator.SetLocatorProvider(() => SimpleIoc.Default);
            SimpleIoc.Default.Register<ViewModelLocator>();
            locator = ServiceLocator.Current.GetInstance<ViewModelLocator>();
            FeedNavigationPage = new NavigationPage(new Views.FeedView());
            FriendNavigationPage = new NavigationPage(new Views.FriendsView());
            SendGiftNavigationPage = new NavigationPage(new Views.SendAGFTView());
           // MyWishNavigationPage = new NavigationPage(new Views.MyWishesView());
            MoreNavigationPage = new Views.MoreView();

            ////this is for generate token for notification
            //CrossFirebasePushNotification.Current.OnTokenRefresh += (s, p) =>
            //{
            //    System.Diagnostics.Debug.WriteLine($"TOKEN : {p.Token}");
            //    if (p.Token != null)
            //    {
            //        Devicetoken = p.Token;
            //    }
            //};
            //CrossFirebasePushNotification.Current.OnNotificationReceived += (s, p) =>
            //{
            //    System.Diagnostics.Debug.WriteLine("Received");
            //    var model = p.Data.Values;
            //    if (model == null) return;

            //    //  App.AppInSetup.HomeViewModel.NotificationsCountCommand.Execute(null);
            //};
            //CrossFirebasePushNotification.Current.OnNotificationOpened += (s, p) =>
            //{
            //    System.Diagnostics.Debug.WriteLine("Opened");
            //    // App.AppInSetup.HomeViewModel.NotificationsCommand.Execute(null);
            //    foreach (var data in p.Data)
            //    {
            //        System.Diagnostics.Debug.WriteLine($"{data.Key} : {data.Value}");
            //    }

            //    if (!string.IsNullOrEmpty(p.Identifier))
            //    {
            //        System.Diagnostics.Debug.WriteLine($"ActionId: {p.Identifier}");
            //    }
            //};
            var login = Xamarin.Essentials.Preferences.Get("IsLogin", false);
            //MainPage = new ItemDetailsView(); //new NavigationPage(new Views.OTPVerficationView());
            if (login)
            {
                //locator.LoginViewModel.LogOutCommand.Execute(null);
                App.MyAccesstoken = Xamarin.Essentials.Preferences.Get("MyAccesstoken", App.MyAccesstoken);
                Locator.LoginViewModel.GetDataOnLoad(null);
                MainPage = new Views.HomeView();// new NavigationPage(new Views.SignupView());
            }
            else
            {
                //MainPage = new Views.LoginView();
                MainPage = new NavigationPage(new Views.LoginView());
            }

        }

        protected override void OnStart()
        {
            // Handle when your app starts
        }

        protected override void OnSleep()
        {
            // Handle when your app sleeps
        }

        protected override void OnResume()
        {
            // Handle when your app resumes
        }
    }
}
