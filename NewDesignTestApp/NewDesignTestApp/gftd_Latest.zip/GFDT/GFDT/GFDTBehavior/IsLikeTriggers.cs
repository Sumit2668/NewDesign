﻿using System;
using System.Collections.Generic;
using System.Text;
using Xamarin.Forms;

namespace GFDT.GFDTBehavior
{
   public class IsLikeTriggers : Behavior<View>
    {
        protected async override void OnAttachedTo(View bindable)
        {
            base.OnAttachedTo(bindable);
            await bindable.ScaleTo(0.95, 50, Easing.CubicOut);
            await bindable.ScaleTo(1, 50, Easing.CubicIn);
            /*
              protected async override void Invoke(ImageButton button)
        {
            Xamarin.Forms.ImageButton img = (Xamarin.Forms.ImageButton)button;
            Xamarin.Forms.FileImageSource objFileImageSource = (Xamarin.Forms.FileImageSource)img.Source;
            if (objFileImageSource.File == "yes.png")
            {
                button.Source = "no.png";
            }
            else
            {
                button.Source = "yes.png";
            }
        }*/
        }
    }
}
