﻿using SQLite;
using System;
using System.Collections.Generic;
using System.Linq;
using Xamarin.Forms;
using GFDT.Services;
using GFDT.Models;

namespace GFDT.Services
{
    public class LocalDatabase
    {
        static object locker = new object();

        SQLiteConnection Connection;
        public LocalDatabase()
        {
            Connection = DependencyService.Get<IDatabase>().SQLiteConnection();
            Connection.CreateTable<CurrentUser>();           
        }

        #region User
        public IEnumerable<CurrentUser> GetAllCurrentUser()
        {
            lock (locker)
            {
                return (from i in Connection.Table<CurrentUser>() select i).ToList();
            }
        }
        public CurrentUser GetCurrentUser()
        {
            lock (locker)
            {
                return Connection.Table<CurrentUser>().FirstOrDefault();
            }
        }
        public int SaveCurrentUser(CurrentUser user)
        {
            lock (locker)
            {
                if (GetCurrentUser() != null)
                {
                    Connection.Update(user);
                    return 1;
                }
                else
                {
                    return Connection.Insert(user);
                }
            }
            return 0;
        }
        public int DeleteItem(Guid id)
        {
            lock (locker)
            {
                return Connection.Delete<CurrentUser>(id);
            }
        }
        #endregion
    }
}

