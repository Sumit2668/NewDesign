﻿using GFDT.Models;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace GFDT.Services
{
   public interface ISqliteService
    {
        Task<CurrentUser> GetCurrentUser();
        Task SaveCurrentUser(CurrentUser user);
        Task Remove(CurrentUser item);
    }
}
