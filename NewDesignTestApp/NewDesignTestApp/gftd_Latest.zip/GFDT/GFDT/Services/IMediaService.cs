﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using System.Threading.Tasks;

namespace GFDT.Services
{
    public interface IMediaService
    {
        //SQLiteConnection SQLiteConnection();
        Task<bool> CheckNewworkConnectivity();
        string ViewMediaInPdf(byte[] fileStream, string fileName);
        byte[] GetMediaInBytes(string filePath);
        string ViewMediaInPNG(byte[] fileStream, string fileName);
        byte[] ResizeImage(byte[] imageStream, float width, float height);
        Task<string> SaveFileToDisk(Stream stream, string fileName);

    }
}