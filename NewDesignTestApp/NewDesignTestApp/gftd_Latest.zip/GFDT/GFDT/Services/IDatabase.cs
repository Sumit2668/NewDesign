﻿using System;
namespace GFDT.Services
{
    public interface IDatabase
    {
        SQLite.SQLiteConnection SQLiteConnection();
    }
}
