﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using GFDT.Models;
using SQLite;
using Xamarin.Forms;

namespace GFDT.Services
{
    public class SqliteService : ISqliteService
    {
        private SQLiteAsyncConnection _sqlCon;
        #region Constructor
        public SqliteService()
        {
            var databasePath = DependencyService.Get<IPathService>().GetDatabasePath();
            _sqlCon = new SQLiteAsyncConnection(databasePath);

            CreateDatabaseAsync();
        }
        #endregion

        public async void CreateDatabaseAsync()
        {
            _sqlCon.CreateTableAsync<CurrentUser>(CreateFlags.None).ConfigureAwait(false);
         
        }

        public async Task<CurrentUser> GetCurrentUser()
        {

            return await _sqlCon.Table<CurrentUser>().FirstOrDefaultAsync();
        }


        public async Task SaveCurrentUser(Models.CurrentUser user)
        {
            await _sqlCon.InsertOrReplaceAsync(user);
        }
        public async Task Remove(CurrentUser item)
        {
            await _sqlCon.DeleteAsync(item);
        }

    }
}
