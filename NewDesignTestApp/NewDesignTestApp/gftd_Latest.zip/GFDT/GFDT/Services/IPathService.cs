﻿using System;
using System.Collections.Generic;
using System.Text;

namespace GFDT.Services
{
    public interface IPathService
    {
        string GetDatabasePath();
    }
}
