﻿using System;
using System.Collections.Generic;

using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace GFDT
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class AppStyle : ResourceDictionary
    {
        public AppStyle()
        {
            InitializeComponent();
        }
    }
}
