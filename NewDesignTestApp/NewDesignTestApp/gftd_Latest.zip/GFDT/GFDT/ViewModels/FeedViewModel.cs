﻿using Acr.UserDialogs;
using GFDT.Models.Response;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;

namespace GFDT.ViewModels
{
    public class FeedViewModel : BaseViewModel
    {
        public FeedViewModel()
        {
            //FeedModelList = new ObservableCollection<ViewModels.FeedModel>();
            //FeedModelList.Add(new FeedModel { Image="i1", Title = "You GFTD Ice Cream Sandwich to Nancy" , Role="Public" , Date="15/03/2019"});
            //FeedModelList.Add(new FeedModel { Image = "i2", Title = "You GFTD Ice Cream Sandwich to David", Role = "Private", Date = "15/03/2019" });
            //FeedModelList.Add(new FeedModel { Image = "i1", Title = "Andrew GFTD Ice Cream Sandwich to You", Role = "Public", Date = "15/03/2019" });
            //FeedModelList.Add(new FeedModel { Image = "i2", Title = "You GFTD Ice Cream Sandwich to Pinky", Role = "Public", Date = "15/03/2019" });
            //FeedModelList.Add(new FeedModel { Image = "i1", Title = "John GFTD Ice Cream Sandwich to You", Role = "Private", Date = "15/03/2019" });
           // GetFeedCollection();
        }
        private ObservableCollection<GetFeedData> feedmodellist;
        public ObservableCollection<GetFeedData> FeedModelList
        {
            get => feedmodellist;
            set
            {
                feedmodellist = value;
                RaisePropertyChanged(() => FeedModelList);
            }
        } 


        #region Methods 
        public void GetFeedCollection()
        {
            try
            {
                userManager.GetFeedResponseList(() =>
                    {
                        var getfeeddata = userManager.GetFeedResponse;
                        FeedModelList = new ObservableCollection<GetFeedData>(getfeeddata.data);
                        UserDialogs.Instance.HideLoading();
                    },
                (failure) =>
                {
                    UserDialogs.Instance.HideLoading();
                });
            }
            catch (Exception ex)
            {

            }
        }

        #endregion
    }

}
