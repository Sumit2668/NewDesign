using Acr.UserDialogs;
using GFDT.Models.Request;
using System;
using System.Collections.Generic;
using System.Text;
using System.Text.RegularExpressions;
using Xamarin.Forms;

namespace GFDT.ViewModels
{
    public class ContactUsViewModel : BaseViewModel
    {
        public ContactUsViewModel()
        {

        }

        #region Property

        private string name { get; set; }
        public string Name
        {
            get => name;
            set { name = value; RaisePropertyChanged(() => Name); }
        }

        private string email { get; set; }
        public string Email
        {
            get => email;
            set { email = value; RaisePropertyChanged(() => Email); }
        }

        private string contactNumber { get; set; }
        public string ContactNumber
        {
            get => contactNumber;
            set { contactNumber = value; RaisePropertyChanged(() => ContactNumber); }
        }

        private string message { get; set; }
        public string Message
        {
            get => message;
            set { message = value; RaisePropertyChanged(() => Message); }
        }
        private string subject { get; set; }
        public string Subject
        {
            get => subject;
            set { subject = value; RaisePropertyChanged(() => Subject); }
        }
        #endregion

        #region Commands 
        public Command SubmitCommand
        {
            get { return new Command(SubmitExecution); }
        }


        #endregion

        #region Command Execution 
        void SubmitExecution()
        {
            if (IsValid())
            {
                var sss = IsEmailValid(Email);
                if (sss != true)
                {
                    UserDialogs.Instance.Alert("Please enter valid Email.", "Alert", "Ok");
                }
                else
                {
                    UserDialogs.Instance.ShowLoading();
                    var req = new ContactUsRequest
                    {
                        email = Email,
                        message = Message,
                        mobile = Convert.ToInt64(ContactNumber),
                        name = Name,
                        subject = string.IsNullOrEmpty(Subject) ? "Query" : Subject
                    };
                    userManager.ContactUs(req, () =>
                    {
                        UserDialogs.Instance.HideLoading();
                        var v = userManager.ContactUsResponse;
                        if (v.status == true)
                        {
                            UserDialogs.Instance.Alert(v.message, "Alert", "Ok");
                            Clear();
                            //Device.BeginInvokeOnMainThread(() =>
                            //{
                            //    App.Current.MainPage = new NavigationPage(new Views.HomeView());
                            //});
                        }
                        else
                        {
                            UserDialogs.Instance.Alert(v.message, "Alert", "Ok");
                        }

                    },
                   (failure) =>
                   {
                       UserDialogs.Instance.HideLoading();
                       UserDialogs.Instance.Alert(failure.message, "Alert", "Ok");
                   });
                }
            }

        }

        #endregion

        #region Validation Methods
        public bool IsValid()
        {
            bool isvalid = false;

            if (string.IsNullOrEmpty(Name))
            {
                UserDialogs.Instance.Alert("Please enter Name.", "Alert", "Ok");
            }
            else if (string.IsNullOrEmpty(Email))
            {
                UserDialogs.Instance.Alert("Please enter Email.", "Alert", "Ok");
            }
            else if (!IsEmailValid(Email))
            {
                UserDialogs.Instance.Alert("Please enter Valid Email.", "Alert", "Ok");
            }
            else if (string.IsNullOrEmpty(ContactNumber))
            {
                UserDialogs.Instance.Alert("Please enter Contact Number.", "Alert", "Ok");
            }
            else if (string.IsNullOrEmpty(Message))
            {
                UserDialogs.Instance.Alert("Please enter Message.", "Alert", "Ok");
            }

            else
            {
                isvalid = true;
            }
            return isvalid;
        }

        public void Clear()
        {
            Name = Email = ContactNumber = Message = "";
        }

        private bool IsEmailValid(string email)
        {
            Regex regex = new Regex(@"^([\w\.\-]+)@([\w\-]+)((\.(\w){2,3})+)$");
            Match match = regex.Match(email);
            if (match.Success)
                return true;
            else
                return false;
        }
        #endregion
    }
}
