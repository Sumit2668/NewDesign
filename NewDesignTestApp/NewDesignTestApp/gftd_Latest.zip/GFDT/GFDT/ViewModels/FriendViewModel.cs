﻿using Acr.UserDialogs;
using GFDT.Models.Response;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Text;

namespace GFDT.ViewModels
{
    public class FriendViewModel : BaseViewModel
    {
        public FriendViewModel()
        {
           
        } 

        private ObservableCollection<Userdata> fuserdata;
        public ObservableCollection<Userdata> FUserdata
        {
            get => fuserdata;
            set
            {
                fuserdata = value;
                RaisePropertyChanged(() => FUserdata);
            }
        } 

        #region Methods

       public void GetFriendCollection()
        {
            try
            {

                userManager.GetFriendList(() =>
                {
                    var getfriend = userManager.GetFriendListResponse;

                    FUserdata = new ObservableCollection<Userdata>(getfriend.data);
                    UserDialogs.Instance.HideLoading();
                },
                (failure) =>
                {
                    UserDialogs.Instance.HideLoading();
                });
            }
            catch (Exception ex)
            {

            }
        }

        #endregion
    }
}
