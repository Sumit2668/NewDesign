﻿using System;
using System.Collections.Generic;
using System.Text;
using Xamarin.Forms;

namespace GFDT.ViewModels
{
    public class PrivacyPolicyViewModel : BaseViewModel
    {
        public PrivacyPolicyViewModel()
        { 
        }

        private string privacyPolicyies { get; set; }
        public string PrivacyPolicyies
        {
            get => privacyPolicyies;
            set
            {
                privacyPolicyies = value;
                RaisePropertyChanged(() => PrivacyPolicyies);
            }
        }

        private string termsPrivacyTitle { get; set; }
        public string TermsPrivacyTitle
        {
            get => termsPrivacyTitle;
            set
            {
                termsPrivacyTitle = value;
                RaisePropertyChanged(() => TermsPrivacyTitle);
            }
        }
        public Command GetPrivacyPolicyCommand
        {
            //get { return new Command(GetPrivacyPolicyExecution); }

            get { return new Command<string>((url) => GetPrivacyPolicy(url)); }
        }


        public void GetPrivacyPolicy(string url)
        {

            userManager.GetPrivayPolicy(url, () =>
            {
                PrivacyPolicyies = userManager.PrivacyPolicyResponse.data; 
            },
                (failure) =>
                {
                    //UserDialogs.Instance.HideLoading();
                });
        } 


    }
}
