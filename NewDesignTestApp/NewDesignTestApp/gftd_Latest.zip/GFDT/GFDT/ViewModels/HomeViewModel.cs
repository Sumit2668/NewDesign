﻿using System;
using System.Collections.Generic;
using Acr.UserDialogs;
using GalaSoft.MvvmLight;
using GFDT.Models.Response;
using GFDT.Views;
using Xamarin.Forms;

namespace GFDT.ViewModels
{
    public class HomeViewModel : BaseViewModel
    {
        public HomeViewModel()
        {
            MenuItemList = new List<Menu>();
            MenuItemList.Add(new Menu { Title = "Edit Profile", Icon = "edit_pro.png", TargetType = typeof(Views.EditProfileView) });
            MenuItemList.Add(new Menu { Title = "Privacy Setting", Icon = "privacy_setting.png", TargetType = typeof(WishListPrivacyView) });
            MenuItemList.Add(new Menu { Title = "Notification", Icon = "notification.png", TargetType = typeof(NotificationView) });


            MenuItemList.Add(new Menu { Title = "Store", Icon = "store.png", TargetType = typeof(StoreView) });
            MenuItemList.Add(new Menu { Title = "My Transacions", Icon = "contact_us.png", TargetType = typeof(TransactionView) });
            MenuItemList.Add(new Menu { Title = "Add Item", Icon = "add_item.png", TargetType = typeof(AddItemView) });

            MenuItemList.Add(new Menu { Title = "Share App", Icon = "share_app.png", TargetType = typeof(BankDetailView) });
            MenuItemList.Add(new Menu { Title = "Privacy Policy", Icon = "terms_cond.png", TargetType = typeof(PrivacyPolicy) });
            MenuItemList.Add(new Menu { Title = "Terms and Conditions", Icon = "my_transaction.png", TargetType = typeof(TermsandConditionsView) });

            MenuItemList.Add(new Menu { Title = "Delete Account", Icon = "del_acc.png", TargetType = typeof(DeleteAccountView) });
            MenuItemList.Add(new Menu { Title = "Contact Us", Icon = "contact_us.png", TargetType = typeof(Contactus) });
            MenuItemList.Add(new Menu { Title = "Change Number", Icon = "change_number.png", TargetType = typeof(UnderDevelopment) });

            MenuItemList.Add(new Menu { Title = "Logout", Icon = "change_number.png", TargetType = typeof(LoginView) });


        }

        #region Set Property

        private List<Menu> menuItemList;
        public List<Menu> MenuItemList
        {
            get { return menuItemList; }
            set
            {
                menuItemList = value;
                RaisePropertyChanged(() => MenuItemList);
            }
        }

        private bool isPresented;
        public bool IsPresented
        {
            get { return isPresented; }
            set
            {
                isPresented = value;
                RaisePropertyChanged(() => IsPresented);
            }
        }

        private ImageSource picture;
        public ImageSource Picture
        {
            get { return picture; }
            set { picture = value; RaisePropertyChanged(() => Picture); }
        }

        private UserData currentUser;
        public UserData CurrentUser
        {
            get { return currentUser; }
            set
            {
                currentUser = value;
                RaisePropertyChanged(() => CurrentUser);
            }
        }



        #endregion


        #region Commands 

        public Command ProfileinfoCommand
        {
            get { return new Command(ProfileinfoExecution); }
        }



        #endregion

        #region Command Execution  

        public void ProfileinfoExecution()
        {
            try
            {
                UserDialogs.Instance.ShowLoading();
                userManager.ProfileInfo(() =>
                {
                    UserDialogs.Instance.HideLoading();
                    var profileInfo = userManager.ProfileInfoResponse;
                    if (profileInfo.status)
                    {
                        App.Locator.HomeViewModel.CurrentUser = profileInfo.data;

                        if (!profileInfo.data.image.StartsWith("http"))
                        {
                            profileInfo.data.image = "https://avatars3.githubusercontent.com/u/1816448?s=400&v=4";
                        }
                        Device.BeginInvokeOnMainThread(() =>
                        {
                            Picture = new UriImageSource
                            {
                                Uri = new Uri(profileInfo.data.image),
                                CachingEnabled = true,
                                CacheValidity = new TimeSpan(5, 0, 0, 0)
                            };
                        });
                    }

                },
                (failure) =>
                {
                    UserDialogs.Instance.HideLoading();
                });
            }
            catch (Exception ex)
            {
                userManager.ProfileInfo(() =>
               {
                   UserDialogs.Instance.HideLoading();
                   var profileInfo = userManager.ProfileInfoResponse;
                   if (profileInfo.status)
                   {
                       App.Locator.HomeViewModel.CurrentUser = profileInfo.data;

                       if (!profileInfo.data.image.StartsWith("http"))
                       {
                           profileInfo.data.image = "https://avatars3.githubusercontent.com/u/1816448?s=400&v=4";
                       }
                       Device.BeginInvokeOnMainThread(() =>
                       {
                           Picture = new UriImageSource
                           {
                               Uri = new Uri(profileInfo.data.image),
                               CachingEnabled = true,
                               CacheValidity = new TimeSpan(5, 0, 0, 0)
                           };
                       });
                   }

               },
               (failure) =>
               {
                   UserDialogs.Instance.HideLoading();
               });


            }
        }

        #endregion


    }
    public class Menu : ViewModelBase
    {
        public string Title { get; set; }
        public ImageSource Icon { get; set; }
        public string Tag { get; set; }
        public Type TargetType { get; set; }
        public int Quantity { get; set; }
        public Color SelectionColor { get; set; }

        private bool isVisible = true;
        public bool IsVisible
        {
            get { return isVisible; }
            set
            {
                isVisible = value;
                RaisePropertyChanged(() => IsVisible);
            }
        }

    }
    public class MyTestModel
    {
       public string Image { get; set; }
       public string Name { get; set; }
    }
}
