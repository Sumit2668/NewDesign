/*
  In App.xaml:
  <Application.Resources>
      <vm:ViewModelLocator xmlns:vm="clr-namespace:GFTD"
                           x:Key="Locator" />
  </Application.Resources>
  
  In the View:
  DataContext="{Binding Source={StaticResource Locator}, Path=ViewModelName}"

  You can also use Blend to do all this with the tool's support.
  See http://www.galasoft.ch/mvvm
*/

using GalaSoft.MvvmLight.Ioc;
using GFDT.ViewModels;
using CommonServiceLocator;
using GFDT.Providers.ApiProvider;
using GFDT.Managers.SettingsManager;
using GFDT.Managers.UserManager;
using GFDT.Services;

namespace GFTD.ViewModel
{
    /// <summary>
    /// This class contains static references to all the view models in the
    /// application and provides an entry point for the bindings.
    /// </summary>
    public class ViewModelLocator
    {
        /// <summary>
        /// Initializes a new instance of the ViewModelLocator class.
        /// </summary>
        public ViewModelLocator()
        {
            CommonServiceLocator.ServiceLocator.SetLocatorProvider(() => SimpleIoc.Default);

            ////if (ViewModelBase.IsInDesignModeStatic)
            ////{
            ////    // Create design time view services and models
            ////    SimpleIoc.Default.Register<IDataService, DesignDataService>();
            ////}
            ////else
            ////{
            ////    // Create run time view services and models
            ////    SimpleIoc.Default.Register<IDataService, DataService>();
            ////}
            /// 
            /// 
            /// 

            SimpleIoc.Default.Register<ISettingsManager, SettingsManager>();
            SimpleIoc.Default.Register<IApiProvider, ApiProvider>();
            SimpleIoc.Default.Register<IUserManager, UserManager>();
            SimpleIoc.Default.Register<ISqliteService, SqliteService>();

            SimpleIoc.Default.Register<MainViewModel>();
            SimpleIoc.Default.Register<LoginViewModel>();
            SimpleIoc.Default.Register<HomeViewModel>();
            SimpleIoc.Default.Register<AddItemViewModel>();
            SimpleIoc.Default.Register<ContactUsViewModel>();
            SimpleIoc.Default.Register<SendAGFTViewModel>();
            SimpleIoc.Default.Register<PrivacyPolicyViewModel>();
            SimpleIoc.Default.Register<MyWishesViewModel>();
            SimpleIoc.Default.Register<FriendViewModel>();
            SimpleIoc.Default.Register<EditProfileViewModel>();
            SimpleIoc.Default.Register<StoreViewModel>();
            SimpleIoc.Default.Register<FeedViewModel>();
            
        }

        public MainViewModel Main
        {
            get
            {
                return ServiceLocator.Current.GetInstance<MainViewModel>();
            }
        }

        public LoginViewModel LoginViewModel
        {
            get
            {
                return ServiceLocator.Current.GetInstance<LoginViewModel>();
            }
        }

        public HomeViewModel HomeViewModel
        {
            get
            {
                return ServiceLocator.Current.GetInstance<HomeViewModel>();
            }
        }
        public AddItemViewModel AddItemViewModel
        {
            get
            {
                return ServiceLocator.Current.GetInstance<AddItemViewModel>();
            }
        }
        public ContactUsViewModel ContactUsViewModel
        {
            get
            {
                return ServiceLocator.Current.GetInstance<ContactUsViewModel>();
            }
        }
        public SendAGFTViewModel SendAGFTViewModel
        {
            get
            {
                return ServiceLocator.Current.GetInstance<SendAGFTViewModel>();
            }
        }
        public PrivacyPolicyViewModel PrivacyPolicyViewModel
        {
            get
            {
                return ServiceLocator.Current.GetInstance<PrivacyPolicyViewModel>();
            }
        }
        public MyWishesViewModel MyWishesViewModel
        {
            get
            {
                return ServiceLocator.Current.GetInstance<MyWishesViewModel>();
            }
        }
        public FriendViewModel FriendViewModel
        {
            get
            {
                return ServiceLocator.Current.GetInstance<FriendViewModel>();
            }
        }
        public EditProfileViewModel EditProfileViewModel
        {
            get
            {
                return ServiceLocator.Current.GetInstance<EditProfileViewModel>();
            }
        }
        public StoreViewModel StoreViewModel => ServiceLocator.Current.GetInstance<StoreViewModel>();
        public FeedViewModel FeedViewModel => ServiceLocator.Current.GetInstance<FeedViewModel>();



        public static void Cleanup()
        {
            // TODO Clear the ViewModels
        }
    }
}