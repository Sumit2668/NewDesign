﻿using Acr.UserDialogs;
using GalaSoft.MvvmLight;
using GFDT.Enums;
using GFDT.Models.Request;
using GFDT.Models.Response;
using GFDT.Views;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;
using Xamarin.Forms;

namespace GFDT.ViewModels
{
    public class StoreViewModel : BaseViewModel
    {

        #region Product Property Code

        private List<ProductImage> productimagelist;
        public List<ProductImage> ProductImageList
        {
            get { return productimagelist; }
            set
            {

                productimagelist = value;
                RaisePropertyChanged(() => ProductImageList);
            }
        }

        private string productname;
        public string ProductName
        {
            get { return productname; }
            set
            {
                productname = value;
                RaisePropertyChanged(() => ProductName);
            }
        }
        private string productcategory;
        public string ProductCategory
        {
            get { return productcategory; }
            set
            {
                productcategory = value;
                RaisePropertyChanged(() => ProductCategory);
            }
        }

        private string productcolor;
        public string ProductColor
        {
            get { return productcolor; }
            set
            {
                productcolor = value;
                RaisePropertyChanged(() => ProductColor);
            }
        }

        private string productprice;
        public string ProductPrice
        {
            get { return productprice; }
            set
            {
                productprice = value;
                RaisePropertyChanged(() => ProductPrice);
            }
        }

        private string productrate;
        public string ProductRate
        {
            get { return productrate; }
            set
            {
                productrate = value;
                RaisePropertyChanged(() => ProductRate);
            }
        }

        private string productsize;
        public string ProductSize
        {
            get { return productsize; }
            set
            {
                productsize = value;
                RaisePropertyChanged(() => ProductSize);
            }
        }

        private string productdescription;

        public string ProductDescription
        {
            get { return productdescription; }
            set
            {
                productdescription = value;
                RaisePropertyChanged(() => ProductDescription);
            }
        }

        #endregion

        #region Store Property Code
        public ObservableCollection<MyWishStoreList> storesource;
        int selectionCount = 1;
        public ObservableCollection<MyWishStoreList> Stores { get; private set; }
        public IList<MyWishStoreList> EmptyMonkeys { get; private set; }

        MyWishStoreList selectedStore;
        public MyWishStoreList SelectedStore
        {
            get
            {
                return selectedStore;
            }
            set
            {
                if (selectedStore != value)
                {
                    selectedStore = value;
                }
            }
        }

        private string favorite;

        public string Favorite
        {
            get { return favorite; }
            set
            {
                favorite = value;
                RaisePropertyChanged(() => Favorite);
            }
        }

        private int productid;

        public int ProductId
        {
            get { return productid; }
            set
            {
                productid = value;
                RaisePropertyChanged(() => ProductId);
            }
        }
        #endregion

        public string SelectedStoreMessage { get; private set; }
        public ICommand FilterCommand => new Command<string>(FilterItems);
        public ICommand MonkeySelectionChangedCommand => new Command(StoreSelectionChanged);

        public ICommand IsLikeCommand => new Command(IsLikeCommandExecution);
        public ICommand SendGiftCommand => new Command(SendGiftCommandExecution);

        

        public ICommand NavigeteToItemDetailCommand => new Command<MyWishStoreList>(NavigeteToItemDetailCommandExecution);





        private void SendGiftCommandExecution(object obj)
        {
            try
            {
                var sendgiftrequest = new SendProductGiftRequest()
                {
                    product_id = ProductId,
                };
                userManager.SendProductGift(sendgiftrequest, () =>
                {
                    var getresponse = userManager.BaseResponse;
                    UserDialogs.Instance.Toast(getresponse.message, new TimeSpan(3000));
                },
                (failure) =>
                {
                    UserDialogs.Instance.HideLoading();
                });
            }
            catch (Exception)
            {
                UserDialogs.Instance.HideLoading();
            }
        }

        private void NavigeteToItemDetailCommandExecution(MyWishStoreList obj)
        {
            ProductImageList = new List<ProductImage>();
            try
            {
                userManager.GetProductDetails(obj.id, () =>
                {
                    var getitemdetailresponse = userManager.ProductDetailResponse;
                    var data = getitemdetailresponse.product;

                    Device.BeginInvokeOnMainThread(() =>
                    {
                        foreach (var item in data.product_all_image)
                        {
                            ProductImageList.Add(new ProductImage() { ImageUrl = item });
                        }
                        ProductColor = data.product_color;
                        ProductSize = data.product_size;
                        ProductRate = data.product_rate;
                        ProductDescription = data.product_description;
                        ProductPrice = data.product_price;
                        ProductName = data.product_name;

                        //   App.SendGiftNavigationPage.Navigation.PushAsync(new Views.ItemDetailsView());
                        UserDialogs.Instance.HideLoading();
                        try
                        {
                            // ((MasterDetailPage)App.Current.MainPage).Detail.Navigation.PushAsync(new HomeView());
                            ((MasterDetailPage)App.Current.MainPage).Detail.Navigation.PushAsync(new Views.ItemDetailsView());
                        }
                        catch (Exception ex)
                        {
                            App.Current.MainPage.Navigation.PushAsync(new Views.ItemDetailsView());
                        }

                    });
                },
                (failure) =>
                {
                    UserDialogs.Instance.HideLoading();
                });
            }
            catch (Exception)
            {
                UserDialogs.Instance.HideLoading();
            }
        }

        private void IsLikeCommandExecution(object obj)
        {
            try
            {
                var mark = new MarkRequest()
                {
                    product_id = ProductId,
                };
                userManager.StoreLike(mark, () =>
                 {
                     var getresponse = userManager.BaseResponse;
                     UserDialogs.Instance.Toast(getresponse.message, new TimeSpan(2000));
                 },
                (failure) =>
                {
                    UserDialogs.Instance.HideLoading();
                });
            }
            catch (Exception)
            {
                UserDialogs.Instance.HideLoading();
            }
        }

        public StoreViewModel()
        {
            GetStoreList();
        }


        void GetStoreList()
        {
            try
            {
                storesource = new ObservableCollection<MyWishStoreList>(); 
                userManager.GetStoreWisheshItemDetail((int)GetListEnum.MyStore, () =>
                {
                    var getitemdata = userManager.GetListItemResponce;
                    foreach (var item in getitemdata.data)
                    {
                        storesource.Add(new MyWishStoreList()
                        {
                            id = item.id,
                            created_at = item.created_at,
                            product_category = item.product_category,
                            product_description = item.product_description,
                            product_image = item.product_image,
                            product_name = item.product_name,
                            product_price = item.product_price,
                            product_tag = item.product_tag,
                            product_tax = item.product_tax,
                            store_location = item.store_location,
                            store_name = item.store_name,
                            updated_at = item.updated_at,
                            user_id = item.user_id
                        });
                    }

                    Stores = new ObservableCollection<MyWishStoreList>(storesource);
                },
                (failure) =>
                {
                    UserDialogs.Instance.HideLoading();
                });
            }
            catch (Exception ex)
            {

            }

        }


        void FilterItems(string filter)
        {
            var filteredItems = storesource.Where(store => store.product_name.ToLower().Contains(filter.ToLower())).ToList();
            foreach (var store in storesource)
            {
                if (!filteredItems.Contains(store))
                {
                    Stores.Remove(store);
                }
                else
                {
                    if (!Stores.Contains(store))
                    {
                        Stores.Add(store);
                    }
                }
            }
        }
         
        void StoreSelectionChanged()
        {
            SelectedStoreMessage = $"Selection {selectionCount}: {SelectedStore.product_name}";
            RaisePropertyChanged(() => SelectedStoreMessage);
            selectionCount++;
        }



        #region WishViewCode


        public ObservableCollection<MyWishStoreList> mywishlist;
        private ObservableCollection<MyWishStoreList> wishlist;
        public ObservableCollection<MyWishStoreList> WishList
        {
            get => wishlist;
            set
            {
                wishlist = value;
                RaisePropertyChanged(() => WishList);
            }
        }
 
        public ICommand WishFilterCommand => new Command<string>(WishFilterItems);

        MyWishStoreList selectedWishesh;
        public MyWishStoreList SelectedWishesh
        {
            get
            {
                return selectedWishesh;
            }
            set
            {
                if (selectedWishesh != value)
                {
                    selectedWishesh = value;
                }
            }
        }
 


        public void GetWishCollection()
        {
            try
            {
                // UserDialogs.Instance.ShowLoading();
                mywishlist = new ObservableCollection<MyWishStoreList>();
                userManager.GetStoreWisheshItemDetail((int)GetListEnum.MyWishList, (Action)(() =>
                {
                    var getitemdata = userManager.GetListItemResponce;
                        foreach (var item in getitemdata.data)
                        {
                            mywishlist.Add(new MyWishStoreList()
                            {
                                id = item.id,
                                created_at = item.created_at,
                                product_category = item.product_category,
                                product_description = item.product_description,
                                product_image = item.product_image,
                                product_name = item.product_name,
                                product_price = item.product_price,
                                product_tag = item.product_tag,
                                product_tax = item.product_tax,
                                store_location = item.store_location,
                                store_name = item.store_name,
                                updated_at = item.updated_at,
                                user_id = item.user_id
                            });
                        }
                        WishList = new ObservableCollection<MyWishStoreList>(mywishlist);
                     
                    // UserDialogs.Instance.HideLoading();
                }),
                (failure) =>
                {
                    //UserDialogs.Instance.HideLoading();
                });
            }
            catch (Exception ex)
            {

            }
        }


        void WishFilterItems(string filter)
        {
            var filteredItems = mywishlist.Where(store => store.product_name.ToLower().Contains(filter.ToLower())).ToList();
            foreach (var wishes in mywishlist)
            {
                if (!filteredItems.Contains(wishes))
                {
                    WishList.Remove(wishes);
                }
                else
                {
                    if (!WishList.Contains(wishes))
                    {
                        WishList.Add(wishes);
                    }
                }
            }
        }
        #endregion

    }

    public class ProductImage
    {
        public string ImageUrl { get; set; }
    }
}

