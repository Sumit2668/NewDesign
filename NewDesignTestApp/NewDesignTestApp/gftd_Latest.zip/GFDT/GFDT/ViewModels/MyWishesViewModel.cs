﻿using Acr.UserDialogs;
using GFDT.Enums;
using GFDT.Models.Response;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Windows.Input;
using Xamarin.Forms;

namespace GFDT.ViewModels
{
    public class MyWishesViewModel : BaseViewModel
    {
        public MyWishesViewModel()
        {

            // CreateStoreCollection();
            
            //Now we can use for the Store Viewmodel
        }
        //public ObservableCollection<MyWishStoreList> mywishlist;
        //private ObservableCollection<MyWishStoreList> wishlist;
        //public ObservableCollection<MyWishStoreList> WishList
        //{
        //    get => wishlist;
        //    set
        //    {
        //        wishlist = value;
        //        RaisePropertyChanged(() => WishList);
        //    }
        //}
        //public IList<MyWishStoreList> EmptyMonkeys { get; private set; }
        //public ICommand WishFilterCommand => new Command<string>(WishFilterItems);

        //MyWishStoreList selectedWishesh;
        //public MyWishStoreList SelectedWishesh
        //{
        //    get
        //    {
        //        return selectedWishesh;
        //    }
        //    set
        //    {
        //        if (selectedWishesh != value)
        //        {
        //            selectedWishesh = value;
        //        }
        //    }
        //}

        //private string favorite;

        //public string Favorite
        //{
        //    get { return favorite; }
        //    set { favorite = value; }
        //}




        //public void GetWishCollection()
        //{
        //    try
        //    {
        //        // UserDialogs.Instance.ShowLoading();
        //        mywishlist = new ObservableCollection<MyWishStoreList>();
        //        userManager.GetStoreWisheshItemDetail((int)GetListEnum.MyWishList, (Action)(() =>
        //        {
        //            var getitemdata = userManager.GetListItemResponce;
        //            try
        //            {
        //                foreach (var item in getitemdata.data)
        //                {
        //                    mywishlist.Add(new MyWishStoreList()
        //                    {
        //                        id = item.id,
        //                        created_at = item.created_at,
        //                        product_category = item.product_category,
        //                        product_description = item.product_description,
        //                        product_image = item.product_image,
        //                        product_name = item.product_name,
        //                        product_price = item.product_price,
        //                        product_tag = item.product_tag,
        //                        product_tax = item.product_tax,
        //                        store_location = item.store_location,
        //                        store_name = item.store_name,
        //                        updated_at = item.updated_at,
        //                        user_id = item.user_id
        //                    });
        //                }
        //                WishList = new ObservableCollection<MyWishStoreList>(mywishlist);
        //            }
        //            catch (Exception ex)
        //            {

        //            }
        //            // UserDialogs.Instance.HideLoading();
        //        }),
        //        (failure) =>
        //        {
        //            //UserDialogs.Instance.HideLoading();
        //        });
        //    }
        //    catch (Exception ex)
        //    {

        //    }
        //}


        //void WishFilterItems(string filter)
        //{
        //    var filteredItems = mywishlist.Where(store => store.product_name.ToLower().Contains(filter.ToLower())).ToList();
        //    foreach (var wishes in mywishlist)
        //    {
        //        if (!filteredItems.Contains(wishes))
        //        {
        //            WishList.Remove(wishes);
        //        }
        //        else
        //        {
        //            if (!WishList.Contains(wishes))
        //            {
        //                WishList.Add(wishes);
        //            }
        //        }
        //    }
        //}




    }
}
