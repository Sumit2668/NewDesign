﻿using System;
using GalaSoft.MvvmLight;

namespace GFDT.ViewModels
{
    public class MainViewModel:ViewModelBase
    {
        public MainViewModel()
        {
            
        }
        string m;
        public string mm
        {
            get { return m; }
            set
            {
                m = value;
                RaisePropertyChanged(() => mm);

            }
        }
    }
}
