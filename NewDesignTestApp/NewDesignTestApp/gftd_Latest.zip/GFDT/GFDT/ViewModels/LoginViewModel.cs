﻿using System;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using Acr.UserDialogs;
using GFDT.Models;
using GFDT.Models.Request;
using GFDT.Services;
using GFDT.Views;
using GFTD.Models.Request;
using GFTD.Models.Response;
using Xamarin.Forms;
using System.Linq;

namespace GFDT.ViewModels
{
    public class LoginViewModel : BaseViewModel
    {


        public LoginViewModel()
        {
            //UserName = "sumit@gmail.com";
            //Password = "111111";
            if (string.IsNullOrEmpty(App.Devicetoken))
            {
                App.Devicetoken = "cOA9jx7_cTI:APA91bGlBW3nrKPGVjffsG06dLu3zjmEIZ4kU-IYiY1BW1tU2jx83rsCPS9juKx6IqgnwsUArKl1A7IS1u4aEoA4rr0rTekEukuYGeOQWidpItOwmCq9P1V0-8bm6_wbkVfLagvZ-8KB";
            }
        }

        #region Bank Property
        private string bankName { get; set; }
        public string BankName
        {
            get => bankName;
            set
            {
                bankName = value;
                RaisePropertyChanged(() => BankName);
            }
        }

        private string acholdername { get; set; }
        public string ACHolderName
        {
            get => acholdername;
            set
            {
                acholdername = value;
                RaisePropertyChanged(() => ACHolderName);
            }
        }
        private string accountnumber { get; set; }
        public string AccNumber
        {
            get => accountnumber;
            set
            {
                accountnumber = value;
                RaisePropertyChanged(() => AccNumber);
            }
        }


        private string countryCode { get; set; }
        public string CountryCode
        {
            get => countryCode;
            set
            {
                countryCode = value;
                RaisePropertyChanged(() => CountryCode);
            }
        }



        private string routingnumber { get; set; }
        public string RoutingNumber
        {
            get => routingnumber;
            set
            {
                routingnumber = value;
                RaisePropertyChanged(() => RoutingNumber);
            }
        }

        #endregion

        #region Set OTP Property
        private string otp1;
        public string OTP1
        {
            get { return otp1; }
            set
            {
                otp1 = value;
                RaisePropertyChanged(() => OTP1);
            }
        }
        private string otp2;
        public string OTP2
        {
            get { return otp2; }
            set
            {
                otp2 = value;
                RaisePropertyChanged(() => OTP2);
            }
        }

        private string otp3;
        public string OTP3
        {
            get { return otp3; }
            set
            {
                otp3 = value;
                RaisePropertyChanged(() => OTP3);
            }
        }
        private string otp4;
        public string OTP4
        {
            get { return otp4; }
            set
            {
                otp4 = value;
                RaisePropertyChanged(() => OTP4);
            }
        }
        #endregion

        #region Set Property

        private string userName { get; set; }
        public string UserName
        {
            get => userName;
            set
            {
                userName = value;
                RaisePropertyChanged(() => UserName);
            }
        }


        private string password { get; set; }
        public string Password
        {
            get => password;
            set
            {
                password = value;
                RaisePropertyChanged(() => Password);
            }
        }

        private string phoneNumber { get; set; }
        public string PhoneNumber
        {
            get => phoneNumber;
            set
            {
                phoneNumber = value;
                RaisePropertyChanged(() => PhoneNumber);
            }
        }


        private string displayName { get; set; }
        public string DisplayName
        {
            get => displayName;
            set
            {
                displayName = value;
                RaisePropertyChanged(() => DisplayName);
            }
        }


        private string username { get; set; }
        public string Username
        {
            get => username;
            set
            {
                username = value;
                RaisePropertyChanged(() => Username);
            }
        }


        private string email { get; set; }
        public string Email
        {
            get => email;
            set
            {
                email = value;
                RaisePropertyChanged(() => Email);
            }
        }

        private string forgetemail { get; set; }
        public string ForgetEmail
        {
            get => forgetemail;
            set
            {
                forgetemail = value;
                RaisePropertyChanged(() => ForgetEmail);
            }
        }

        private string userpassword { get; set; }
        public string Userpassword
        {
            get => userpassword;
            set
            {
                userpassword = value;
                RaisePropertyChanged(() => Userpassword);
            }
        }


        private string conUserpassword { get; set; }
        public string ConUserpassword
        {
            get => conUserpassword;
            set
            {
                conUserpassword = value;
                RaisePropertyChanged(() => ConUserpassword);
            }
        }

        #endregion

        #region Commands
        public Command LoginCommand
        {
            get { return new Command(LoginCommandExecution); }
        }

        public Command SignupCommand
        {
            get { return new Command(SignupCommandExecution); }
        }

        public Command ForgotPasswordCommand
        {
            get { return new Command(ForgotPasswordCommandExecution); }
        }

        public Command GoBackToLoginCommand
        {
            get { return new Command(GoBackToLoginCommandExecution); }
        }

        public Command GoBackOTPToLoginCommand
        {
            get { return new Command(GoBackOTPToLoginCommandExecution); }
        }
        public Command ContinueToOTPCommand
        {
            get { return new Command(ContinueToOTPCommandExecution); }
        }
        public Command ContinueToCompleteProfileCommand
        {
            get { return new Command(ContinueToCompleteProfileCommandExecution); }
        }

        public Command ContinueOTPToLoginCommand
        {
            get { return new Command(ContinueOTPToLoginCommandExecution); }
        }

        public Command SaveCompleteProfileCommand
        {
            get { return new Command(SaveCompleteProfileCommandExecution); }
        }

        public Command BankNextCommand
        {
            get { return new Command(BankNextCommandExecution); }
        }
        public Command BankSkipCommand
        {
            get { return new Command(BankSkipCommandExecution); }
        }

        public Command DeleteAccountCommand
        {
            get { return new Command(DeleteAccountCommandExecution); }
        }

        public Command LogOutCommand
        {
            get { return new Command(LogOutCommandExecution); }
        }

        public Command ForgotPasswordAPICommand
        {
            get { return new Command(ForgotPasswordAPICommandExecution); }
        }



        #endregion

        #region Command Execution
        void LoginCommandExecution()
        {

            try
            {
                if (IsLoginValid())
                {
                    UserDialogs.Instance.ShowLoading();
                    var req = new LoginRequest
                    {
                        email = UserName,
                        password = Password,
                        device_token = App.Devicetoken == null ? "cOA9jx7_cTI:APA91bGlBW3nrKPGVjffsG06dLu3zjmEIZ4kU-IYiY1BW1tU2jx83rsCPS9juKx6IqgnwsUArKl1A7IS1u4aEoA4rr0rTekEukuYGeOQWidpItOwmCq9P1V0-8bm6_wbkVfLagvZ-8KB" : App.Devicetoken,
                    };
                    userManager.Login(req, () =>
                    {

                        var v = userManager.LoginResponse;

                        if (v.status)
                        {
                            GetDataOnLoad(v);
                            //var CurrentUser = new CurrentUser()
                            //{
                            //    email = v.data.email,
                            //    username = v.data.username,
                            //    mobile = v.data.mobile,
                            //    device_token = v.data.device_token,
                            //    ID = Guid.NewGuid(),
                            //    api_token = v.token,
                            //};



                            Xamarin.Essentials.Preferences.Set("IsLogin", true);

                            //   App.CurrentUser = CurrentUser;
                            // App.LocalDatabase.SaveCurrentUser(CurrentUser);
                            UserDialogs.Instance.HideLoading();
                            Device.BeginInvokeOnMainThread(async () =>
                            {
                                Clear();

                                var nav = App.Current.MainPage.Navigation.NavigationStack.Where(x => x is HomeView).FirstOrDefault();

                                if (nav == null)
                                {
                                    App.Current.MainPage = new NavigationPage(new Views.HomeView());

                                }
                                else
                                {
                                    // ((MasterDetailPage)App.Current.MainPage).Detail.Navigation.PushAsync(new HomeView());
                                    App.Current.MainPage.Navigation.PushAsync(new HomeView());
                                }
                                //var nav=App.Current.MainPage.Navigation.NavigationStack.where(x=>x is HomeView)
                                //if(App.Current.MainPage.Navigation.NavigationStack.Contains(typeof()))
                                // {
                                //App.Current.MainPage = new NavigationPage(new Views.HomeView());
                                //}else
                                //{
                                //await  App.Current.MainPage.Navigation.PushAsync(new Views.HomeView(),true);
                                //}
                            });
                        }
                        else
                        {
                            UserDialogs.Instance.HideLoading();
                            UserDialogs.Instance.Alert(v?.message, "Alert", "Ok");
                        }

                    },
                   (failure) =>
                   {
                       UserDialogs.Instance.HideLoading();
                       UserDialogs.Instance.Alert(failure?.message, "Alert", "Ok");
                   });
                }

            }
            catch (Exception ex)
            {
                UserDialogs.Instance.HideLoading();
                UserDialogs.Instance.Alert(ex.Message, "Alert", "Ok");
            }
        }

        public void GetDataOnLoad(LoginResponse LoginResponse)
        {
            if (LoginResponse != null)
            {
                App.MyAccesstoken = LoginResponse.token;
                Xamarin.Essentials.Preferences.Set("MyAccesstoken", LoginResponse.token);
                App.UserId = LoginResponse.data.id.ToString();
            }

            App.Locator.SendAGFTViewModel.WishListCommand.Execute(null);
            App.Locator.SendAGFTViewModel.GetListCommand.Execute(null);
            App.Locator.FriendViewModel.GetFriendCollection();
            App.Locator.StoreViewModel.GetWishCollection();
            App.Locator.FeedViewModel.GetFeedCollection();
            App.Locator.HomeViewModel.ProfileinfoCommand.Execute(null);
            // App.Locator.EditProfileViewModel.ProfileinfoCommand.Execute(null);
        }
        private void ForgotPasswordCommandExecution()
        {
            Clear();
            Device.BeginInvokeOnMainThread(() =>
            {
                App.Current.MainPage.Navigation.PushAsync(new ForgotPasswordView());
            });

        }

        private void SignupCommandExecution(object obj)
        {
            Clear();
            Device.BeginInvokeOnMainThread(() =>
            {
                App.Current.MainPage.Navigation.PushAsync(new SignupView());
            });


        }

        private void GoBackToLoginCommandExecution(object obj)
        {
            Device.BeginInvokeOnMainThread(() =>
            {
                // App.Current.MainPage.Navigation.PopAsync(true);
                App.Current.MainPage.Navigation.PushAsync(new LoginView());
            });
        }

        public int bankid = 1;

        private void ContinueToOTPCommandExecution(object obj)
        {
            try
            {
                var req = new ResetPasswordRequest { mobile = PhoneNumber, password = "123456" };
                UserDialogs.Instance.ShowLoading();
                userManager.ResetPassword(req, () =>
                {
                    var v = userManager.ResetPasswordResponse;

                    Device.BeginInvokeOnMainThread(() =>
                    {
                        App.Current.MainPage.DisplayAlert("Message", userManager.ResetPasswordResponse.message.ToString(), "Okay");
                        App.Current.MainPage = new NavigationPage(new LoginView());
                        UserDialogs.Instance.HideLoading();
                    });
                },
               (failure) =>
               {
                   UserDialogs.Instance.Alert(failure?.message, null, "OK");
                   UserDialogs.Instance.HideLoading();
               });
            }
            catch (Exception ex)
            {
                UserDialogs.Instance.HideLoading();
                UserDialogs.Instance.Alert(ex?.Message, null, "OK");

            }

        }

        private void ContinueToCompleteProfileCommandExecution(object obj)
        {
            try
            {
                if (IsPhoneValid())
                {
                    UserDialogs.Instance.ShowLoading();
                    var req = new SignupRequest
                    {
                        mobile = CountryCode + PhoneNumber,
                        device_token = App.Devicetoken == null ? "cOA9jx7_cTI:APA91bGlBW3nrKPGVjffsG06dLu3zjmEIZ4kU-IYiY1BW1tU2jx83rsCPS9juKx6IqgnwsUArKl1A7IS1u4aEoA4rr0rTekEukuYGeOQWidpItOwmCq9P1V0-8bm6_wbkVfLagvZ-8KB" : App.Devicetoken
                    };
                    userManager.Signup(req, () =>
                    {
                        UserDialogs.Instance.HideLoading();
                        var v = userManager.SignupResponse;
                        if (v.status)
                        {
                            App.MyAccesstoken = v.token;
                            Device.BeginInvokeOnMainThread(() =>
                            {
                                App.Current.MainPage.Navigation.PushAsync(new OTPVerficationView());
                                UserDialogs.Instance.HideLoading();
                            });
                        }
                        else
                        {
                            UserDialogs.Instance.Alert(v?.message, "Alert", "Ok");
                        }
                    },
                   (failure) =>
                   {
                       UserDialogs.Instance.HideLoading();
                       UserDialogs.Instance.Alert(failure?.message, "Alert", "Ok");
                   });
                }
            }
            catch (Exception ex)
            {
                UserDialogs.Instance.HideLoading();
                UserDialogs.Instance.Alert(ex.Message, "Alert", "Ok");

            }


        }


        private void SaveCompleteProfileCommandExecution(object obj)
        {
            try
            {

                if (IsProfileValid())
                {
                    UserDialogs.Instance.ShowLoading();
                    //Anupam
                    var req = new CompleteProfileRequest { profile_type = 1, name = DisplayName, username = Username, email = Email, password = Userpassword };
                    userManager.CompleteProfile(req, () =>
                   {
                       var v = userManager.SignupResponse;
                       if (v.status)
                       {

                           App.MyAccesstoken = v.token;
                           App.UserId = v.data.id.ToString();
                           Xamarin.Essentials.Preferences.Set("MyAccesstoken", v.token);
                           GetDataOnLoad(null);

                           var CurrentUser = new CurrentUser()
                           {
                               email = v.data.email,
                               username = v.data.username,
                               mobile = v.data.mobile,
                               device_token = v.data.device_token,
                               ID = Guid.NewGuid(),
                               api_token = v.token,
                           };
                           App.CurrentUser = CurrentUser;

                           Xamarin.Essentials.Preferences.Set("IsLogin", true);
                           // App.LocalDatabase.SaveCurrentUser(CurrentUser);

                           ClearProfile();

                           Device.BeginInvokeOnMainThread(() =>
                           {
                               App.Current.MainPage = new BankDetailView();
                               UserDialogs.Instance.HideLoading();
                           });
                       }
                       else
                       {
                           UserDialogs.Instance.Alert(v?.message, "Alert", "Ok");
                       }


                   }, (failure) =>
                   {
                       UserDialogs.Instance.HideLoading();
                       UserDialogs.Instance.Alert(failure?.message, "Alert", "Ok");

                   });
                }

            }
            catch (Exception ex)
            {
                UserDialogs.Instance.HideLoading();
                UserDialogs.Instance.Alert(ex?.Message, "Alert", "Ok");

            }
        }


        private async void ContinueOTPToLoginCommandExecution(object obj)
        {
            if (PhoneNumber == "")
            {
                await App.Current.MainPage.DisplayAlert("", "Please fill all fields carefully.", "Okay");
                return;
            }
            if (string.IsNullOrEmpty(OTP1) || string.IsNullOrEmpty(OTP2) || string.IsNullOrEmpty(OTP3) || string.IsNullOrEmpty(OTP4))
            {
                await App.Current.MainPage.DisplayAlert("", "Please fill OTP fields carefully.", "Okay");
                return;
            }
            UserDialogs.Instance.ShowLoading();
            var req = new OTPVerificationRequest { mobile = PhoneNumber, otp = $"{OTP1}{OTP2}{OTP3}{OTP4}" };
            userManager.OTPVerification(req, () =>
           {
               var v = userManager.OTPVerificationResponse;
               System.Diagnostics.Debug.WriteLine($"OTP:  {userManager.OTPVerificationResponse.data.otp}");
               //App.Current.MainPage.DisplayAlert("", $"OTP:  {userManager.OTPVerificationResponse.data.otp}", "Okay");
               Device.BeginInvokeOnMainThread(() =>
          {
              // App.Current.MainPage = new NavigationPage(new CompleteProfileView());
              UserDialogs.Instance.HideLoading();

              try
              {
                  // ((MasterDetailPage)App.Current.MainPage).Detail.Navigation.PushAsync(new HomeView());
                  ((MasterDetailPage)App.Current.MainPage).Detail.Navigation.PushAsync(new Views.CompleteProfileView());
              }
              catch (Exception ex)
              {
                  App.Current.MainPage.Navigation.PushAsync(new Views.CompleteProfileView());
              }


          });
           },
           (failure) =>
           {

               UserDialogs.Instance.HideLoading();
               UserDialogs.Instance.Alert(failure?.message, "Alert", "Ok");
           });

        }

        private void GoBackOTPToLoginCommandExecution(object obj)
        {
            Clear();
            Device.BeginInvokeOnMainThread(() =>
            {
                App.Current.MainPage = new NavigationPage(new LoginView());
            });
        }
        private async void BankNextCommandExecution(object obj)
        {
            if (string.IsNullOrEmpty(BankName) == true || string.IsNullOrEmpty(ACHolderName) == true || string.IsNullOrEmpty(RoutingNumber) == true)
            {
                await App.Current.MainPage.DisplayAlert("", "Please fill all fields carefully.", "Okay");
                return;
            }
            UserDialogs.Instance.HideLoading();
            var req = new BankRequest
            {
                account_number = AccNumber == "" ? 0 : Convert.ToInt64(AccNumber),
                account_holder_name = ACHolderName,
                bank_name = BankName,
                route_number = RoutingNumber
            };
            userManager.BankDetail(req, () =>
           {
               var v = userManager.BankResponse;

               Device.BeginInvokeOnMainThread(() =>
               {
                   // App.Current.MainPage = new NavigationPage(new LoginView());
                   UserDialogs.Instance.HideLoading();
                   Device.BeginInvokeOnMainThread(() =>
                   {
                       // App.Current.MainPage = new NavigationPage(new Views.HomeView());


                       // var nav = App.Current.MainPage.Navigation.NavigationStack.Where(x => x is HomeView).FirstOrDefault();

                       // if (nav == null)
                       try
                       {
                           App.Current.MainPage = new NavigationPage(new Views.HomeView());

                       }
                       catch (Exception ex)
                       {
                           App.Current.MainPage.Navigation.PushAsync(new HomeView());

                       }
                       // else
                       {
                           // ((MasterDetailPage)App.Current.MainPage).Detail.Navigation.PushAsync(new HomeView());
                           //  App.Current.MainPage.Navigation.PushAsync(new HomeView());
                       }
                   });


               });
           }, (failure) => { UserDialogs.Instance.HideLoading(); });
        }

        private void BankSkipCommandExecution(object obj)
        {
            Device.BeginInvokeOnMainThread(() =>
            {
                // App.Current.MainPage = new NavigationPage(new HomeView());

                try
                {
                    // ((MasterDetailPage)App.Current.MainPage).Detail.Navigation.PushAsync(new HomeView());
                    ((MasterDetailPage)App.Current.MainPage).Detail.Navigation.PushAsync(new Views.HomeView());
                }
                catch (Exception ex)
                {
                    App.Current.MainPage.Navigation.PushAsync(new Views.HomeView());
                }
            });
        }


        public void DeleteAccountCommandExecution(object obj)
        {
            UserDialogs.Instance.ShowLoading();
            userManager.DeleteAccount(() =>
            {
                var v = userManager.BankResponse;


                Device.BeginInvokeOnMainThread(() =>
                {
                    App.Current.MainPage = new NavigationPage(new Views.LoginView());
                });
                UserDialogs.Instance.HideLoading();
                UserDialogs.Instance.AlertAsync(v.message, "Alert", "Okay");
                Xamarin.Essentials.Preferences.Set("IsLogin", false);
            }, (failure) =>
            {
                UserDialogs.Instance.HideLoading();
            });
        }

        private void ForgotPasswordAPICommandExecution(object obj)
        {
            var sss = IsEmailValid(ForgetEmail);
            if (sss != true)
            {
                UserDialogs.Instance.Alert("Please enter valid Email.", "Alert", "Ok");
            }
            else
            {
                UserDialogs.Instance.ShowLoading();
                var forgetreq = new ForgotPasswordRequest() { email = ForgetEmail };
                userManager.ForgotPassword(forgetreq, () =>
                {
                    var v = userManager.BaseResponse;
                    //System.Diagnostics.Debug.WriteLine($"OTP:  {userManager.OTPVerificationResponse.data.otp}");
                    //App.Current.MainPage.DisplayAlert("", $"OTP:  {userManager.OTPVerificationResponse.data.otp}", "Okay");
                    Device.BeginInvokeOnMainThread(() =>
                        {
                            //App.Current.MainPage = new NavigationPage(new CompleteProfileView());
                            UserDialogs.Instance.HideLoading();
                        });
                },
               (failure) =>
               {

                   UserDialogs.Instance.HideLoading();
               });
            }
        }






        private bool IsEmailValid(string email)
        {

            Regex regex = new Regex(@"^([\w\.\-]+)@([\w\-]+)((\.(\w){2,3})+)$");
            Match match = regex.Match(email);
            if (match.Success)
                return true;
            else
                return false;
        }
        public bool IsLoginValid()
        {
            bool isvalid = false;

            if (string.IsNullOrEmpty(UserName) && string.IsNullOrEmpty(Password))
            {
                UserDialogs.Instance.Alert("Please enter Username/Email and Password.", "Alert", "Ok");
            }
            else if (string.IsNullOrEmpty(UserName))
            {
                UserDialogs.Instance.Alert("Please enter Username/Email.", "Alert", "Ok");
            }
            //else if (!IsEmailValid(UserName))
            //{
            //    UserDialogs.Instance.Alert("Please enter valid Email.", "Alert", "Ok");
            //}
            else if (string.IsNullOrEmpty(Password))
            {
                UserDialogs.Instance.Alert("Please enter Password.", "Alert", "Ok");
            }
            else
            {
                isvalid = true;
            }
            return isvalid;
        }
        public bool IsPhoneValid()
        {
            bool isvalid = false;

            if (string.IsNullOrEmpty(PhoneNumber))
            {
                UserDialogs.Instance.Alert("Please enter your Phone Number.", "Alert", "Ok");
            }
            else if (PhoneNumber.Length != 10)
            {
                UserDialogs.Instance.Alert("Please enter a valid Phone Number.", "Alert", "Ok");
            }
            else
            {
                isvalid = true;
            }
            return isvalid;
        }
        public bool IsProfileValid()
        {

            bool isvalid = false;

            if (string.IsNullOrEmpty(DisplayName))
            {
                UserDialogs.Instance.Alert("Please enter Display Name.", "Alert", "Ok");
            }
            else if (string.IsNullOrEmpty(Username))
            {
                UserDialogs.Instance.Alert("Please enter User Name.", "Alert", "Ok");
            }
            else if (string.IsNullOrEmpty(Email))
            {
                UserDialogs.Instance.Alert("Please enter Email.", "Alert", "Ok");
            }
            else if (!IsEmailValid(Email))
            {
                UserDialogs.Instance.Alert("Please enter a valid Email.", "Alert", "Ok");
            }
            else if (string.IsNullOrEmpty(Userpassword))
            {
                UserDialogs.Instance.Alert("Please enter Password.", "Alert", "Ok");
            }
            else if (string.IsNullOrEmpty(ConUserpassword))
            {
                UserDialogs.Instance.Alert("Please enter Confirm Password.", "Alert", "Ok");
            }
            else if (ConUserpassword != Userpassword)
            {
                UserDialogs.Instance.Alert("Confirm Password and Password do not match.", "Alert", "Ok");
            }
            else if (!string.IsNullOrEmpty(ConUserpassword) && !string.IsNullOrEmpty(Userpassword))
            {
                if (ConUserpassword.Length < 6)
                    UserDialogs.Instance.Alert("Password must contain at least 6 characters.", "Alert", "Ok");
                else
                    isvalid = true;
            }
            else
            {
                isvalid = true;
            }
            return isvalid;
        }

        public void Clear()
        {
            UserName = Password = PhoneNumber = "";
        }
        public void ClearOtp()
        {
            OTP1 = OTP2 = OTP3 = OTP4 = "";
        }
        public void ClearProfile()
        {
            DisplayName = ""; Username = ""; Email = ""; Userpassword = ""; ConUserpassword = "";
        }

        //public async void SaveUserData(UserDB user)
        //{
        //  await  _sqliteService.SaveCurrentUser(user);
        //}

        //public async Task<UserDB> GetCurrentUser()
        //{
        //    return await _sqliteService.GetCurrentUser();
        //}



        private string privacyPolicyies { get; set; }
        public string PrivacyPolicyies
        {
            get => privacyPolicyies;
            set
            {
                privacyPolicyies = value;
                RaisePropertyChanged(() => PrivacyPolicyies);
            }
        }



        public Command GetPrivacyPolicyCommand
        {
            //get { return new Command(GetPrivacyPolicyExecution); }

            get { return new Command<string>((url) => GetPrivacyPolicyExecution(url)); }
        }


        public async void GetPrivacyPolicyExecution(string url)
        {

            Device.BeginInvokeOnMainThread(async () =>
            {
                if (url == "terms-condition")
                {
                    await App.Current.MainPage.Navigation.PushAsync(new TermsandConditionsView(), true);
                }
                else
                {
                    await App.Current.MainPage.Navigation.PushAsync(new PrivacyPolicy(), true);
                }

            });
        }




        public async void LogOutCommandExecution()
        {
            Xamarin.Essentials.Preferences.Set("IsLogin", false);

            Device.BeginInvokeOnMainThread(() =>
           {
                //App.Current.MainPage= new NavigationPage(new Views.LoginView());

                ((MasterDetailPage)App.Current.MainPage).Detail.Navigation.PushAsync(new Views.LoginView());
           });
            //Device.BeginInvokeOnMainThread(async () => 
            //{

            //await App.Current.MainPage. Navigation.PushAsync(new  LoginView(),true);// new NavigationPage(new LoginView());
            //});

            //App.LocalDatabase.DeleteItem(App.CurrentUser.ID);
            // var vv=  await _sqliteService.GetCurrentUser();

            //var CurrentUser = new UserDB()
            //{
            //    email = App.CurrentUser.email,
            //    username = App.CurrentUser.username,
            //    mobile = App.CurrentUser.mobile,
            //    device_token = App.CurrentUser.device_token,
            //    ID = App.CurrentUser.ID,
            //    api_token = App.CurrentUser.api_token,
            //    Islogin = false,
            //};
            //await _sqliteService.SaveCurrentUser(CurrentUser);
        }



        //txt1.TextChanged += (s, e) =>
        //     {
        //         if(txt1.Text.Length==0)
        //         {
        //             txt1.Focus();
        //         }
        //         else
        //         {
        //             txt2.Focus();
        //         }

        //     };
        //    txt2.TextChanged += (s, e) =>
        //    {
        //        if (txt2.Text.Length == 0)
        //        {
        //            txt1.Focus();
        //        }
        //        else
        //        {
        //            txt3.Focus();
        //        } 
        //    };
        //    txt3.TextChanged += (s, e) =>
        //    {
        //        if (txt3.Text.Length == 0)
        //        {
        //            txt2.Focus();
        //        }
        //        else
        //        {
        //            txt4.Focus();
        //        }

        //    };
        //    txt4.TextChanged += (s, e) =>
        //    {
        //        if (txt4.Text.Length == 0)
        //        {
        //            txt3.Focus();
        //        }
        //        else
        //        {
        //            txt4.Focus();
        //        }
        //    };

        #endregion
    }
}
