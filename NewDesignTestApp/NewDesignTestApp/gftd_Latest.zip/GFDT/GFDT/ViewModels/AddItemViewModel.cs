﻿using Acr.UserDialogs;
using GFDT.Models.Request;
using GFDT.Services;
using Plugin.Media;
using Plugin.Media.Abstractions;
using System;
using System.Collections.Generic;
using System.Text;
using Xamarin.Forms;

namespace GFDT.ViewModels
{
    public class AddItemViewModel : BaseViewModel
    {
        public AddItemViewModel()
        {

        }

        #region Property

        private string gftName { get; set; }
        public string GFTName
        {
            get => gftName;
            set { gftName = value; RaisePropertyChanged(() => GFTName); }
        }

        private string price { get; set; }
        public string Price
        {
            get => price;
            set { price = value; RaisePropertyChanged(() => Price); }
        }

        private string tags { get; set; }
        public string Tags
        {
            get => tags;
            set { tags = value; RaisePropertyChanged(() => Tags); }
        }

        private string storeName { get; set; }
        public string StoreName
        {
            get => storeName;
            set { storeName = value; RaisePropertyChanged(() => StoreName); }
        }
        private string storeLocation { get; set; }
        public string StoreLocation
        {
            get => storeLocation;
            set { storeLocation = value; RaisePropertyChanged(() => StoreLocation); }
        }


        private string shortDescription { get; set; }
        public string ShortDescription
        {
            get => shortDescription;
            set { shortDescription = value; RaisePropertyChanged(() => ShortDescription); }
        }

        private string imageBase64String = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAB4AAAAeCAYAAAA7MK6iAAAABHNCSVQICAgIfAhkiAAAA1hJREFUSIm1lk1rXFUYx3//J0MmCbW5sRZFoUk34q7zBcR0ZVCEBISCEDL5BM3KLCVLV51+gkQK9WWTcaF0Z1buhMm+YhTpojbkjlSNYXIeF+feebnzXuqBy8M5d+b+n9/zP+e5V0w4Zg//XJfpPXMqJiUSFUlINMyUGjTkM0enH5a/neR5Gnn38CyxYHcNdsyUCMjEMAmRxfwCbEapXLXW3Oz99LbS6YW/Oasi7kkkUUSYBN2iFmN/MoaM1KTtp++X64Meb4NFT2vI98ETgODgQHAHwN3bc8/mOMSguO4kIfjh9UcX9yYj/vrZAdJWvKuo2EM0JblA0sEfa+Xt4cRfPauBtvAsJ89Ti6QvRB7Xq9cfXdQGE3/5tIq03yYtxpdAbqaN3PP45P2zhPnWL0DSFqMonk8FmehoscJuNyGRtsrlm+ltpbHUcxc7eEhinUJWq0B7ntcP8ODsvj3Lz2tXeLz2Cj+8u4A7+YYihE754xVwnBACHkhK5+c7HY+dnbanRdLu9czzpVmxvGAsL4i35m06z6W7ACUePlkHX8Q987Irokjbs05heEYUy+s4lomYxRjNcUwiXHpy7ft/1w1stWcDTUJeGNPudvfL1RIeKj2Ek5AXmd0JOdEE5EiVEmglPyo95F3x5KNXe4TmZzrUb8wZJx9c7VQF+PG0RfWn80iqTDxLWlF6sYSH5YGEXfPlhcGdFaBs9N1//FyE4KPIKzbS2yGeTjLGeS4e/H6CtNwW6459TSTGz29d4dN35gH49e/Ayndpb7LjO9yxASd9hMPIh1Vg+t6eGngDHEKxU42JReUBHc57Ope3OxyBhsHM0cBdPZa8OPo73DDyS/zI2HyzDt5sZzwReRF4dG8vkDcvNq7WSzElapg+G3ee8/XdxnN2j//q/K47UvxfTi6Cw4yoQf6SCK0awZs9GU/r+QRvNXdvtix0CW/fTDGv9no0refj32qIKhtLaUcYYPNGHed+zPB/IA++x8dL7S/O/kP54LcDXFujPn8mXu9IfMGda9Vumf4mvHmj+lLJQ9grig4m7pCvE3SAafEFyZtIVe68NsUHfSSvE1orBN+b8pw3wff4p7QyTHQ0cV8FnqxDWAUqSAnSLRwwjnGlSA3QEZ+8PlSse/wHYF25p888FGwAAAAASUVORK5CYII=";
        public string ImageBase64String
        {
            get => imageBase64String;
            set { imageBase64String = value; RaisePropertyChanged(() => ImageBase64String); }
        }

        private ImageSource picture= "gift_img.png";
        public ImageSource Picture
        {
            get { return picture; }
            set { picture = value; RaisePropertyChanged(() => Picture); }
        }
        #endregion

        #region Commands

        public Command TakePicture => new Command(TakePhotoExcute);
        public Command PickPhotoCommand => new Command(PickPhotoExcuteAsync);
        //public Command SelectPicture => new Command(SelectPictureAsync);
        public Command AddToWishListCommand
        {
            get { return new Command(AddToWishListExecution); }
        }



        private async void TakePhotoExcute()
        {
            try
            {
                if (!CrossMedia.Current.IsCameraAvailable || !CrossMedia.Current.IsTakePhotoSupported)
                {
                    UserDialogs.Instance.Alert("No Camera", ":( No camera available.", "OK");
                    return;
                }

                var file = await CrossMedia.Current.TakePhotoAsync(new StoreCameraMediaOptions
                {
                    Directory = "Test",
                    SaveToAlbum = true,
                    CompressionQuality = 75,
                    CustomPhotoSize = 50,
                    PhotoSize = PhotoSize.MaxWidthHeight,
                    MaxWidthHeight = 2000,
                    DefaultCamera = CameraDevice.Front
                });

                if (file == null)
                    return;

                //UserDialogs.Instance.Alert("File Location", file.Path, "OK"); 

                byte[] ReceiptData = DependencyService.Get<IMediaService>().GetMediaInBytes(file.Path);
                // DependencyService.Get<IMediaService>().ResizeImage(DependencyService.Get<IMediaService>().GetMediaInBytes(file.Path), 450, 650);
                ImageBase64String = Convert.ToBase64String(ReceiptData);
                Picture = ImageSource.FromStream(() =>
                {
                    var stream = file.GetStream();
                    file.Dispose();
                    return stream;

                });
            }
            catch
            {

            }
            finally
            {

            }

        }

        private async void PickPhotoExcuteAsync()
        {
            try
            {

                if (!CrossMedia.Current.IsPickPhotoSupported)
                {
                    UserDialogs.Instance.Alert("Photos Not Supported", ":( Permission not granted to photos.", "OK");
                    return;
                }
                var file = await CrossMedia.Current.PickPhotoAsync(new PickMediaOptions
                {
                    PhotoSize = PhotoSize.Medium,
                });


                if (file == null)
                    return;

                byte[] ReceiptData = DependencyService.Get<IMediaService>().GetMediaInBytes(file.Path);
                var x = DependencyService.Get<IMediaService>().ResizeImage(ReceiptData, 120, 120);
                ImageBase64String = Convert.ToBase64String(ReceiptData);

                Picture = ImageSource.FromStream(() =>
                {
                    var stream = file.GetStream();
                    file.Dispose();
                    return stream;
                });
            }
            catch
            {
                 
            }
            finally
            {
                
            }


        }

        #endregion

        #region Command Execution 

        //public async void TakePictureAsync()
        //{
        //    //await CrossMedia.Current.Initialize();
        //    //if (!CrossMedia.Current.IsPickPhotoSupported || CrossMedia.Current.IsCameraAvailable)
        //    //{
        //    //    Xamarin.Forms.Device.BeginInvokeOnMainThread(() =>
        //    //    {
        //    //        //UserDialogs.Instance.Alert("Photos Not Supported", ":( Permission not granted to photos.", "OK");
        //    //        return;
        //    //    });
        //    //}
        //    //var file = await CrossMedia.Current.TakePhotoAsync(new Plugin.Media.Abstractions.StoreCameraMediaOptions
        //    //{
        //    //    Directory = "TimePeace App",
        //    //    Name = "Aes_" + DateTime.Now.ToString("yyyyMMdd") + ".jpg",
        //    //    DefaultCamera = Plugin.Media.Abstractions.CameraDevice.Rear,
        //    //    //SaveToAlbum = false
        //    //});
        //    //if (file == null) return;
        //    /////Mohit
        //    //var cropedBytes = await CrossXMethod.Current.CropImageFromOriginalToBytes(file.Path);
        //    //if (cropedBytes != null)
        //    //{
        //    //    Picture = ImageSource.FromStream(() =>
        //    //    {
        //    //        file.Dispose();
        //    //        var cropedImage = new MemoryStream(cropedBytes);
        //    //        return cropedImage;
        //    //    });
        //    //    ImageBase64 = Convert.ToBase64String(cropedBytes);
        //    //}
        //    //else
        //    //{
        //    //    file.Dispose();
        //    //    return;
        //    //}
        //    ////byte[] ReceiptData = DependencyService.Get<IMediaService>().ResizeImage(cropedBytes, 300, 400);
        //    /////Mohit
        //    ////byte[] ReceiptData = DependencyService.Get<IMediaService>().ResizeImage(DependencyService.Get<IMediaService>().GetMediaInBytes(file.Path), 450, 650);
        //    ////ImageBase64 = Convert.ToBase64String(ReceiptData);
        //    ////Picture = ImageSource.FromStream(() => new MemoryStream(ReceiptData));

        //    //byte[] resizedImage = DependencyService.Get<IMediaService>().ResizeImage(cropedBytes, 400, 400);
        //    //ImageBase64 = Convert.ToBase64String(resizedImage);
        //    //Picture = ImageSource.FromStream(() => new MemoryStream(cropedBytes));
        //}
        //public async void SelectPictureAsync()
        //{
        //    //await CrossMedia.Current.Initialize();
        //    //var file = await CrossMedia.Current.PickPhotoAsync(new Plugin.Media.Abstractions.PickMediaOptions
        //    //{
        //    //    PhotoSize = Plugin.Media.Abstractions.PhotoSize.Custom
        //    //});
        //    //if (file == null) return;
        //    /////Mohit
        //    //var cropedBytes = await CrossXMethod.Current.CropImageFromOriginalToBytes(file.Path);
        //    //if (cropedBytes != null)
        //    //{
        //    //    Picture = ImageSource.FromStream(() =>
        //    //    {
        //    //        file.Dispose();
        //    //        var cropedImage = new MemoryStream(cropedBytes);
        //    //        return cropedImage;
        //    //    });
        //    //    ImageBase64 = Convert.ToBase64String(cropedBytes);
        //    //}
        //    //else
        //    //{
        //    //    file.Dispose();
        //    //    return;
        //    //}
        //    /////Mohit
        //    ////byte[] ReceiptData = DependencyService.Get<IMediaService>().ResizeImage(cropedBytes, 450, 650);
        //    ////byte[] ReceiptData = DependencyService.Get<IMediaService>().ResizeImage(DependencyService.Get<IMediaService>().GetMediaInBytes(file.Path), 450, 650);
        //    //byte[] resizedImage = DependencyService.Get<IMediaService>().ResizeImage(cropedBytes, 400, 400);
        //    //ImageBase64 = Convert.ToBase64String(resizedImage);
        //    ////ImageBase64 = Convert.ToBase64String(cropedBytes);
        //    //Picture = ImageSource.FromStream(() => new MemoryStream(cropedBytes));
        //}


        void AddToWishListExecution()
        {
            if (IsValid())
            {
                UserDialogs.Instance.ShowLoading();

                var req = new AddItemRequest
                {
                    store_name = StoreName,
                    description = ShortDescription,
                    image = ImageBase64String,
                    name = GFTName,
                    price = Convert.ToInt32(Price),
                    store_location = StoreLocation,
                    tag = Convert.ToInt32(Tags)
                };
                userManager.AddToWishList(req, () =>
                {
                    UserDialogs.Instance.HideLoading();
                    var v = userManager.AddItemResponse;
                    if (v.status == true)
                    {
                        UserDialogs.Instance.Alert(v.message, "Alert", "Ok");
                        Clear();
                        //Anupam
                        Device.BeginInvokeOnMainThread(() =>
                        {
                            App.Locator.SendAGFTViewModel.WishListCommand.Execute(null);
                            App.Locator.SendAGFTViewModel.GetListCommand.Execute(null);
                        });
                    }
                    else
                    {
                        UserDialogs.Instance.Alert(v.message, "Alert", "Ok");
                    }

                },
               (failure) =>
               {
                   UserDialogs.Instance.HideLoading();
                   UserDialogs.Instance.Alert(failure.message, "Alert", "Ok");
               });
            }


        }

        #endregion

        #region Methods
        public bool IsValid()
        {
            bool isvalid = false;

            if (string.IsNullOrEmpty(GFTName))
            {
                UserDialogs.Instance.Alert("Please enter GFT Name.", "Alert", "Ok");
            }
            else if (string.IsNullOrEmpty(Price))
            {
                UserDialogs.Instance.Alert("Please enter Price.", "Alert", "Ok");
            }
            else if (string.IsNullOrEmpty(Tags))
            {
                UserDialogs.Instance.Alert("Please enter Tags.", "Alert", "Ok");
            }
            else if (string.IsNullOrEmpty(StoreName))
            {
                UserDialogs.Instance.Alert("Please enter Store Name.", "Alert", "Ok");
            }
            else if (string.IsNullOrEmpty(StoreLocation))
            {
                UserDialogs.Instance.Alert("Please enter Store Location.", "Alert", "Ok");
            }
            else if (string.IsNullOrEmpty(ShortDescription))
            {
                UserDialogs.Instance.Alert("Please enter Short Description.", "Alert", "Ok");
            }
            //else if (string.IsNullOrEmpty(ImageBase64String))
            //{
            //    UserDialogs.Instance.Alert("Please select Image.", "Alert", "Ok");
            //}
            else
            {
                isvalid = true;
            }
            return isvalid;
        }

        public void Clear()
        {
            StoreName = ShortDescription = ImageBase64String = GFTName = Price = StoreLocation = Tags = "";
        }
        #endregion

    }
}
