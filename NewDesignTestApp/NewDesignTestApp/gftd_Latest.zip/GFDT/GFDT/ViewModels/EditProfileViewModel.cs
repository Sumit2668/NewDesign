﻿using Acr.UserDialogs;
using GalaSoft.MvvmLight.Command;
using GFDT.Models;
using GFDT.Models.Request;
using GFDT.Models.Response;
using GFDT.Services;
using Plugin.Media;
using Plugin.Media.Abstractions;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Text;
using System.Text.RegularExpressions;
using Xamarin.Forms;

namespace GFDT.ViewModels
{
    public class EditProfileViewModel : BaseViewModel
    {
        public EditProfileViewModel()
        {//Anupam
            Picture = ImageSource.FromFile("edit_pro_screen.png");
        }

        #region Property 


        bool isBusy = false;
        public bool IsBusy
        {
            get => isBusy;
            set { isBusy = value; RaisePropertyChanged(() => IsBusy); }
        }
        private string imageBase64;
        public string ImageBase64
        {
            get { return this.imageBase64; }
            set
            {
                if (Equals(value, this.imageBase64))
                {
                    return;
                }
                this.imageBase64 = value;
                RaisePropertyChanged(() => ImageBase64);
            }
        }

        private ImageSource picture;
        public ImageSource Picture
        {
            get { return picture; }
            set { picture = value; RaisePropertyChanged(() => Picture); }
        }
        private UserData currentUser { get; set; }
        public UserData CurrentUser
        {
            get => currentUser;
            set { currentUser = value; RaisePropertyChanged(() => CurrentUser); }
        }
        private ObservableCollection<MyWishlist> myWishlist { get; set; }
        public ObservableCollection<MyWishlist> MyWishlist
        {
            get => myWishlist;
            set { myWishlist = value; RaisePropertyChanged(() => MyWishlist); }
        }
        private ObservableCollection<ProductDetails> productDetails { get; set; }
        public ObservableCollection<ProductDetails> ProductDetails
        {
            get => productDetails;
            set { productDetails = value; RaisePropertyChanged(() => ProductDetails); }
        }

        //Anupam
        private string imgUrl { get; set; }
        public string ImgUrl
        {
            get => imgUrl;
            set { imgUrl = value; RaisePropertyChanged(() => ImgUrl); }
        }
          private string displayName { get; set; }
        public string DisplayName
        {
            get => displayName;
            set { displayName = value; RaisePropertyChanged(() => DisplayName); }
        }

        private string userName { get; set; }
        public string UserName
        {
            get => userName;
            set { userName = value; RaisePropertyChanged(() => UserName); }
        }

        private string email { get; set; }
        public string Email
        {
            get => email;
            set { email = value; RaisePropertyChanged(() => Email); }
        }

        private string password { get; set; }
        public string Password
        {
            get => password;
            set { password = value; RaisePropertyChanged(() => Password); }
        }

        private string confirmPassword { get; set; }
        public string ConfirmPassword
        {
            get => confirmPassword;
            set { confirmPassword = value; RaisePropertyChanged(() => ConfirmPassword); }
        }


        #endregion

        #region Commands 
        public Command UpdateProfileCommand
        {
            get { return new Command(UpdateProfileExecution); }
        }
        public Command ProfileinfoCommand
        {
            get { return new Command(ProfileinfoExecution); }
        }
        //Anupam

        public Command SetProfileInfoCommand
        {
            get { return new Command(SetProfileInfoExecution); }
        }
        public RelayCommand TakePhotoCommand => new RelayCommand(() => TakePhotoExcute());
        public RelayCommand PickPhotoCommand => new RelayCommand(() => PickPhotoExcuteAsync());


        #endregion

        #region Command Execution  

        //Anupam
        private async void TakePhotoExcute()
        {
            try
            {
                IsBusy = true;
                if (!CrossMedia.Current.IsCameraAvailable || !CrossMedia.Current.IsTakePhotoSupported)
                {
                    UserDialogs.Instance.Alert("No Camera", ":( No camera available.", "OK");
                    return;
                }

                var file = await CrossMedia.Current.TakePhotoAsync(new StoreCameraMediaOptions
                {
                    Directory = "Test",
                    SaveToAlbum = true,
                    CompressionQuality = 75,
                    CustomPhotoSize = 50,
                    PhotoSize = PhotoSize.MaxWidthHeight,
                    MaxWidthHeight = 2000,
                    DefaultCamera = CameraDevice.Front
                });

                if (file == null)
                    return;

                //UserDialogs.Instance.Alert("File Location", file.Path, "OK"); 

                byte[] ReceiptData = DependencyService.Get<IMediaService>().GetMediaInBytes(file.Path);
                // DependencyService.Get<IMediaService>().ResizeImage(DependencyService.Get<IMediaService>().GetMediaInBytes(file.Path), 450, 650);
                ImageBase64 = Convert.ToBase64String(ReceiptData);
                Picture = ImageSource.FromStream(() =>
                {
                    var stream = file.GetStream();
                    file.Dispose();
                    return stream;

                });
            }
            catch
            {
                IsBusy = false;
            }
            finally
            {
                IsBusy = false;
            }

        }

        private async void PickPhotoExcuteAsync()
        {
            try
            {
                IsBusy = true;
                if (!CrossMedia.Current.IsPickPhotoSupported)
                {
                    UserDialogs.Instance.Alert("Photos Not Supported", ":( Permission not granted to photos.", "OK");
                    return;
                }
                var file = await CrossMedia.Current.PickPhotoAsync(new PickMediaOptions
                {
                    PhotoSize = PhotoSize.Medium,
                });


                if (file == null)
                    return;

                byte[] ReceiptData = DependencyService.Get<IMediaService>().GetMediaInBytes(file.Path);
                var x = DependencyService.Get<IMediaService>().ResizeImage(ReceiptData, 120, 120);
                ImageBase64 = Convert.ToBase64String(ReceiptData);

                Picture = ImageSource.FromStream(() =>
                {
                    var stream = file.GetStream();
                    file.Dispose();
                    return stream;
                });
            }
            catch
            {
                IsBusy = false;
            }
            finally
            {
                IsBusy = false;
            }


        }
        void UpdateProfileExecution()
        {
            if (IsValid())
            {
                UserDialogs.Instance.ShowLoading();

                var req = new EditProfileRequest
                {
                    profile_type=2,
                    email = Email,
                    username = UserName,
                    name = DisplayName,
                    image=string.IsNullOrEmpty(ImageBase64)? "iVBORw0KGgoAAAANSUhEUgAAAHwAAAB8CAMAAACcwCSMAAAAZlBMVEUAAAD///+cnJz7+/vz8/MdHR329vbw8PBRUVHh4eEaGhqsrKzn5+dZWVnk5OQyMjLZ2dmOjo6ysrIoKCjR0dFiYmKjo6NKSkoNDQ3ExMQ4ODi5ubmHh4cWFhbLy8tBQUF6enpvb2/Qp8GOAAAFzUlEQVRogcWb56KyOhBFIyBFQUGkiQXe/yVvQPFQUvYEvN/+q7CYlMnMJGG7fyhm8pDrnZ71Mbd65cf6efLc/wPuhlXeRLf0wUZ6pLeoyauQ+gUkuFPd/ZRJlfr3yvkN3L20pRw8qGwvuP0g3K0aPXhQU4F8CB5aLxzd6WWFG8HDRNHPMqUJgNfCPRP0G++thNtHQ3SPP9pr4NfCHN2puBrDvWYdulOjansFvLqtZzN2qwzgtrUFupMl7XkZPGy3YjPWymadBB4TvYpar5gCrwEvTlFZ4/DjtuhORxT+A7aYLoD/hC2kL+E/YovoC/jlV2zGLjr483dsxp5qeLBiEdMrDVRwz/8lmzHfU8DvlDelLz/yX7SmusvhhIEe5XHYLRh2GOcRgX6UwWPUqT6s08SCUwK74zKWwFELmuUqFTYoPRLDwQX8JY4O6jNIt0Tw00P/IJcvWR53MThTHn9d9gdvoEezQAR+Nz1Ib5bwK/TgSxUPBmDQ9w1pB7gNffZDbndvANhzQ1A3wGvoMUuG/SiH3sKGuOYDd6FpVuiybxtLMiJ3AscMX6yJC4ELcj2BQ4b7+rKDg425aAzHhrquxzsl0Js+A/4Nb5AHynksIFKFefnmD25DD9y0+TbXCfSy9heODbcIqbQ44OpUf+EZ9P9GjX3LbjB4NsA97P8JAoeDIe8DBycnMtjh4d77jA4OZsPbWt6+4R44QLE+R/P6s9fD0Txh09HeZxAMXoq2neeM5T0cLoBs6OFY3+ls58AVkA19O9fL4fATnHP4+nb38FpOeuJwvKGA9Rxz1L3KisMJOVKhqaXudpQi1pHDKcU+nZ8hFQ4tDm8I/3/IMoa3CD3IOqfF4AytV6Eq4RMrhxGH057I5PSQZAafaxxOLIQUsrwhoNbm0x2z99RnJFkquWK6t+lwVjZL44OG+hZDODf+PsXHd4OXmMK59ZEV9Ju3rhfnkVmN2hjeKS2yNivMC3er4Gv1r+E7OPSYqTy//CiLipvp15+5kyHv2z3SqLWqZ8xHnG27Thhfq2PTFlhVYqSCw7F0ZdA+S56xIJK0w+ulIXpqDqfUW8/WVRXCnmqKJXcOR4NX7lrUO6O9wiNcuM45HIx8brN6q1R2lWHdX3P49QD88ZCA6E5ujVh/uHK4B5RRsqc2eps2vqW3iOcgbGdrY4CDcEdOrUA79CK7y1h0cX5GaPGRjhrjkz5d0qTnidHJI66ruj8vPTxQfmJuiOYKVOPuEPRwV/Uf8fYvKE8xnHz3XZmQd3qpT5CUUmTrXf7RweX1xxVt/rFdumxdP3BbtqpiVRilZFuUZ/sDl7V7azrOx6oUdvXwQPxx6m0FVGLLgi9cnDIZ+DWRhFXw1+4PLlpWXzR3LpfIieUjuCMYFqtm+ETLdk2dEVzQMe1mbEHE8JlGH/hiRpSKI01UufMVbtjEH7a25pFcgVT8UM3LPsMu+gAPHuLfN1E8bdfv1uB3O3PW6xu2+qLdv47zC3cmPvYBBKoENeN3n787ZH+7yJMxuVeXnaiajKi/OTzavB8vf4dNLZ9svIyODozg8XjMyY/vGSgYuZlxKW98ZmJcPyxbazMlY+8+Ll1PjqrQckYjZTsZPDTN1WGdQymcWDyla+a0Zwez4JTVTLOYcH4krfkle745tjiM98NzYf6ctYA7P6MvDx4sz0CiZ23I7GWxXHD68/QTui/IdUXnXsOVp9pFEm5RCE/8KlNHI/nC/ENy0Jp0HlEvSVwkgdv5hr6ulKUf0sP1z838/Fm6ASy/VqDK7CmK5HGw6kJFTq7lLvVQpfjKqySn1Qu8upKluURTr7rRcdPke7rrQ45lvImSWrpTZPqLU0b3prCbU8iVsZBufQrdGcMuy7kX0ryLwNt68DXB0ALH3g27KEeCc5cbW5FmJ2kfWTEh26BdDbXDOsluwlrt4ZYldUjLc+iXYm0vrvOk9c/7Q6/92W+TvI49eoJldCP38xUfmb/hPxbhSmN+ggQuAAAAAElFTkSuQmCC" : ImageBase64,
                    password=Password== "~~~~~~" ? null:Password, 
                   
                };
                userManager.UpdateProfile(req, () =>
                {
                    UserDialogs.Instance.HideLoading();
                    var v = userManager.UpdateProfileResponse;
                    if (v.status)
                    {
                        UserDialogs.Instance.Alert(v.message, "Alert", "Ok");
                        Clear();
                        SetProfileInfoCommand.Execute(null);
                        App.Locator.HomeViewModel.ProfileinfoCommand.Execute(null);
                        
                        //Device.BeginInvokeOnMainThread(() =>
                        //{
                        //    App.Current.MainPage = new NavigationPage(new Views.HomeView());
                        //});
                    }
                    else
                    {
                        UserDialogs.Instance.Alert(v.message, "Alert", "Ok");
                    }

                },
               (failure) =>
               {
                   UserDialogs.Instance.HideLoading();
                   UserDialogs.Instance.Alert(failure.message, "Alert", "Ok");
               });
            }


        }

        public void ProfileinfoExecution()
        {
            try
            {
                UserDialogs.Instance.ShowLoading();
                userManager.ProfileInfo(() =>
                {
                    UserDialogs.Instance.HideLoading();
                    var profileInfo = userManager.ProfileInfoResponse;
                    CurrentUser = new UserData();
                    if (profileInfo.status)
                    {
                        App.Locator.HomeViewModel.ProfileinfoCommand.Execute(null);
                        SetProfileData(profileInfo);

                        Device.BeginInvokeOnMainThread(async () =>
                        {
                            try
                            { 
                               await ((MasterDetailPage)App.Current.MainPage).Detail.Navigation.PushAsync(new Views.EditProfileView());
                            }
                            catch (Exception ex)
                            {
                               await App.Current.MainPage.Navigation.PushAsync(new Views.EditProfileView());
                            }
                           
                        });

                    }

                },
                (failure) =>
                {
                    UserDialogs.Instance.HideLoading();
                });
            }
            catch (Exception ex)
            {

            }
        }
        //Anupam
        public void SetProfileInfoExecution()
        {
            try
            {
                UserDialogs.Instance.ShowLoading();
                userManager.ProfileInfo(() =>
                {
                    UserDialogs.Instance.HideLoading();
                    var profileInfo = userManager.ProfileInfoResponse;
                    CurrentUser = new UserData();
                    if (profileInfo.status)
                    {
                        SetProfileData(profileInfo);
                    }


                },
                (failure) =>
                {
                    UserDialogs.Instance.HideLoading();
                });
            }
            catch (Exception ex)
            {

            }
        }

        private void SetProfileData(ProfileInfoResponse profileInfo)
        {
            Email = profileInfo.data.email;
            UserName = profileInfo.data.username;
            DisplayName = profileInfo.data.name;
            Password = ConfirmPassword = "~~~~~~";
            ImgUrl = profileInfo.data.image;
            CurrentUser = profileInfo.data;
            MyWishlist = profileInfo.data.my_wishlist;
            //ProductDetails = profileInfo.data.my_wishlist;

            if (!profileInfo.data.image.StartsWith("http"))
            {
                profileInfo.data.image = "https://avatars3.githubusercontent.com/u/1816448?s=400&v=4";
            }
            Device.BeginInvokeOnMainThread( () =>
            {
                Picture = new UriImageSource
                {
                    Uri = new Uri(profileInfo.data.image),
                    CachingEnabled = true,
                    CacheValidity = new TimeSpan(5, 0, 0, 0)
                };
            });
        }


        #endregion

        #region Methods
        public bool IsValid()
        {
            bool isvalid = false;

            if (string.IsNullOrEmpty(DisplayName))
            {
                UserDialogs.Instance.Alert("Please enter Display Name.", "Alert", "Ok");
            }
            else if (string.IsNullOrEmpty(UserName))
            {
                UserDialogs.Instance.Alert("Please enter User Name.", "Alert", "Ok");
            }
            else if (string.IsNullOrEmpty(Email))
            {
                UserDialogs.Instance.Alert("Please enter Email.", "Alert", "Ok");
            }
            else if (!IsEmailValid(Email))
            {
                UserDialogs.Instance.Alert("Please enter valid Email.", "Alert", "Ok");
            }
            else if (string.IsNullOrEmpty(Password))
            {
                UserDialogs.Instance.Alert("Please enter Password.", "Alert", "Ok");
            }
            else if (string.IsNullOrEmpty(ConfirmPassword))
            {
                UserDialogs.Instance.Alert("Please enter ConfirmPassword.", "Alert", "Ok");
            }
            else if (ConfirmPassword != Password)
            {
                UserDialogs.Instance.Alert("Confirm Password and Password do not match.", "Alert", "Ok");
            }
            else
            {
                isvalid = true;
            }
            return isvalid;
        }

        private bool IsEmailValid(string email)
        {

            Regex regex = new Regex(@"^([\w\.\-]+)@([\w\-]+)((\.(\w){2,3})+)$");
            Match match = regex.Match(email);
            if (match.Success)
                return true;
            else
                return false;
        }

        public void Clear()
        {
            //StoreName = ShortDescription = ImageBase64String = CurrentUser = Price = StoreLocation = Tags = "";
        }
        #endregion


    }
}
