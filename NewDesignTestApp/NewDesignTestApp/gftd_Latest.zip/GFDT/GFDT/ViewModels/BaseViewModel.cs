﻿using System;
using GalaSoft.MvvmLight;
using GalaSoft.MvvmLight.Ioc;
using GFDT.Managers.SettingsManager;
using GFDT.Managers.UserManager;

namespace GFDT.ViewModels
{
    public class BaseViewModel:ViewModelBase
    {
        protected readonly IUserManager userManager;
        internal readonly ISettingsManager settingsManager;
        public BaseViewModel()
        {
            userManager = SimpleIoc.Default.GetInstance<IUserManager>();
            settingsManager = SimpleIoc.Default.GetInstance<ISettingsManager>();
        }
    }
}
