﻿using Acr.UserDialogs;
using GalaSoft.MvvmLight.Command;
using GFDT.Enums;
using GFDT.Models.Request;
using GFDT.Models.Response;
using GFDT.Services;
using Plugin.Media;
using Plugin.Media.Abstractions;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Text;
using Xamarin.Forms;

namespace GFDT.ViewModels
{
    public class SendAGFTViewModel : BaseViewModel
    {
        public SendAGFTViewModel()
        {
            Picture = ImageSource.FromFile("gift_img.png"); 
           // WishListCommand.Execute(null);
           // GetListCommand.Execute(null);
        }


        #region Property

        bool isBusy = false;
        public bool IsBusy
        {
            get => isBusy;
            set { isBusy = value; RaisePropertyChanged(() => IsBusy); }
        }

        private string recipient { get; set; }
        public string Recipient
        {
            get => recipient;
            set { recipient = value; RaisePropertyChanged(() => Recipient); }
        }
        private string wishListGFT { get; set; }
        public string WishListGFT
        {
            get => wishListGFT;
            set { wishListGFT = value; RaisePropertyChanged(() => WishListGFT); }
        }

        private string ownGFT { get; set; }
        public string OwnGFT
        {
            get => ownGFT;
            set { ownGFT = value; RaisePropertyChanged(() => OwnGFT); }
        }


        private string price { get; set; }
        public string Price
        {
            get => price;
            set { price = value; RaisePropertyChanged(() => Price); }
        }

        private string tax { get; set; }
        public string Tax
        {
            get => tax;
            set { tax = value; RaisePropertyChanged(() => Tax); }
        }

        private string tip { get; set; }
        public string Tip
        {
            get => tip;
            set { tip = value; RaisePropertyChanged(() => Tip); }
        }

        private string wishId { get; set; }
        public string WishId
        {
            get => wishId;
            set { wishId = value; RaisePropertyChanged(() => WishId); }
        }
        private string productId { get; set; }
        public string ProductId
        {
            get => productId;
            set { productId = value; RaisePropertyChanged(() => ProductId); }
        }


        private string totalPrice { get; set; }
        public string TotalPrice
        {
            get => totalPrice;
            set { totalPrice = value; RaisePropertyChanged(() => TotalPrice); }
        }

        private string privacy { get; set; }
        public string Privacy
        {
            get => privacy;
            set { privacy = value; RaisePropertyChanged(() => Privacy); }
        }

        private string message { get; set; }
        public string Message
        {
            get => message;
            set { message = value; RaisePropertyChanged(() => Message); }
        }

        private int giftedUserId { get; set; }
        public int GiftedUserId
        {
            get => giftedUserId;
            set { giftedUserId = value; RaisePropertyChanged(() => GiftedUserId); }
        }

        private string imageBase64;
        public string ImageBase64
        {
            get { return this.imageBase64; }
            set
            {
                if (Equals(value, this.imageBase64))
                {
                    return;
                }
                this.imageBase64 = value;
                RaisePropertyChanged(() => ImageBase64);
            }
        }

        private ImageSource picture;
        public ImageSource Picture
        {
            get { return picture; }
            set { picture = value; RaisePropertyChanged(() => Picture); }
        }

        private ObservableCollection<MyWishStoreList> wishStoreList;
        public ObservableCollection<MyWishStoreList> WishStoreList
        {
            get { return wishStoreList; }
            set { wishStoreList = value; RaisePropertyChanged(() => WishStoreList); }
        }

        private ObservableCollection<GetList> getWishList;
        public ObservableCollection<GetList> GetWishList
        {
            get { return getWishList; }
            set { getWishList = value; RaisePropertyChanged(() => GetWishList); }
        } 
        #endregion

        #region Commands 
        public Command SubmitCommand
        {
            get { return new Command(SubmitExecution); }
        }
          public Command WishListCommand
        {
            get { return new Command(WishListCommandExecution); }
        }
          public Command GetListCommand
        {
            get { return new Command(GetListExecution); }
        }


        #endregion

        #region Command Execution 

        public RelayCommand TakePhotoCommand => new RelayCommand(() => TakePhotoExcute());
        public RelayCommand PickPhotoCommand => new RelayCommand(() => PickPhotoExcuteAsync());
        private async void TakePhotoExcute()
        {
            try
            {
                IsBusy = true;
                if (!CrossMedia.Current.IsCameraAvailable || !CrossMedia.Current.IsTakePhotoSupported)
                {
                    UserDialogs.Instance.Alert("No Camera", ":( No camera available.", "OK");
                    return;
                }

                var file = await CrossMedia.Current.TakePhotoAsync(new StoreCameraMediaOptions
                {
                    Directory = "Test",
                    SaveToAlbum = true,
                    CompressionQuality = 75,
                    CustomPhotoSize = 50,
                    PhotoSize = PhotoSize.MaxWidthHeight,
                    MaxWidthHeight = 2000,
                    DefaultCamera = CameraDevice.Front
                });

                if (file == null)
                    return;

                //UserDialogs.Instance.Alert("File Location", file.Path, "OK"); 

                byte[] ReceiptData = DependencyService.Get<IMediaService>().GetMediaInBytes(file.Path);
                // DependencyService.Get<IMediaService>().ResizeImage(DependencyService.Get<IMediaService>().GetMediaInBytes(file.Path), 450, 650);
                ImageBase64 = Convert.ToBase64String(ReceiptData);
                Picture = ImageSource.FromStream(() =>
                {
                    var stream = file.GetStream();
                    file.Dispose();
                    return stream;

                });
            }
            catch
            {
                IsBusy = false;
            }
            finally
            {
                IsBusy = false;
            }

        }

        private async void PickPhotoExcuteAsync()
        {
            try
            {
                IsBusy = true;
                if (!CrossMedia.Current.IsPickPhotoSupported)
                {
                    UserDialogs.Instance.Alert("Photos Not Supported", ":( Permission not granted to photos.", "OK");
                    return;
                }
                var file = await CrossMedia.Current.PickPhotoAsync(new PickMediaOptions
                {
                    PhotoSize = PhotoSize.Medium,
                });


                if (file == null)
                    return;

                byte[] ReceiptData = DependencyService.Get<IMediaService>().GetMediaInBytes(file.Path);
              var x =   DependencyService.Get<IMediaService>().ResizeImage(ReceiptData, 120, 120);
                ImageBase64 = Convert.ToBase64String(ReceiptData);

                Picture =  ImageSource.FromStream(() =>
                {
                    var stream = file.GetStream();
                    file.Dispose();
                    return stream;
                });
            }
            catch
            {
                IsBusy = false;
            }
            finally
            {
                IsBusy = false;
            }


        }
        void SubmitExecution()
        {
            if (IsValid())
            {
                UserDialogs.Instance.ShowLoading();

                var req = new SendGiftRequest
                {
                    gifted_user_id = Convert.ToInt32(App.UserId),
                    message = Message,
                    price = Price,
                    privacy = Privacy,
                    product_id = Convert.ToInt32(ProductId),
                    tax = Tax,
                    tip = Convert.ToInt32(Tip),
                    type = 1,
                    wish_id = Convert.ToInt32(WishId),
                    image=ImageBase64
                };
                userManager.SendGift(req, () =>
                {
                    UserDialogs.Instance.HideLoading();
                    var v = userManager.SendGiftResponse;
                    if (v.status == true)
                    {
                        UserDialogs.Instance.Alert(v.message, "Alert", "Ok");
                        Clear();
                        //Device.BeginInvokeOnMainThread(() =>
                        //{
                        //    App.Current.MainPage = new NavigationPage(new Views.HomeView());
                        //});
                    }
                    else
                    {
                        UserDialogs.Instance.Alert(v.message, "Alert", "Ok");
                    }

                },
               (failure) =>
               {
                   UserDialogs.Instance.HideLoading();
                   UserDialogs.Instance.Alert(failure.message, "Alert", "Ok");
               });
            }


        }

        void WishListCommandExecution()
        {
            try
            {
                //UserDialogs.Instance.ShowLoading();

                userManager.GetStoreWisheshItemDetail((int)GetListEnum.MyWishList, () =>
                {
                   // UserDialogs.Instance.HideLoading();
                    WishStoreList = new ObservableCollection<MyWishStoreList>();
                    var getitemdata = userManager.GetListItemResponce;
                    //Anupam
                    if (getitemdata != null)
                    {
                        foreach (var item in getitemdata.data)
                        {
                            WishStoreList.Add(new MyWishStoreList()
                            {
                                id = item.id,
                                created_at = item.created_at,
                                product_category = item.product_category,
                                product_description = item.product_description,
                                product_image = item.product_image,
                                product_name = item.product_name,
                                product_price = item.product_price,
                                product_tag = item.product_tag,
                                product_tax = item.product_tax == null ? "0" : item.product_tax,
                                store_location = item.store_location,
                                store_name = item.store_name,
                                updated_at = item.updated_at,
                                user_id = item.user_id
                            });
                        }
                    }
                },
                (failure) =>
                {
                  //  UserDialogs.Instance.HideLoading();
                });
            }
            catch (Exception ex)
            {
              //  UserDialogs.Instance.HideLoading();

            }


        }

        void GetListExecution()
        {
            try
            {
                //UserDialogs.Instance.ShowLoading();
                var parReq = "6";// + App.UserId;
                userManager.GetList(parReq, () =>
                {
                    GetWishList = new ObservableCollection<GetList>();
                    var getitemdata = userManager.GetListResponse;
                    //Anupam
                    if (getitemdata != null)
                    {  
                        foreach (var item in getitemdata.data)
                        {
                            GetWishList.Add(new GetList()
                            {
                                id = item.id,
                                created_at = item.created_at,
                                product_category = item.product_category,
                                product_description = item.product_description,
                                product_image = item.product_image,
                                product_name = item.product_name,
                                product_price = item.product_price,
                                product_tag = item.product_tag,
                                product_tax = item.product_tax,
                                store_location = item.store_location,
                                store_name = item.store_name,
                                updated_at = item.updated_at,
                                user_id = item.user_id
                            });
                        }
                    }
                },
                (failure) =>
                {
                      UserDialogs.Instance.HideLoading();
                });
            }
            catch (Exception ex)
            {
                 UserDialogs.Instance.HideLoading();

            }


        }

        #endregion

        #region Methods
        public bool IsValid()
        {
            bool isvalid = false;

            if (string.IsNullOrEmpty(Recipient))
            {
                UserDialogs.Instance.Alert("Please enter Recipient.", "Alert", "Ok");
            }
            //else if (string.IsNullOrEmpty(WishListGFT))
            //{
            //    UserDialogs.Instance.Alert("Please select Wish GFT.", "Alert", "Ok");
            //}
            //else if (string.IsNullOrEmpty(OwnGFT))
            //{
            //    UserDialogs.Instance.Alert("Please Enter Own GFT.", "Alert", "Ok");
            //}
            else if (string.IsNullOrEmpty(Price))
            {
                UserDialogs.Instance.Alert("Please enter Price.", "Alert", "Ok");
            }
            else if (string.IsNullOrEmpty(Tax))
            {
                UserDialogs.Instance.Alert("Please select Tax.", "Alert", "Ok");
            }
            else if (string.IsNullOrEmpty(Tip))
            {
                UserDialogs.Instance.Alert("Please select Tip.", "Alert", "Ok");
            }
            else if (string.IsNullOrEmpty(TotalPrice))
            {
                UserDialogs.Instance.Alert("Please enter Total Price.", "Alert", "Ok");
            }
             else if (string.IsNullOrEmpty(Privacy))
            {
                UserDialogs.Instance.Alert("Please enter  Privacy.", "Alert", "Ok");
            }
            else if (string.IsNullOrEmpty(Message))
            {
                UserDialogs.Instance.Alert("Please enter  Message.", "Alert", "Ok");
            } 
            else
            {
                isvalid = true;
            }
            return isvalid;
        }

        public void Clear()
        {
             Message = Price  = Privacy = Tax =Tip  = "";
        }
        #endregion

    }
}
