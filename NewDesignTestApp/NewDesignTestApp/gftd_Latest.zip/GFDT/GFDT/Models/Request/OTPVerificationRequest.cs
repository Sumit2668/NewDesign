﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GFDT.Models.Request
{
    public class OTPVerificationRequest
    {
        public string mobile { get; set; }
        public string otp { get; set; }
    }
}
