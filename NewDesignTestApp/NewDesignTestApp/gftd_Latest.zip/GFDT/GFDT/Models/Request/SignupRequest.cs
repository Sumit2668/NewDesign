﻿using System;
using System.Collections.Generic;
using System.Text;

namespace GFDT.Models.Request
{
    public class SignupRequest
    {
        public string mobile { get; set; }
        public string device_token { get; set; }
    }
}
