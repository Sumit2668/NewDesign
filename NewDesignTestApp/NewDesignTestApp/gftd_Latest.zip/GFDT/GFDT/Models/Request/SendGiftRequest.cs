﻿using System;
using System.Collections.Generic;
using System.Text;

namespace GFDT.Models.Request
{
   public class SendGiftRequest
    {
        public int gifted_user_id { get; set; }
        public int type { get; set; }
        public string price { get; set; }
        public string tax { get; set; }
        public string privacy { get; set; }
        public string message { get; set; }
        public string image { get; set; }
        public int tip { get; set; }
        public int product_id { get; set; }
        public int wish_id { get; set; }
    }
}
