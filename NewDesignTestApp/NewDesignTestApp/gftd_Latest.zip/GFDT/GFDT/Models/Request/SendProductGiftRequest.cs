﻿using System;
using System.Collections.Generic;
using System.Text;

namespace GFDT.Models.Request
{
    public class SendProductGiftRequest
    {
        public int product_id { get; set; }
        public int gifted_user_id { get; set; }
    }
}
