﻿using System;
using System.Collections.Generic;
using System.Text;

namespace GFDT.Models.Request
{
   public class ContactUsRequest
    {
        public string name { get; set; }
        public string email { get; set; }
        public long mobile { get; set; }
        public string subject { get; set; }
        public string message { get; set; }
    }
}
