﻿using System;
using System.Collections.Generic;
using System.Text;

namespace GFTD.Models.Request
{
    public class LoginRequest
    {
        public string email { get; set; }
        public string password { get; set; }
        public string device_token { get; set; }
    }
}
