﻿using System;
using System.Collections.Generic;
using System.Text;

namespace GFDT.Models.Request
{
   public class ForgotPasswordRequest
    {
        public string email { get; set; }
    }
}
