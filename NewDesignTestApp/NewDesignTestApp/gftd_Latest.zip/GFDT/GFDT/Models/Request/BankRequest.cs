﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GFDT.Models.Request
{
    public class BankRequest
    {
       
        public string bank_name { get; set; }
        public string account_holder_name { get; set; }
        public string route_number { get; set; }
        public Int64 account_number { get; set; }
    }
}
