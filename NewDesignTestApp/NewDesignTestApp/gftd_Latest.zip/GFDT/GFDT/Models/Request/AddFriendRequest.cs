﻿using GFDT.ViewModels;
using System;
using System.Collections.Generic;
using System.Text;

namespace GFDT.Models.Request
{
    public class AddFriendRequest
    {
        public string message { get; set; }
        public List<Contactlist> contactlist { get; set; }
    }
    public class Contactlist
    {
        public string contact_name { get; set; }
        public string contact_imagebase64 { get; set; }
        public string contact_number { get; set; }
    }

    
}
