﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GFDT.Models.Request
{
    public class ResetPasswordRequest
    {
        public string mobile { get; set; }
        public string password { get; set; }
    }
}
