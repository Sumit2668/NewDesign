﻿using System;
using System.Collections.Generic;
using System.Text;

namespace GFDT.Models.Request
{
    public class AddItemRequest
    {
        public string image { get; set; }
        public string name { get; set; }
        public int price { get; set; }
        public int tag { get; set; }
        public string store_name { get; set; }
        public string store_location { get; set; }
        public string description { get; set; }
    }
}
