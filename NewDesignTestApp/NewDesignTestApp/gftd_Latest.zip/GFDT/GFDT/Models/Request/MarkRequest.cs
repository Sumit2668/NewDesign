﻿using System;
using System.Collections.Generic;
using System.Text;

namespace GFDT.Models.Request
{
   public class MarkRequest
    {
        public int product_id { get; set; }
    }
}
