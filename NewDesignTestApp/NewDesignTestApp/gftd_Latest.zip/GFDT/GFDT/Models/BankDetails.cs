﻿using System;
using System.Collections.Generic;
using System.Text;

namespace GFTD.Models
{
    public class BankDetails
    {
        public int id { get; set; }
        public int user_id { get; set; }
        public string bank_name { get; set; }
        public string account_holder_name { get; set; }
        public string route_number { get; set; }
        public string account_number { get; set; }
        public string created_at { get; set; }
        public string updated_at { get; set; }
    }
}
