﻿using GFTD.Models.Response;
using Newtonsoft.Json;
using Newtonsoft.Json.Serialization;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Text;

namespace GFDT.Models.Response
{
    public class GetListItemResponce : BaseResponseModel
    {
        [JsonProperty(PropertyName = "data")]
        public ObservableCollection<MyWishStoreList> data { get; set; }
    }
    public class MyWishStoreList
    {
        public int id { get; set; }
        public string product_name { get; set; }
        public string product_image { get; set; }
        public int? product_category { get; set; }
        public int? user_id { get; set; }
        public string product_description { get; set; }
        public string product_price { get; set; }
        public string product_tag { get; set; }
        public string product_tax { get; set; }
        public string store_name { get; set; }
        public string store_location { get; set; }
        public string created_at { get; set; }
        public string updated_at { get; set; }
        public string product_size { get; set; }
        public string product_color { get; set; }
        public string product_rate { get; set; }
        public bool is_like { get; set; }
        public string favuriteimage  => is_like == false ? "unfavurite.png" : "favurite.png";
    }
}
