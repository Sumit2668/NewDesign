﻿using GFTD.Models.Response;
using System;
using System.Collections.Generic;
using System.Text;

namespace GFDT.Models.Response
{
    public class ProductDetailResponse: BaseResponseModel
    {
        public Product product { get; set; }
    }

    public class Product
    {
        public int id { get; set; }
        public string product_name { get; set; }
        public string product_image { get; set; }
        public int product_category { get; set; }
        public object user_id { get; set; }
        public string product_description { get; set; }
        public string product_price { get; set; }
        public object product_tag { get; set; }
        public string product_tax { get; set; }
        public object store_name { get; set; }
        public object store_location { get; set; }
        public string created_at { get; set; }
        public string updated_at { get; set; }
        public string product_size { get; set; }
        public string product_color { get; set; }
        public string product_rate { get; set; }
        public List<string> product_all_image { get; set; }
    }
}
