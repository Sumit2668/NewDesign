﻿using GFDT.ViewModels;
using GFTD.Models;
using GFTD.Models.Response;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Text;

namespace GFDT.Models.Response
{
   public class UpdateMobileNumberResponse: BaseResponseModel
    {
        [JsonProperty("data")]
        public Data data { get; set; }
    }
}
