﻿using GFTD.Models;
using GFTD.Models.Response;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GFDT.Models.Response
{
    public class BankResponse : BaseResponseModel
    {

        [JsonProperty(PropertyName = "Data")]
        public Data data { get; set; }
    }
}
