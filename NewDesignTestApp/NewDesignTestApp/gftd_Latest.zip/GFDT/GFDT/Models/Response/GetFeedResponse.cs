﻿using GFTD.Models.Response;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Text;

namespace GFDT.Models.Response
{
    public class GetFeedResponse : BaseResponseModel
    {
        [JsonProperty("data")]
        public ObservableCollection<GetFeedData> data { get; set; }
    }

    public class GetFeedData
    {
        public string image { get; set; } = "i1.png";
        public int privacy { get; set; }
        public string created_at { get; set; }
        public int gift_send_type { get; set; }
        public string other_user_name { get; set; }
        public string product_name { get; set; } 
        //
        public string myprivacy => privacy == 1 ? "Privacy" : "Public";
    }
}
