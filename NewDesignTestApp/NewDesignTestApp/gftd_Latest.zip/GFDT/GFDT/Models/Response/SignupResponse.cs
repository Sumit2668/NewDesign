﻿using System;
using GFTD.Models;
using GFTD.Models.Response;

namespace GFDT.Models.Response
{
    public class SignupResponse: BaseResponseModel
    {
        public Data data { get; set; }
        public string token { get; set; }
    }
}
