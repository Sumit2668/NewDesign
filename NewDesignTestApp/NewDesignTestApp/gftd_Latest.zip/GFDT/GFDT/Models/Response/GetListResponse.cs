﻿using System;
using System.Collections.Generic;
using System.Text;

namespace GFDT.Models.Response
{
    public class GetList
    {
        public int id { get; set; }
        public string product_name { get; set; }
        public string product_image { get; set; }
        public object product_category { get; set; }
        public int user_id { get; set; }
        public string product_description { get; set; }
        public string product_price { get; set; }
        public string product_tag { get; set; }
        public object product_tax { get; set; }
        public string store_name { get; set; }
        public string store_location { get; set; }
        public string created_at { get; set; }
        public string updated_at { get; set; }
    }
    public class GetListResponse
    {
        public bool status { get; set; }
        public string message { get; set; }
        public List<GetList> data { get; set; }
    }
}
