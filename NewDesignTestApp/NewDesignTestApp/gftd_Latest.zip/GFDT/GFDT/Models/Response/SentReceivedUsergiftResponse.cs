﻿using GFTD.Models.Response;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Text;

namespace GFDT.Models.Response
{
    public class SentReceivedUsergiftResponse : BaseResponseModel
    {
        public User user { get; set; }
        [JsonProperty(PropertyName = "Datum")]
        public List<GiftItems> data { get; set; }
    }
  
    public class GiftItems
    {
        public int gift_send_type { get; set; }
        public string user_name { get; set; }
        public string other_user_name { get; set; }
        public string date { get; set; }
        public string product_image { get; set; }
        public string product_name { get; set; }
    }
}
