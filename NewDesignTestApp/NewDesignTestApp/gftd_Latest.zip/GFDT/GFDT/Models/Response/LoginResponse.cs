﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Text;

namespace GFTD.Models.Response
{
    public class LoginResponse:BaseResponseModel
    {
        public Data data { get; set; }
    }
}
