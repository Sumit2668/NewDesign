﻿using System;
using System.Collections.Generic;
using System.Text;

namespace GFDT.Models.Response
{ 
    public class PrivacyPolicyResponse
    {
        public bool status { get; set; }
        public string message { get; set; }
        public string data { get; set; }
    }
}
