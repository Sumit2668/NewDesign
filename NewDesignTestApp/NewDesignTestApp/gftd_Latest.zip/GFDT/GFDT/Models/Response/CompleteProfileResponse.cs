﻿using System;
using System.Collections.Generic;
using System.Text;

namespace GFTD.Models.Response
{
    public class CompleteProfileResponse:BaseResponseModel
    {
        public Data data { get; set; }
    }
}
