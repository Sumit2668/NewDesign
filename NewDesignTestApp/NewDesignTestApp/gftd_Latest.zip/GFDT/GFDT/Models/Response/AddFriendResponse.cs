﻿using GFDT.ViewModels;
using GFTD.Models.Response;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Text;

namespace GFDT.Models.Response
{
   public class AddFriendResponse: BaseResponseModel
    {
//        [JsonProperty(PropertyName ="Data")]
        public FriendData data { get; set; }
    }
    public class FriendData
    {
        public List<ExistingFriend> existing_friend { get; set; }
        public List<NonExistingFriend> non_existing_friend { get; set; }
    }

    public class ExistingFriend
    {
        public int id { get; set; }
        public int user_id { get; set; }
        public int other_user_id { get; set; }
        public string mobile_no { get; set; }
        public int is_friend { get; set; }
        public string created_at { get; set; }
        public string updated_at { get; set; }
        public UserInfo user_info { get; set; }
    }

    public class NonExistingFriend
    {
        public int id { get; set; }
        public int user_id { get; set; }
        public object other_user_id { get; set; }
        public string mobile_no { get; set; }
        public string created_at { get; set; }
        public string updated_at { get; set; }
        public object user_info { get; set; }
    }

    
}
