﻿using GFTD.Models.Response;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Text;

namespace GFDT.Models.Response
{
    public class GetFriendListResponse : BaseResponseModel
    {
        public User user { get; set; }
        [JsonProperty("data")]
        public ObservableCollection<Userdata> data { get; set; }
    }

    public class User
    {
        public string name { get; set; }
        public string image { get; set; }
        public int total_gift { get; set; }
        public int total_friend { get; set; }
    }


    public class Userdata
    {
        public int id { get; set; }
        public int user_id { get; set; }
        public int other_user_id { get; set; }
        public string mobile_no { get; set; }
        public int is_friend { get; set; }
        public string created_at { get; set; }
        public string updated_at { get; set; }
        public UserInfo user_info { get; set; }
    }
}
