﻿using System;
using System.Collections.Generic;
using System.Text;

namespace GFTD.Models.Response
{
    public class BaseResponseModel
    {
        public bool status { get; set; }
        public string message { get; set; }
        public string token { get; set; }
    }
}
