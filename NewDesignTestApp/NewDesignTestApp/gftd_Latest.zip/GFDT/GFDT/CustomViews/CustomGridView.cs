﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Xamarin.Forms;

namespace GFDT.CustomViews
{
    public class CustomGridView : Grid
    {
        public static readonly BindableProperty CommandParameterProperty = BindableProperty.Create<CustomGridView, object>(p => p.CommandParameter, null);
        public static readonly BindableProperty CommandProperty = BindableProperty.Create<CustomGridView, Command>(p => p.Command, null);

        private int _maxColumns = 2;
        private float _tileHeight = 148;//132;


        public static readonly BindableProperty ItemsSourceProperty =
         BindableProperty.Create<CustomGridView, IList>(
             view => view.ItemsSource,
             null,
             propertyChanged: (bindableObject, oldValue, newValue) =>
             {
                 Task.Run(async () => await ((CustomGridView)bindableObject).ItemsSourceChanged());
             }
         );

        public IList ItemsSource
        {
            get
            {
                return (IList)GetValue(ItemsSourceProperty);
            }
            set
            {
                SetValue(ItemsSourceProperty, value);
            }
        }
        public DataTemplate ItemTemplate
        {
            get;
            set;
        }

        public CustomGridView()
        {
            for (var i = 0; i < MaxColumns; i++)
            {
                ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
            }
        }

        public int MaxColumns
        {
            get { return _maxColumns; }
            set { _maxColumns = value; }
        }

        public float TileHeight
        {
            get { return _tileHeight; }
            set { _tileHeight = value; }
        }

        public object CommandParameter
        {
            get { return GetValue(CommandParameterProperty); }
            set { SetValue(CommandParameterProperty, value); }
        }

        public Command Command
        {
            get { return (Command)GetValue(CommandProperty); }
            set { SetValue(CommandProperty, value); }
        }

        public void BuildTiles<T>(IEnumerable<T> tiles)
        {
            // Wipe out the previous row definitions if they're there.
            if (RowDefinitions.Any())
            {
                this.RowDefinitions.Clear();
                this.ColumnDefinitions.Clear();
                this.Children.Clear();
            }
            var enumerable = tiles as IList<T> ?? tiles.ToList();
            var numberOfRows = Math.Ceiling(enumerable.Count / (float)MaxColumns);
            for (var i = 0; i < numberOfRows; i++)
            {
                RowDefinitions.Add(new RowDefinition { Height = TileHeight });
            }

            for (var index = 0; index < enumerable.Count; index++)
            {
                var column = index % MaxColumns;
                var row = (int)Math.Floor(index / (float)MaxColumns);

                var tile = BuildTile(enumerable[index]);

                Children.Add(tile, column, row);
            }
        }

        private View BuildTile(object item1)
        {
            // return await Task.Run(() =>
            // {
            //var buildTile = new CustomCells.DepartmentItem();
            //buildTile.BindingContext = item1;
            //// var buildTile = (DepartmentItem)Activator.CreateInstance(ItemTemplate, item1);
            //var tapGestureRecognizer = new TapGestureRecognizer
            //{
            //    Command = Command,
            //    CommandParameter = item1
            //};

            //buildTile.GestureRecognizers.Add(tapGestureRecognizer);
            return null; //buildTile;
            // });
        }
        public async Task ItemsSourceChanged()
        {
            //await Task.Yield();
            //
            await Task.Factory.StartNew(() =>
            {
                Device.BeginInvokeOnMainThread(() =>
                {
                    if (RowDefinitions.Any())
                    {
                        this.RowDefinitions.Clear();
                        //this.ColumnDefinitions.Clear();
                        this.Children.Clear();
                    }
                    var enumerable = ItemsSource;
                    var numberOfRows = Math.Ceiling(enumerable.Count / (float)MaxColumns);
                    for (var i = 0; i < numberOfRows; i++)
                    {
                        RowDefinitions.Add(new RowDefinition { Height = TileHeight });
                    }

                    for (var index = 0; index < enumerable.Count; index++)
                    {
                        var view = (View)ItemTemplate.CreateContent();
                        var bindableObject = view as BindableObject;

                        var tapGestureRecognizer = new TapGestureRecognizer
                        {
                            Command = Command,
                            CommandParameter = enumerable[index]
                        };

                        view.GestureRecognizers.Add(tapGestureRecognizer);

                        var column = index % MaxColumns;
                        var row = (int)Math.Floor(index / (float)MaxColumns);
                        try
                        {
                            Children.Add(view, column, row);
                            view.BindingContext = enumerable[index];
                        }
                        catch (Exception ex)
                        {

                        }
                    }
                    //Acr.UserDialogs.UserDialogs.Instance.HideLoading();
                });
                Acr.UserDialogs.UserDialogs.Instance.HideLoading();
            });
        }

        protected override SizeRequest OnMeasure(double widthConstraint, double heightConstraint)
        {
            return base.OnMeasure(widthConstraint, heightConstraint);
        }
    }
}