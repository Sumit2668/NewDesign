﻿using System;
using Xamarin.Forms;

namespace GFDT.CustomViews
{
    public class CustomListView:ListView
    {
        public CustomListView()
        {
        }
    }
}
