﻿using System;
using Xamarin.Forms;

namespace GFDT.CustomViews
{
    public class CustomListViewCell:ViewCell
    {
        public CustomListViewCell()
        {
        }
    }
}
