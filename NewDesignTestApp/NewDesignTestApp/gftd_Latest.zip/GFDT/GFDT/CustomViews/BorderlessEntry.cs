﻿using System;
using System.Collections.Generic;
using System.Text;
using Xamarin.Forms;

namespace GFDT.CustomViews
{
   public class BorderlessEntry: Entry
    {
    }
}
