﻿using Xamarin.Forms;

namespace GFDT
{
    public partial class GFDTPage : ContentPage
    {
        public GFDTPage()
        {
            InitializeComponent();
        }
    }
}
