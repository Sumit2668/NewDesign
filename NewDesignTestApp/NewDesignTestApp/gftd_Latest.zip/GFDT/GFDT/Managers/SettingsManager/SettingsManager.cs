﻿
using System;
using System.Reflection;

namespace GFDT.Managers.SettingsManager
{
    public class SettingsManager : ISettingsManager
    {       
        public SettingsManager()
        {
       // Authorization: Bearer ZEmEQtlZ8uSmAjDSTkSPiCkRPesno0GB5cvT0GVERoJxup7z45edjV5npfK

        }
        public string ApiHost => $"http://13.234.81.74/gifted/public/index.php/api/v1/user/";
        public string Token => "eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiIsImp0aSI6ImJhZDRlZTg3OTI3OTgwM2MwZGFmY2M2ZTExYWIwNjlmMDAwZWY3NzZmNDhiNGIyOTY1OTUzYTkxNzI0MThkODNiNGE3YmZjODdlOTIyMDQ4In0";
    }
}
