﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Globalization;
using System.Linq;
using System.Threading.Tasks;
using System.Xml.Linq;
using GFDT.Providers.ApiProvider;
using GFDT.Managers.SettingsManager;
using Xamarin.Forms.Internals;
using GFDT.Managers.UserManager;
using GFDT.Models.Response;
using GFTD.Models.Request;
using GFTD.Models.Response;
using GFDT.Models.Request;
using System.Net.Http.Headers;
using System.Net.Http;
using Xamarin.Forms;
using GFDT.Services;
using Acr.UserDialogs;

namespace GFDT.Managers.UserManager
{
    public class UserManager : IUserManager
    {
        #region Connectivity
        public async Task<bool> IsConnected()
        {
            //bool IsNetwork = await DependencyService.Get<IMediaService>().CheckNewworkConnectivity();
            // var networkConnection = Xamarin.Forms.DependencyService.Get<Services.IMediaService>().CheckNewworkConnectivity().Result; //CrossConnectivity.Current.IsConnected;
            return await DependencyService.Get<IMediaService>().CheckNewworkConnectivity(); // networkConnection;
        }
        #endregion

        #region Property
        private readonly IApiProvider _apiProvider;
        private readonly ISettingsManager _settingsManager;
        #endregion

        #region


        private LoginResponse loginResponse { get; set; }

        private CompleteProfileResponse completeProfileResponse { get; set; }
        private OTPVerificationResponse otpverificationResponse { get; set; }
        private SignupResponse signupResponse { get; set; }
        private ResetPasswordResponse resetPasswordResponse { get; set; }
        private GetListItemResponce getlistItemResponce { get; set; }
        private GetListResponse getListResponse { get; set; }

        private BaseResponseModel addItemResponse { get; set; }
        private BaseResponseModel contactUsResponse { get; set; }
        private BaseResponseModel sendGiftResponse { get; set; }
        private BaseResponseModel updateProfileResponse { get; set; }
        private BaseResponseModel baseResponse { get; set; }
        public BaseResponseModel BaseResponse => baseResponse;
        //sss
        private ProductDetailResponse productdetailresponse { get; set; }

        public ProductDetailResponse ProductDetailResponse => productdetailresponse;

        private GetFeedResponse getfeedresponse { get; set; }
        public GetFeedResponse GetFeedResponse => getfeedresponse;
        private GetFriendListResponse getfriendlistresponse { get; set; }
        public GetFriendListResponse GetFriendListResponse => getfriendlistresponse;
        private AddFriendResponse addfriendresponse { get; set; }
        public AddFriendResponse AddFriendResponse => addfriendresponse;
        private SentReceivedUsergiftResponse sentreceivedusergiftresponse { get; set; }
        public SentReceivedUsergiftResponse SentReceivedUsergiftResponse => sentreceivedusergiftresponse;
        private BaseResponseModel deletecccountresponse { get; set; }
        public BaseResponseModel DeleteAccountResponse => deletecccountresponse;

        private BaseResponseModel changemobilenumberresponse { get; set; }
        public BaseResponseModel ChangeMobileNumberResponse => changemobilenumberresponse;
        public BaseResponseModel UpdateProfileResponse => updateProfileResponse;


        private UpdateMobileNumberResponse updatemobilenumberresponse { get; set; }
        public UpdateMobileNumberResponse UpdateMobileNumberResponse => updatemobilenumberresponse;
        //sss



        public GetListItemResponce GetListItemResponce => getlistItemResponce;
        public GetListResponse GetListResponse => getListResponse;
        private BankResponse bankResponse { get; set; }
        public BankResponse BankResponse => bankResponse;
        public ResetPasswordResponse ResetPasswordResponse => resetPasswordResponse;
        public OTPVerificationResponse OTPVerificationResponse => otpverificationResponse;
        public LoginResponse LoginResponse => loginResponse;
        public CompleteProfileResponse CompleteProfileResponse => completeProfileResponse;
        public SignupResponse SignupResponse => signupResponse;
        public BaseResponseModel AddItemResponse => addItemResponse;
        public BaseResponseModel ContactUsResponse => contactUsResponse;
        public BaseResponseModel SendGiftResponse => sendGiftResponse;

        public ProfileInfoResponse ProfileInfoResponse => profileInfoResponse;
        private ProfileInfoResponse profileInfoResponse { get; set; }
        private PrivacyPolicyResponse privacyPolicyResponse { get; set; }
        public PrivacyPolicyResponse PrivacyPolicyResponse => privacyPolicyResponse;

        #endregion

        #region Header

        public Dictionary<string, string> SignupHeaders()
        {
            Dictionary<string, string> header = new Dictionary<string, string>();
            header.Add("Authorization", $"{"Bearer "}ZEmEQtlZ8uSmAjDSTkSPiCkRPesno0GB5cvT0GVERoJxup7z45edjV5npfK");

            return header;
        }

        public Dictionary<string, string> AfterLoginHeaders()
        {
            Dictionary<string, string> header = new Dictionary<string, string>();
            header.Add("X-Access-Token", App.MyAccesstoken);
            //header.Add("X-Access-Token", "MTIzNDU2NTM=");
            return header;
        }

        #endregion

        public async void Login(LoginRequest loginRequest, Action success, Action<BaseResponseModel> failed)
        {
            bool IsNetwork = await IsConnected();
            if (IsNetwork)
            {
                try
                {
                    var url = string.Format("{0}login", _settingsManager.ApiHost);
                    var result = await _apiProvider.Post<LoginResponse, LoginRequest>(url, loginRequest);
                    if (result.Result.status == true)
                    {
                        if (success != null)
                        {
                            loginResponse = result.Result;
                            success.Invoke();
                        }
                        else
                        {
                            failed.Invoke(result.Result);
                        }
                    }
                    else
                    {
                        failed.Invoke(result.Result);
                    }
                }
                catch (Exception ex)
                {

                }
            }
            else
            {
                BaseResponseModel error = new BaseResponseModel { message = "Please check your internet connection!" };
                failed.Invoke(error);
            }
        }

        public async void Signup(SignupRequest signupRequest, Action success, Action<BaseResponseModel> failed)
        {
            bool IsNetwork = await IsConnected();
            if (IsNetwork)
            {
                try
                {
                    var url = string.Format("{0}signup", _settingsManager.ApiHost);
                    var result = await _apiProvider.Post<SignupResponse, SignupRequest>(url, signupRequest, SignupHeaders());
                    if (result.Result.status == true)
                    {
                        if (success != null)
                        {
                            signupResponse = result.Result;
                            success.Invoke();
                        }
                        else
                        {
                            failed.Invoke(result.Result);
                        }
                    }
                    else
                    {
                        failed.Invoke(result.Result);
                    }
                }
                catch (Exception exe)
                {
                    UserDialogs.Instance.HideLoading();
                }
            }
            else
            {
                BaseResponseModel error = new BaseResponseModel { message = "Please check your internet connection!" };
                failed.Invoke(error);
            }

        }

        public async void CompleteProfile(CompleteProfileRequest completeProfileRequest, Action success, Action<BaseResponseModel> failed)
        {
            bool IsNetwork = await IsConnected();
            if (IsNetwork)
            {
                try
                {
                    var url = string.Format("{0}completeProfile", _settingsManager.ApiHost);
                    var result = await _apiProvider.Post<CompleteProfileResponse, CompleteProfileRequest>(url, completeProfileRequest, AfterLoginHeaders());
                    //var result = await _apiProvider.Post<SignupResponse, SignupRequest>(url, signupRequest, SignupHeaders());
                    if (result.Result.status == true)
                    {
                        if (success != null)
                        {
                            completeProfileResponse = result.Result;
                            success.Invoke();
                        }
                        else
                        {
                            failed.Invoke(result.Result);
                        }
                    }
                    else
                    {
                        failed.Invoke(result.Result);
                    }

                }
                catch (Exception exc)
                {

                }
            }
            else
            {
                BaseResponseModel error = new BaseResponseModel { message = "Please check your internet connection!" };
                failed.Invoke(error);
            }

        }

        public async void OTPVerification(OTPVerificationRequest otpverificationRequest, Action success, Action<BaseResponseModel> failed)
        {
            bool IsNetwork = await IsConnected();
            if (IsNetwork)
            {
                try
                {
                    var url = string.Format("{0}otpVerification", _settingsManager.ApiHost);
                    var result = await _apiProvider.Post<OTPVerificationResponse, OTPVerificationRequest>(url, otpverificationRequest);
                    if (result.Result.status == true)
                    {
                        if (success != null)
                        {
                            otpverificationResponse = result.Result;
                            success.Invoke();
                        }
                        else
                        {
                            failed.Invoke(result.Result);
                        }
                    }
                    else
                    {
                        failed.Invoke(result.Result);
                    }

                }
                catch (Exception exc)
                {

                }
            }
            else
            {
                BaseResponseModel error = new BaseResponseModel { message = "Please check your internet connection!" };
                failed.Invoke(error);
            }
        }

        public async void ResetPassword(ResetPasswordRequest resetPasswordRequest, Action success, Action<BaseResponseModel> failed)
        {
            bool IsNetwork = await IsConnected();
            if (IsNetwork)
            {
                try
                {
                    var url = string.Format("{0}resetpassword", _settingsManager.ApiHost);
                    var result = await _apiProvider.Post<ResetPasswordResponse, ResetPasswordRequest>(url, resetPasswordRequest);
                    if (result.Result.status == true)
                    {
                        if (success != null)
                        {
                            resetPasswordResponse = result.Result;
                            success.Invoke();
                        }
                        else
                        {
                            failed.Invoke(result.Result);
                        }
                    }
                    else
                    {
                        failed.Invoke(result.Result);
                    }

                }
                catch (Exception exc)
                {

                }
            }
            else
            {
                BaseResponseModel error = new BaseResponseModel { message = "Please check your internet connection!" };
                failed.Invoke(error);
            }
        }

        public async void BankDetail(BankRequest bankRequest, Action success, Action<BaseResponseModel> failed)
        {
            bool IsNetwork = await IsConnected();
            if (IsNetwork)
            {
                try
                {
                    var url = string.Format("{0}bankDetail", _settingsManager.ApiHost);
                    var result = await _apiProvider.Post<BankResponse, BankRequest>(url, bankRequest, AfterLoginHeaders());
                    if (result.Result.status == true)
                    {
                        if (success != null)
                        {
                            bankResponse = result.Result;
                            success.Invoke();
                        }
                        else
                        {
                            failed.Invoke(result.Result);
                        }
                    }
                    else
                    {
                        failed.Invoke(result.Result);
                    }

                }
                catch (Exception exc)
                {

                }
            }
            else
            {
                BaseResponseModel error = new BaseResponseModel { message = "Please check your internet connection!" };
                failed.Invoke(error);
            }
        }

        //Sumit
        public async void GetStoreWisheshItemDetail(int ListId, Action success, Action<BaseResponseModel> failed)
        {
            bool IsNetwork = await IsConnected();
            if (IsNetwork)
            {
                try
                {
                    var url = string.Format("{0}getList/" + ListId.ToString(), _settingsManager.ApiHost);
                    var result = await _apiProvider.Get<GetListItemResponce>(url, AfterLoginHeaders());
                    if (result.Result.status == true)
                    {
                        if (success != null)
                        {
                            getlistItemResponce = result.Result;
                            success.Invoke();
                        }
                        else
                        {
                            failed.Invoke(result.Result);
                        }
                    }
                    else
                    {
                        failed.Invoke(result.Result);
                    }

                }
                catch (Exception exc)
                {

                }
            }
            else
            {
                BaseResponseModel error = new BaseResponseModel { message = "Please check your internet connection!" };
                failed.Invoke(error);
            }
        }
        public async void SentReceivedGift(int userid, Action success, Action<BaseResponseModel> failed)
        {
            bool IsNetwork = await IsConnected();
            if (IsNetwork)
            {
                try
                {
                    //sentgift/10
                    var url = string.Format("{0}sentgift/" + userid.ToString(), _settingsManager.ApiHost);
                    var result = await _apiProvider.Get<SentReceivedUsergiftResponse>(url, AfterLoginHeaders());
                    if (result.Result.status == true)
                    {
                        if (success != null)
                        {
                            sentreceivedusergiftresponse = result.Result;
                            success.Invoke();
                        }
                        else
                        {
                            failed.Invoke(result.Result);
                        }
                    }
                    else
                    {
                        failed.Invoke(result.Result);
                    }

                }
                catch (Exception exc)
                {

                }
            }
            else
            {
                BaseResponseModel error = new BaseResponseModel { message = "Please check your internet connection!" };
                failed.Invoke(error);
            }
        }
        public async void GetFriendList(Action success, Action<BaseResponseModel> failed)
        {
            bool IsNetwork = await IsConnected();
            if (IsNetwork)
            {
                try
                {
                    var url = string.Format("{0}getfriendlist", _settingsManager.ApiHost);
                    var result = await _apiProvider.Get<GetFriendListResponse>(url, AfterLoginHeaders());
                    if (result.Result.status == true)
                    {
                        if (success != null)
                        {
                            getfriendlistresponse = result.Result;
                            success.Invoke();
                        }
                        else
                        {
                            failed.Invoke(result.Result);
                        }
                    }
                    else
                    {
                        failed.Invoke(result.Result);
                    }

                }
                catch (Exception exc)
                {

                }
            }
            else
            {
                BaseResponseModel error = new BaseResponseModel { message = "Please check your internet connection!" };
                failed.Invoke(error);
            }
        }
        public async void Addfriend(AddFriendRequest addfriendrequest, Action success, Action<BaseResponseModel> failed)
        {
            bool IsNetwork = await IsConnected();
            if (IsNetwork)
            {
                try
                {
                    var url = string.Format("{0}addfriend", _settingsManager.ApiHost);
                    var result = await _apiProvider.Post<AddFriendResponse, AddFriendRequest>(url, addfriendrequest, AfterLoginHeaders());
                    if (result.Result.status == true)
                    {
                        if (success != null)
                        {
                            addfriendresponse = result.Result;
                            success.Invoke();
                        }
                        else
                        {
                            failed.Invoke(result.Result);
                        }
                    }
                    else
                    {
                        failed.Invoke(result.Result);
                    }

                }
                catch (Exception exc)
                {

                }
            }
            else
            {
                BaseResponseModel error = new BaseResponseModel { message = "Please check your internet connection!" };
                failed.Invoke(error);
            }
        }
        public async void GetFeedResponseList(Action success, Action<BaseResponseModel> failed)
        {
            bool IsNetwork = await IsConnected();
            if (IsNetwork)
            {
                try
                {
                    var url = string.Format("{0}getFeed", _settingsManager.ApiHost);
                    var result = await _apiProvider.Get<GetFeedResponse>(url, AfterLoginHeaders());
                    if (result.Result.status == true)
                    {
                        if (success != null)
                        {
                            getfeedresponse = result.Result;
                            success.Invoke();
                        }
                        else
                        {
                            failed.Invoke(result.Result);
                        }
                    }
                    else
                    {
                        failed.Invoke(result.Result);
                    }

                }
                catch (Exception exc)
                {

                }
            }
            else
            {
                BaseResponseModel error = new BaseResponseModel { message = "Please check your internet connection!" };
                failed.Invoke(error);
            }
        }

        public async void DeleteAccount(Action success, Action<BaseResponseModel> failed)
        {
            bool IsNetwork = await IsConnected();
            if (IsNetwork)
            {
                try
                {
                    var url = string.Format("{0}deleteAccount", _settingsManager.ApiHost);
                    var result = await _apiProvider.Delete<BaseResponseModel>(url, AfterLoginHeaders());
                    if (result.Result.status == true)
                    {
                        if (success != null)
                        {
                            deletecccountresponse = result.Result;
                            success.Invoke();
                        }
                        else
                        {
                            failed.Invoke(result.Result);
                        }
                    }
                    else
                    {
                        failed.Invoke(result.Result);
                    }

                }
                catch (Exception exc)
                {

                }
            }
            else
            {
                BaseResponseModel error = new BaseResponseModel { message = "Please check your internet connection!" };
                failed.Invoke(error);
            }
        }

        public async void ChangeMobileNumber(string mobile, Action success, Action<BaseResponseModel> failed)
        {
            bool IsNetwork = await IsConnected();
            if (IsNetwork)
            {
                try
                {
                    var url = string.Format("{0}changeNumber", _settingsManager.ApiHost);
                    var result = await _apiProvider.Post<BaseResponseModel, string>(url, mobile, AfterLoginHeaders());
                    if (result.Result.status == true)
                    {
                        if (success != null)
                        {
                            changemobilenumberresponse = result.Result;
                            success.Invoke();
                        }
                        else
                        {
                            failed.Invoke(result.Result);
                        }
                    }
                    else
                    {
                        failed.Invoke(result.Result);
                    }

                }
                catch (Exception exc)
                {

                }
            }
            else
            {
                BaseResponseModel error = new BaseResponseModel { message = "Please check your internet connection!" };
                failed.Invoke(error);
            }
        }

        public async void UpdateMobileNumber(UpdateMobileNumberRequest updatemobile, Action success, Action<BaseResponseModel> failed)
        {
            bool IsNetwork = await IsConnected();
            if (IsNetwork)
            {
                try
                {
                    var url = string.Format("{0}changeNumber", _settingsManager.ApiHost);
                    var result = await _apiProvider.Post<UpdateMobileNumberResponse, UpdateMobileNumberRequest>(url, updatemobile, AfterLoginHeaders());
                    if (result.Result.status == true)
                    {
                        if (success != null)
                        {
                            updatemobilenumberresponse = result.Result;
                            success.Invoke();
                        }
                        else
                        {
                            failed.Invoke(result.Result);
                        }
                    }
                    else
                    {
                        failed.Invoke(result.Result);
                    }

                }
                catch (Exception exc)
                {

                }
            }
            else
            {
                BaseResponseModel error = new BaseResponseModel { message = "Please check your internet connection!" };
                failed.Invoke(error);
            }
        }

        public async void ForgotPassword(ForgotPasswordRequest forgetpass, Action success, Action<BaseResponseModel> failed)
        {
            bool IsNetwork = await IsConnected();
            if (IsNetwork)
            {
                try
                {
                    var url = string.Format("{0}forgetpassword", _settingsManager.ApiHost);
                    var result = await _apiProvider.Post<BaseResponseModel, ForgotPasswordRequest>(url, forgetpass);
                    if (result.Result.status == true)
                    {
                        if (success != null)
                        {
                            baseResponse = result.Result;
                            success.Invoke();
                        }
                        else
                        {
                            failed.Invoke(result.Result);
                        }
                    }
                    else
                    {
                        await UserDialogs.Instance.AlertAsync(result.Result.message, "Alert", "Okay");
                        failed.Invoke(result.Result);
                    }

                }
                catch (Exception exc)
                {

                }
            }
            else
            {
                BaseResponseModel error = new BaseResponseModel { message = "Please check your internet connection!" };
                failed.Invoke(error);
            }
        }


        public async void GetProductDetails(int productid, Action success, Action<BaseResponseModel> failed)
        {
            bool IsNetwork = await IsConnected();
            if (IsNetwork)
            {
                try
                {
                    var url = string.Format("{0}product/"+ productid, _settingsManager.ApiHost);
                    var result = await _apiProvider.Get<ProductDetailResponse>(url, AfterLoginHeaders());
                    if (result.Result.status == true)
                    {
                        if (success != null)
                        {
                            productdetailresponse = result.Result;
                            success.Invoke();
                        }
                        else
                        {
                            failed.Invoke(result.Result);
                        }
                    }
                    else
                    {
                        failed.Invoke(result.Result);
                    }
                }
                catch (Exception exc)
                {

                }
            }
            else
            {
                BaseResponseModel error = new BaseResponseModel { message = "Please check your internet connection!" };
                failed.Invoke(error);
            }
        }



        public async void StoreLike(MarkRequest mark, Action success, Action<BaseResponseModel> failed)
        {
            bool IsNetwork = await IsConnected();
            if (IsNetwork)
            {
                try
                {
                    var url = string.Format("{0}makewishlist", _settingsManager.ApiHost);
                    var result = await _apiProvider.Post<BaseResponseModel, MarkRequest>(url, mark, AfterLoginHeaders());
                    if (result.Result.status == true)
                    {
                        if (success != null)
                        {
                            baseResponse = result.Result;
                            success.Invoke();
                        }
                        else
                        {
                            failed.Invoke(result.Result);
                        }
                    }
                    else
                    {
                        await UserDialogs.Instance.AlertAsync(result.Result.message, "Alert", "Okay");
                        failed.Invoke(result.Result);
                    }

                }
                catch (Exception exc)
                {

                }
            }
            else
            {
                BaseResponseModel error = new BaseResponseModel { message = "Please check your internet connection!" };
                failed.Invoke(error);
            }
        }

        //End Sumit Work

        public async void AddToWishList(AddItemRequest addItemRequest, Action success, Action<BaseResponseModel> failed)
        {
            bool IsNetwork = await IsConnected();
            if (IsNetwork)
            {
                try
                {
                    var url = string.Format("{0}addItem", _settingsManager.ApiHost);
                    var result = await _apiProvider.Post<BaseResponseModel, AddItemRequest>(url, addItemRequest, AfterLoginHeaders());
                    if (result.Result.status == true)
                    {
                        if (success != null)
                        {
                            addItemResponse = result.Result;
                            success.Invoke();
                        }
                        else
                        {
                            failed.Invoke(result.Result);
                        }
                    }
                    else
                    {
                        failed.Invoke(result.Result);
                    }

                }
                catch (Exception exc)
                {

                }
            }
            else
            {
                BaseResponseModel error = new BaseResponseModel { message = "Please check your internet connection!" };
                failed.Invoke(error);
            }
        }

        public async void ContactUs(ContactUsRequest contactUsRequest, Action success, Action<BaseResponseModel> failed)
        {
            bool IsNetwork = await IsConnected();
            if (IsNetwork)
            {
                try
                {
                    var url = string.Format("{0}contactus", _settingsManager.ApiHost);
                    var result = await _apiProvider.Post<BaseResponseModel, ContactUsRequest>(url, contactUsRequest);
                    if (result.Result.status == true)
                    {
                        if (success != null)
                        {
                            contactUsResponse = result.Result;
                            success.Invoke();
                        }
                        else
                        {
                            failed.Invoke(result.Result);
                        }
                    }
                    else
                    {
                        failed.Invoke(result.Result);
                    }

                }
                catch (Exception exc)
                {

                }
            }
            else
            {
                BaseResponseModel error = new BaseResponseModel { message = "Please check your internet connection!" };
                failed.Invoke(error);
            }
        }

        public async void SendGift(SendGiftRequest sendGiftRequest, Action success, Action<BaseResponseModel> failed)
        {
            bool IsNetwork = await IsConnected();
            if (IsNetwork)
            {
                try
                {
                    var url = string.Format("{0}sendgift", _settingsManager.ApiHost);
                    var result = await _apiProvider.Post<BaseResponseModel, SendGiftRequest>(url, sendGiftRequest, AfterLoginHeaders());
                    if (result.Result.status == true)
                    {
                        if (success != null)
                        {
                            sendGiftResponse = result.Result;
                            success.Invoke();
                        }
                        else
                        {
                            failed.Invoke(result.Result);
                        }
                    }
                    else
                    {
                        failed.Invoke(result.Result);
                    }

                }
                catch (Exception exc)
                {

                }
            }
            else
            {
                BaseResponseModel error = new BaseResponseModel { message = "Please check your internet connection!" };
                failed.Invoke(error);
            }
        }
        public async void UpdateProfile(EditProfileRequest editProfileRequest, Action success, Action<BaseResponseModel> failed)
        {
            bool IsNetwork = await IsConnected();
            if (IsNetwork)
            {
                try
                {
                    var url = string.Format("{0}completeProfile", _settingsManager.ApiHost);
                    var result = await _apiProvider.Post<BaseResponseModel, EditProfileRequest>(url, editProfileRequest, AfterLoginHeaders());
                    if (result.Result.status == true)
                    {
                        if (success != null)
                        {
                            updateProfileResponse = result.Result;
                            success.Invoke();
                        }
                        else
                        {
                            failed.Invoke(result.Result);
                        }
                    }
                    else
                    {
                        failed.Invoke(result.Result);
                    }

                }
                catch (Exception exc)
                {

                }
            }
            else
            {
                BaseResponseModel error = new BaseResponseModel { message = "Please check your internet connection!" };
                failed.Invoke(error);
            }
        }

        public async void SendProductGift(SendProductGiftRequest editProfileRequest, Action success, Action<BaseResponseModel> failed)
        {
            bool IsNetwork = await IsConnected();
            if (IsNetwork)
            {
                try
                {
                    var url = string.Format("{0}sendproductgift", _settingsManager.ApiHost);
                    var result = await _apiProvider.Post<BaseResponseModel, SendProductGiftRequest>(url, editProfileRequest, AfterLoginHeaders());
                    if (result.Result.status == true)
                    {
                        if (success != null)
                        {
                            baseResponse = result.Result;
                            success.Invoke();
                        }
                        else
                        {
                            failed.Invoke(result.Result);
                        }
                    }
                    else
                    {
                        failed.Invoke(result.Result);
                    }

                }
                catch (Exception exc)
                {

                }
            }
            else
            {
                BaseResponseModel error = new BaseResponseModel { message = "Please check your internet connection!" };
                failed.Invoke(error);
            }
        }



        public async void GetList(string Par, Action success, Action<GetListResponse> failed)
        {
            bool IsNetwork = await IsConnected();
            if (IsNetwork)
            {
                try
                {
                    var url = string.Format("{0}getList/" + Par.ToString(), _settingsManager.ApiHost);
                    var result = await _apiProvider.Get<GetListResponse>(url, AfterLoginHeaders());
                    if (result.Result.status == true)
                    {
                        if (success != null)
                        {
                            getListResponse = result.Result;
                            success.Invoke();
                        }
                        else
                        {
                            failed.Invoke(result.Result);
                        }
                    }
                    else
                    {
                        failed.Invoke(result.Result);
                    }

                }
                catch (Exception ex)
                {

                }
            }
            else
            {
                GetListResponse error = new GetListResponse { message = "Please check your internet connection!" };
                failed.Invoke(error);
            }
        } 

       public async void GetPrivayPolicy(string url, Action success, Action<PrivacyPolicyResponse> failed)
        {
            bool IsNetwork = await IsConnected();
            if (IsNetwork)
            {
                try
                {
                    var response = new HttpResponseMessage(); 

                    var result = await _apiProvider.Get<PrivacyPolicyResponse>(url);
                    if (result.Result.status == true)
                    {
                        if (success != null)
                        {
                            privacyPolicyResponse = result.Result;
                            success.Invoke();
                        }
                        else
                        {
                            failed.Invoke(result.Result);
                        }
                    }
                    else
                    {
                        failed.Invoke(result.Result);
                    }

                }
                catch (Exception ex)
                {

                }
            }
            else
            {
                PrivacyPolicyResponse error = new PrivacyPolicyResponse { message = "Please check your internet connection!" };
                failed.Invoke(error);
            }
        }

        public async void ProfileInfo(Action success, Action<ProfileInfoResponse> failed)
        {
            bool IsNetwork = await IsConnected();
            if (IsNetwork)
            {
                try
                {
                    var url = string.Format("{0}profileinfo", _settingsManager.ApiHost);
                    var result = await _apiProvider.Get<ProfileInfoResponse>(url, AfterLoginHeaders());
                    if (result.Result.status == true)
                    {
                        if (success != null)
                        {
                            profileInfoResponse = result.Result;
                            success.Invoke();
                        }
                        else
                        {
                            failed.Invoke(result.Result);
                        }
                    }
                    else
                    {
                        failed.Invoke(result.Result);
                    }

                }
                catch (Exception exc)
                {

                }
            }
            else
            {
                var error = new ProfileInfoResponse { message = "Please check your internet connection!" };
                failed.Invoke(error);
            }
        }

        #region Constructor

        public UserManager(IApiProvider apiProvider, ISettingsManager settingsManager)
        {
            _apiProvider = apiProvider;
            _settingsManager = settingsManager;
        }
        #endregion
    }
}
