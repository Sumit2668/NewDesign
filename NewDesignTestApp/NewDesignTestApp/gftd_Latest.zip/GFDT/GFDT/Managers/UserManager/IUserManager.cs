﻿using System;
using System.Threading.Tasks;
using GFDT.Models.Request;
using GFDT.Models.Response;
using GFTD.Models.Request;
using GFTD.Models.Response;

namespace GFDT.Managers.UserManager
{
    public interface IUserManager
    {


        #region All Response
        LoginResponse LoginResponse { get; }
        CompleteProfileResponse CompleteProfileResponse { get; }
        SignupResponse SignupResponse { get; }
        ResetPasswordResponse ResetPasswordResponse { get; }
        OTPVerificationResponse OTPVerificationResponse { get; }
        BankResponse BankResponse { get; }
        GetListItemResponce GetListItemResponce { get; }
        BaseResponseModel AddItemResponse { get; }
        BaseResponseModel ContactUsResponse { get; }
        BaseResponseModel SendGiftResponse { get; }
        BaseResponseModel DeleteAccountResponse { get; }
        BaseResponseModel ChangeMobileNumberResponse { get; }
        GetListResponse GetListResponse { get; }
        BaseResponseModel BaseResponse { get; }
        SentReceivedUsergiftResponse SentReceivedUsergiftResponse { get; }
        GetFriendListResponse GetFriendListResponse { get; }
        AddFriendResponse AddFriendResponse { get; }
        GetFeedResponse GetFeedResponse { get; }
        ProductDetailResponse ProductDetailResponse { get; }
        UpdateMobileNumberResponse UpdateMobileNumberResponse { get; } 
        BaseResponseModel UpdateProfileResponse { get; }

        PrivacyPolicyResponse PrivacyPolicyResponse { get; }
        ProfileInfoResponse ProfileInfoResponse { get; }
        #endregion

        #region ALL API

        void Login(LoginRequest loginRequest, Action success, Action<BaseResponseModel> failed);

        void Signup(SignupRequest signupRequest, Action success, Action<BaseResponseModel> failed);

        void CompleteProfile(CompleteProfileRequest completeProfileRequest, Action success, Action<BaseResponseModel> failed);

        void OTPVerification(OTPVerificationRequest oTPVerificationRequest, Action success, Action<BaseResponseModel> failed);

        void ResetPassword(ResetPasswordRequest resetPasswordRequest, Action success, Action<BaseResponseModel> failed);

        void BankDetail(BankRequest bankRequest, Action success, Action<BaseResponseModel> failed);
        //Sumit
        void GetStoreWisheshItemDetail(int ListId, Action success, Action<BaseResponseModel> failed);
        void SentReceivedGift(int userid, Action success, Action<BaseResponseModel> failed);
        //Date 18 June 2019 
        void GetFriendList(Action success, Action<BaseResponseModel> failed);
        void GetFeedResponseList(Action success, Action<BaseResponseModel> failed);
        void Addfriend(AddFriendRequest addfriendrequest, Action success, Action<BaseResponseModel> failed);
        void DeleteAccount(Action success, Action<BaseResponseModel> failed);
        void  ForgotPassword(ForgotPasswordRequest Forgotemail, Action success, Action<BaseResponseModel> failed);
        void StoreLike(MarkRequest mark, Action success, Action<BaseResponseModel> failed);
        void GetProductDetails(int productid, Action success, Action<BaseResponseModel> failed);

        void SendProductGift(SendProductGiftRequest editProfileRequest, Action success, Action<BaseResponseModel> failed);
        //Sumit

        void GetList(string Par, Action success, Action<GetListResponse> failed);
        void AddToWishList(AddItemRequest addItemRequest, Action success, Action<BaseResponseModel> failed);
        void ContactUs(ContactUsRequest contactUsRequest, Action success, Action<BaseResponseModel> failed);
        void SendGift(SendGiftRequest contactUsRequest, Action success, Action<BaseResponseModel> failed);
        void UpdateProfile(EditProfileRequest contactUsRequest, Action success, Action<BaseResponseModel> failed);

        // Privacy policy

        void GetPrivayPolicy(string url, Action success, Action<PrivacyPolicyResponse> failed);

        void ProfileInfo(Action success, Action<ProfileInfoResponse> failed);   
        #endregion

    }
}
