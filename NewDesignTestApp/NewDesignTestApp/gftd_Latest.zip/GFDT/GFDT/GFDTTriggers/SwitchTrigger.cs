﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Xamarin.Forms;

namespace GFDT.GFDTTriggers
{
    public class SwitchTrigger : TriggerAction<ImageButton>
    {
        protected async override void Invoke(ImageButton button)
        {
            Xamarin.Forms.ImageButton img = (Xamarin.Forms.ImageButton)button;
            Xamarin.Forms.FileImageSource objFileImageSource = (Xamarin.Forms.FileImageSource)img.Source;
            if (objFileImageSource.File == "yes.png")
            {
                button.Source = "no.png";
            }
            else if (objFileImageSource.File == "no.png")
            {
                button.Source = "yes.png";
            }
            else if (objFileImageSource.File == "favurite.png")
            {
                await button.ScaleTo(0.95, 20, Easing.CubicOut);
                button.Source = "unfavurite.png";
                await button.ScaleTo(1, 20, Easing.CubicIn);
            }
            else
            {
                await button.ScaleTo(0.95, 20, Easing.CubicOut);
                button.Source = "favurite.png";
                await button.ScaleTo(1, 20, Easing.CubicIn);
            }
            App.Locator.StoreViewModel.IsLikeCommand.Execute(null);
        }
    }
}
