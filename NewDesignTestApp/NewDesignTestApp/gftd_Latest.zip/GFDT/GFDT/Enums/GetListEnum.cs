﻿using System;
using System.Collections.Generic;
using System.Text;

namespace GFDT.Enums
{
    public enum GetListEnum
    {
        UsersList = 1,
        MyStore = 2,
        MyWishList= 3,
    }
}
