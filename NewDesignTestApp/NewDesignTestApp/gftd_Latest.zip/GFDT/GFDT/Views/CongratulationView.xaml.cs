﻿using System;
using System.Collections.Generic;

using Xamarin.Forms;

namespace GFDT.Views
{
    public partial class CongratulationView : ContentPage
    {
        public CongratulationView()
        {
            InitializeComponent();
        }
        void Handle_Tapped(object sender, System.EventArgs e)
        {
            Device.BeginInvokeOnMainThread(() =>
            {

                App.Current.MainPage.Navigation.PopAsync( true);
            }
            );
        }
    }
}
