﻿using System;
using System.Collections.Generic;

using Xamarin.Forms;
using Xamarin.Forms.PlatformConfiguration.iOSSpecific;

namespace GFDT.Views
{
    public partial class FeedView : ContentPage
    {
        public FeedView()
        {
            InitializeComponent();
            BindingContext = App.Locator.FeedViewModel; 
        }
        void Handle_Tapped(object sender, System.EventArgs e)
        {
            App.Locator.HomeViewModel.IsPresented = !App.Locator.HomeViewModel.IsPresented;
        }
    }
}
