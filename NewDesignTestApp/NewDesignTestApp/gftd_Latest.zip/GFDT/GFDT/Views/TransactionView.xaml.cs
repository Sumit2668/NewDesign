﻿using System;
using System.Collections.Generic;

using Xamarin.Forms;
using Xamarin.Forms.PlatformConfiguration.iOSSpecific;

namespace GFDT.Views
{
    public partial class TransactionView : ContentPage
    {
        public TransactionView()
        {
            InitializeComponent();
        On<Xamarin.Forms.PlatformConfiguration.iOS>().SetUseSafeArea(true);
        var viewModel = new ViewModels.FeedViewModel();
        BindingContext = viewModel; 
        }
    void Handle_Tapped(object sender, System.EventArgs e)
    {
            //App.Locator.HomeViewModel.IsPresented = !App.Locator.HomeViewModel.IsPresented;
            Device.BeginInvokeOnMainThread
                (() => this.Navigation.PopAsync(true));
        }

        void share_tapped(object sender, System.EventArgs e)
        {
            Device.BeginInvokeOnMainThread(async () =>
            {
                await Xamarin.Essentials.Share.RequestAsync("Share App", "GFTD");
            });
        }
    }
}
