﻿using GFDT.Models.Response;
using GFDT.ViewModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Xamarin.Forms;
using Xamarin.Forms.PlatformConfiguration.iOSSpecific;
using Xamarin.Forms.Xaml;

namespace GFDT.Views
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class StoreView : ContentPage
    {
        public StoreView()
        {
            InitializeComponent();
            BindingContext = App.Locator.StoreViewModel;
        }
        void Handle_Tapped(object sender, System.EventArgs e)
        {
            //App.Locator.HomeViewModel.IsPresented = !App.Locator.HomeViewModel.IsPresented;
            Device.BeginInvokeOnMainThread(() => this.Navigation.PopAsync(true));
        }

        private void ImageButton_Clicked(object sender, EventArgs e)
        {
            var getitem= ((ImageButton)sender).BindingContext as MyWishStoreList;
            App.Locator.StoreViewModel.ProductId = getitem.id;
        }
    }
}