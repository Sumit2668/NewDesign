﻿using GFDT.ViewModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Xamarin.Forms;
using Xamarin.Forms.PlatformConfiguration.iOSSpecific;
using Xamarin.Forms.Xaml;

namespace GFDT.Views
{
	[XamlCompilation(XamlCompilationOptions.Compile)]
	public partial class FriendsView : ContentPage
	{
        List<MyTestModel> myTests = new List<MyTestModel>();
        public FriendsView ()
        {
            InitializeComponent();
            On<Xamarin.Forms.PlatformConfiguration.iOS>().SetUseSafeArea(true);
            //BindingContext = App.Locator.FriendViewModel;
            //myTests = new List<MyTestModel>();
            //myTests.Add(new MyTestModel() { Image = "i1.png", Name = "Ice Cream Sandwich" });
            //myTests.Add(new MyTestModel() { Image = "i2.png", Name = "Ice Cream Sandwich" });
            //myTests.Add(new MyTestModel() { Image = "i1.png", Name = "Ice Cream Sandwich" });
            //myTests.Add(new MyTestModel() { Image = "i2.png", Name = "Ice Cream Sandwich" });
            //myTests.Add(new MyTestModel() { Image = "i1.png", Name = "Ice Cream Sandwich" });
            //myTests.Add(new MyTestModel() { Image = "i2.png", Name = "Ice Cream Sandwich" });
            //myTests.Add(new MyTestModel() { Image = "i1.png", Name = "Ice Cream Sandwich" });
            //myTests.Add(new MyTestModel() { Image = "i2.png", Name = "Ice Cream Sandwich" });
            //myTests.Add(new MyTestModel() { Image = "i1.png", Name = "Ice Cream Sandwich" });
            //myTests.Add(new MyTestModel() { Image = "i2.png", Name = "Ice Cream Sandwich" });
            //myTests.Add(new MyTestModel() { Image = "i1.png", Name = "Ice Cream Sandwich" });
            //myTests.Add(new MyTestModel() { Image = "i2.png", Name = "Ice Cream Sandwich" });
            //myTests.Add(new MyTestModel() { Image = "i1.png", Name = "Ice Cream Sandwich" });
            //myTests.Add(new MyTestModel() { Image = "i2.png", Name = "Ice Cream Sandwich" });
            //WishList.ItemsSource = myTests;
        }
        private async void mywishes_Tapped(object sender, EventArgs e)
        {
            mywishes.FontAttributes = FontAttributes.Bold;
            gtfdFriend.FontAttributes = FontAttributes.None;
            await Task.WhenAll(
            mainbox.TranslateTo(0, 0, 120, Easing.SinOut));
            mywishes.TextColor = Color.FromHex("#0080b1");
            gtfdFriend.TextColor = Color.FromHex("#808080");
        }
        private async void gtfdFriend_Tapped(object sender, EventArgs e)
        {
            gtfdFriend.FontAttributes = FontAttributes.Bold;
            mywishes.FontAttributes = FontAttributes.None;
            await Task.WhenAll(
            mainbox.TranslateTo(mainbox.Width + 32, 0, 120, Easing.SinOut));
            mywishes.TextColor = Color.FromHex("808080");
            gtfdFriend.TextColor = Color.FromHex("#0080b1");
        }


        void Handle_Tapped(object sender, System.EventArgs e)
        {
            App.Locator.HomeViewModel.IsPresented = !App.Locator.HomeViewModel.IsPresented;
        }

        void GFT_Clicked(object sender, System.EventArgs e)
        {
            //Device.BeginInvokeOnMainThread(() => {
            //    try
            //    {
            //        ((MasterDetailPage)App.Current.MainPage).Detail.Navigation.PushAsync(new Views.MyWishesView());
            //    }
            //    catch (Exception ex)
            //    {
            //        App.Current.MainPage.Navigation.PushAsync(new Views.MyWishesView());
            //    }
            //});
        }

        void OpenHistory(object sender, System.EventArgs e)
        {
            Device.BeginInvokeOnMainThread(() => App.Current.MainPage.Navigation.PushAsync(new UserWishesHistryView(), true));
        }
    }
}