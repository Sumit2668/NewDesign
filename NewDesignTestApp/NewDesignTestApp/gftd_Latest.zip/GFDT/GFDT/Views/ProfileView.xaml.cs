﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Xamarin.Forms;
using Xamarin.Forms.PlatformConfiguration.iOSSpecific;

namespace GFDT.Views
{
    public partial class ProfileView : ContentPage
    {

        List<MyTestModel> myTests = new List<MyTestModel>();
        public ProfileView()
        {
            InitializeComponent();
            On<Xamarin.Forms.PlatformConfiguration.iOS>().SetUseSafeArea(true);
            BindingContext = App.Locator.EditProfileViewModel;

            myTests.Add(new MyTestModel() { Image = "i1.png", Name = "Ice Cream Sandwich" });
            myTests.Add(new MyTestModel() { Image = "i2.png", Name = "Ice Cream Sandwich" });
            myTests.Add(new MyTestModel() { Image = "i1.png", Name = "Ice Cream Sandwich" });
            myTests.Add(new MyTestModel() { Image = "i2.png", Name = "Ice Cream Sandwich" });
            myTests.Add(new MyTestModel() { Image = "i1.png", Name = "Ice Cream Sandwich" });
            myTests.Add(new MyTestModel() { Image = "i2.png", Name = "Ice Cream Sandwich" });
            myTests.Add(new MyTestModel() { Image = "i1.png", Name = "Ice Cream Sandwich" });
            myTests.Add(new MyTestModel() { Image = "i2.png", Name = "Ice Cream Sandwich" });
            myTests.Add(new MyTestModel() { Image = "i1.png", Name = "Ice Cream Sandwich" });
            myTests.Add(new MyTestModel() { Image = "i2.png", Name = "Ice Cream Sandwich" });
            myTests.Add(new MyTestModel() { Image = "i1.png", Name = "Ice Cream Sandwich" });
            myTests.Add(new MyTestModel() { Image = "i2.png", Name = "Ice Cream Sandwich" });
            myTests.Add(new MyTestModel() { Image = "i1.png", Name = "Ice Cream Sandwich" });
            myTests.Add(new MyTestModel() { Image = "i2.png", Name = "Ice Cream Sandwich" });

            WishList.ItemsSource = App.Locator.EditProfileViewModel.MyWishlist;
            
        }
        private async void mywishes_Tapped(object sender, EventArgs e)
        {
            WishList.IsVisible = true;
            mywishes.FontAttributes = FontAttributes.Bold;
            gtfdFriend.FontAttributes = FontAttributes.None;
            await Task.WhenAll(
            mainbox.TranslateTo(0, 0, 120, Easing.SinOut));
            mywishes.TextColor = Color.FromHex("#0080b1");
            gtfdFriend.TextColor = Color.FromHex("#808080");
        }
        private async void gtfdFriend_Tapped(object sender, EventArgs e)
        {
            WishList.IsVisible = false;
            gtfdFriend.FontAttributes = FontAttributes.Bold;
            mywishes.FontAttributes = FontAttributes.None;
            await Task.WhenAll(
            mainbox.TranslateTo(mainbox.Width + 32, 0, 120, Easing.SinOut));
            mywishes.TextColor = Color.FromHex("808080");
            gtfdFriend.TextColor = Color.FromHex("#0080b1");
        }


        void Handle_Tapped(object sender, System.EventArgs e)
        {
            //App.Locator.HomeViewModel.IsPresented = !App.Locator.HomeViewModel.IsPresented;
            Device.BeginInvokeOnMainThread
                (() => this.Navigation.PopAsync(true));
        }
    }
}