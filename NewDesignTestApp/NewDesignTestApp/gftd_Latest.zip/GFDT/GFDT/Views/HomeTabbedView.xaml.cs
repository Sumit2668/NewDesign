﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Xamarin.Forms;
using Xamarin.Forms.PlatformConfiguration.iOSSpecific;
using Xamarin.Forms.Xaml;

namespace GFDT.Views
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class HomeTabbedView : TabbedPage
    {
        public HomeTabbedView()
        {
            InitializeComponent();
            On<Xamarin.Forms.PlatformConfiguration.iOS>().SetUseSafeArea(true);
            Xamarin.Forms.NavigationPage.SetHasNavigationBar(this, false);
            this.Children.Add(new  Views.FeedView());
            this.Children.Add(new Views.FriendsView());
            this.Children.Add(App.SendGiftNavigationPage);
            this.Children.Add(new Views.MyWishesView());
            //this.Children.Add(new Views.NotificationView());
            this.Children.Add(new Views.MoreView());

            BarBackgroundColor = Color.WhiteSmoke;
            BarTextColor = Color.FromHex("#009FDE");
            //Children.Insert(4, new MoreView());
            this.CurrentPageChanged += (s, e) =>
            {
                if (CurrentPage is Views.MoreView)
                {
                    Device.BeginInvokeOnMainThread(() =>
                    {
                        this.SelectedItem = this.Children[2];
                        CurrentPage = this.Children[2];
                        App.Locator.HomeViewModel.IsPresented = true;
                    });
                }
            };
        }
    }
}
