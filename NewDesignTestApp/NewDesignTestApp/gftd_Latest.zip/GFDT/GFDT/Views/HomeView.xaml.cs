﻿using Acr.UserDialogs;
using System;
using System.Collections.Generic;

using Xamarin.Forms;
using Xamarin.Forms.PlatformConfiguration.iOSSpecific;
using System.Linq;

namespace GFDT.Views
{
    public partial class HomeView : MasterDetailPage
    {
        Xamarin.Forms.ListView menuList;
        HomeTabbedView views;
        public HomeView()
        {
            InitializeComponent();
            Xamarin.Forms.NavigationPage.SetHasNavigationBar(this, false);
            On<Xamarin.Forms.PlatformConfiguration.iOS>().SetUseSafeArea(true);
            BindingContext = App.Locator.HomeViewModel;
            menuList = masterMenuPage.Content.FindByName<Xamarin.Forms.ListView>("lstMenu");
            views = new Views.HomeTabbedView();

            Detail = new Xamarin.Forms.NavigationPage(views);
            //v.ItemSelected += async (sender, e) => NavigateTo(e.SelectedItem as Menu);
            menuList.ItemTapped += (sender, e) => NavigateTo(e.Item as ViewModels.Menu);
            this.SetBinding(MasterDetailPage.IsPresentedProperty, "IsPresented");

        }
        protected override void OnAppearing()
        {
            try
            {


                base.OnAppearing();
                Device.BeginInvokeOnMainThread(() =>
                {
                    views.SelectedItem = views.Children[2];
                    //((TabbedPage)((MasterDetailPage)this).Detail).SelectedItem = views.Children[2];//.TabIndex = 2;
                });
            }
            catch (Exception ex)
            {

            }
        }
        async void NavigateTo(ViewModels.Menu menu)
        {
            App.Locator.HomeViewModel.IsPresented = false;
            Device.BeginInvokeOnMainThread(async () =>
            {
                if (menu != null)
                {
                    if (menu.TargetType == typeof(EditProfileView))
                    {
                        Device.BeginInvokeOnMainThread(() =>
                        {
                            App.Locator.EditProfileViewModel.ProfileinfoCommand.Execute(null);
                        });
                    }
                    if (menu.TargetType == typeof(WishListPrivacyView))
                    {
                        Device.BeginInvokeOnMainThread(() =>
                        {
                            App.SendGiftNavigationPage.Navigation.PushAsync(new Views.WishListPrivacyView());
                        });
                    }
                    if (menu.TargetType == typeof(NotificationView))
                    {
                        Device.BeginInvokeOnMainThread(() =>
                        {
                            App.SendGiftNavigationPage.Navigation.PushAsync(new Views.NotificationView());
                        });
                    }
                    if (menu.TargetType == typeof(StoreView))
                    {
                        Device.BeginInvokeOnMainThread(() =>
                        {
                            App.SendGiftNavigationPage.Navigation.PushAsync(new Views.StoreView());
                        });
                    }
                    if (menu.TargetType == typeof(TransactionView))
                    {
                        Device.BeginInvokeOnMainThread(() =>
                        {
                            App.SendGiftNavigationPage.Navigation.PushAsync(new Views.TransactionView());
                        });
                    }
                    if (menu.TargetType == typeof(AddItemView))
                    {
                        Device.BeginInvokeOnMainThread(() =>
                        {
                            App.SendGiftNavigationPage.Navigation.PushAsync(new Views.AddItemView());
                        });
                    }
                    if (menu.TargetType == typeof(Contactus))
                    {
                        Device.BeginInvokeOnMainThread(() =>
                        {
                            App.SendGiftNavigationPage.Navigation.PushAsync(new Views.Contactus());
                        });
                    }
                    if (menu.TargetType == typeof(LoginView))
                    {
                        Device.BeginInvokeOnMainThread(() =>
                        {
                            Xamarin.Essentials.Preferences.Set("IsLogin", false);
                            try
                            {
                                App.Current.MainPage = new Xamarin.Forms.NavigationPage(new Views.LoginView());

                            }
                            catch (Exception ex)
                            {
                            }
                            // var nav = App.Current.MainPage.Navigation.NavigationStack.Where(x => x is LoginView).FirstOrDefault();
                            //
                            // if (nav == null)
                            // {
                            //     try
                            //     {
                            //         App.Current.MainPage.Navigation.PushAsync(new Views.LoginView());
                            //         
                            //     }
                            //     catch (Exception ex)
                            //     {
                            //         ((MasterDetailPage)App.Current.MainPage).Detail.Navigation.PushAsync(new Views.LoginView());
                            //     }
                            // }
                            // else
                            // {
                            //     try
                            //     {
                            //         ((MasterDetailPage)App.Current.MainPage).Detail.Navigation.PushAsync(new Views.LoginView());
                            //     }
                            //     catch (Exception ex)
                            //     {
                            //         App.Current.MainPage.Navigation.PushAsync(new Views.LoginView());
                            //     }
                            // }
                        });
                    }
                    else if (menu.TargetType == typeof(UnderDevelopment))
                    {
                        Device.BeginInvokeOnMainThread(() =>
                        {
                            App.SendGiftNavigationPage.Navigation.PushAsync(new Views.UnderDevelopment());
                        });
                    }
                    else if (menu.TargetType == typeof(PrivacyPolicy))
                    {
                        Device.BeginInvokeOnMainThread(() =>
                        {
                            App.SendGiftNavigationPage.Navigation.PushAsync(new Views.PrivacyPolicy());
                        });
                    }


                    else if (menu.TargetType == typeof(TermsandConditionsView))
                    {
                        Device.BeginInvokeOnMainThread(() =>
                        {
                            App.SendGiftNavigationPage.Navigation.PushAsync(new Views.TermsandConditionsView());
                        });
                    }

                    else if (menu.TargetType == typeof(DeleteAccountView))
                    {
                        Device.BeginInvokeOnMainThread(async () =>
                        {
                            var result = await UserDialogs.Instance.ConfirmAsync(
                                new ConfirmConfig
                                {
                                    Title = "Delete Account",
                                    Message = "Do you want to delete account?",
                                    CancelText = "No",
                                    OkText = "Yes",
                                });
                            if (result)
                            {
                                App.Locator.LoginViewModel.DeleteAccountCommandExecution(null);
                            }
                        });
                    }
                    else if (menu.TargetType == typeof(BankDetailView))
                    {
                        Device.BeginInvokeOnMainThread(async () =>
                        {
                            await Xamarin.Essentials.Share.RequestAsync("Share App", "GFTD");
                        });
                    }
                    else if (menu.TargetType == typeof(Nullable))
                    {
                        App.Locator.HomeViewModel.IsPresented = false;
                    }
                }
            });
        }
    }
}