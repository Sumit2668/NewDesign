﻿using System;
using System.Collections.Generic;

using Xamarin.Forms;
using Xamarin.Forms.PlatformConfiguration.iOSSpecific;

namespace GFDT.Views
{
    public partial class CompleteProfileView : ContentPage
    {
        public CompleteProfileView()
        {
            InitializeComponent();
            On<Xamarin.Forms.PlatformConfiguration.iOS>().SetUseSafeArea(true);
            BindingContext = App.Locator.LoginViewModel;

            //txtConPsw.Unfocused += async(s, e) =>
            //  {
            //      if(txtPsw.Text != txtConPsw.Text)
            //      {
            //          await DisplayAlert("", "Confirm password not matched.", "Okay");
            //          App.Locator.LoginViewModel.Password = App.Locator.LoginViewModel.ConUserpassword = string.Empty;
            //      }
            //  };
        }
    }
}