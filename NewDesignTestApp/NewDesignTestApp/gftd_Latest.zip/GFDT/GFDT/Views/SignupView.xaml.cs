﻿using System;
using System.Collections.Generic;

using Xamarin.Forms;
using Xamarin.Forms.PlatformConfiguration.iOSSpecific;
using Xamarin.Forms.Xaml;

namespace GFDT.Views
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class SignupView : ContentPage
    {
        public SignupView()
        {
            InitializeComponent();
            On<Xamarin.Forms.PlatformConfiguration.iOS>().SetUseSafeArea(true);
            App.Locator.LoginViewModel.PhoneNumber = "";
           BindingContext = App.Locator.LoginViewModel;

           // var vv= App.Locator.LoginViewModel.GetCurrentUser();
        }

        protected override void OnAppearing()
        {
            base.OnAppearing();
          
        }

        //private void RoundedEntry_Focused(object sender, FocusEventArgs e)
        //{
        //    pickCountry.Focus();
        //    entryCountryCode.Unfocus();
        //}
    }
}
