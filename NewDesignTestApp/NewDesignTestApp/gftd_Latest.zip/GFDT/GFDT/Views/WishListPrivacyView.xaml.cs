﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Xamarin.Forms;
using Xamarin.Forms.PlatformConfiguration.iOSSpecific;
using Xamarin.Forms.Xaml;

namespace GFDT.Views
{
	[XamlCompilation(XamlCompilationOptions.Compile)]
	public partial class WishListPrivacyView : ContentPage
	{
		public WishListPrivacyView ()
		{
			InitializeComponent ();
            On<Xamarin.Forms.PlatformConfiguration.iOS>().SetUseSafeArea(true);
        }

        private void AllContactsExceptSelectedContacts_Tapped(object sender, EventArgs e)
        {

            var stk = (Grid)sender;
            var img = stk.Children[0] as Image;
            //FileImageSource source = (FileImageSource)(img).Source;
            //string fileName = source.File;


            rdbAllContacts.Source = "radio_unselect.png";
            rdbSelectedContacts.Source = "radio_unselect.png";
            rdbAllContactsExceptSelectedContacts.Source = "radio_unselect.png";

            img.Source = "radio_select.png";
        }
        void Handle_Tapped(object sender, System.EventArgs e)
        {
            //App.Locator.HomeViewModel.IsPresented = !App.Locator.HomeViewModel.IsPresented;
            Device.BeginInvokeOnMainThread
                (() =>this.Navigation.PopAsync(true ));
        }
    }
}