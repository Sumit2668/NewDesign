﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Xamarin.Forms;
using Xamarin.Forms.PlatformConfiguration.iOSSpecific;
using Xamarin.Forms.Xaml;

namespace GFDT.Views
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class AddItemView : ContentPage
    {
        public AddItemView()
        {
            InitializeComponent();
            On<Xamarin.Forms.PlatformConfiguration.iOS>().SetUseSafeArea(true);
            BindingContext = App.Locator.AddItemViewModel;
        }
        void Handle_Tapped(object sender, System.EventArgs e)
        {
            Device.BeginInvokeOnMainThread(() =>
            {
                // App.Locator.HomeViewModel.IsPresented = !App.Locator.HomeViewModel.IsPresented;
                this.Navigation.PopAsync(true);
            });
        }
        private async void AddPicture_Tapped(object sender, EventArgs e)
        {
            var actionSheet = await DisplayActionSheet("", "Cancel", null, new string[] { "Take Picture", "Select Picture" });
            if (actionSheet == "Select Picture")
            {
                App.Locator.AddItemViewModel.PickPhotoCommand.Execute(null);
            }
            else if (actionSheet == "Take Picture")
            {
                App.Locator.AddItemViewModel.TakePicture.Execute(null);
            }
        }
    }
}