using System;
using System.Collections.Generic;

using Xamarin.Forms;
using Xamarin.Forms.PlatformConfiguration.iOSSpecific;

namespace GFDT.Views
{
    public partial class OTPVerficationView : ContentPage
    {
       
        public OTPVerficationView()
        {
            InitializeComponent();
            On<Xamarin.Forms.PlatformConfiguration.iOS>().SetUseSafeArea(true);
            App.Locator.LoginViewModel.ClearOtp();
            BindingContext = App.Locator.LoginViewModel;
            
            txt1.TextChanged += (s, e) =>
            {
                var tt = (Xamarin.Forms.Entry)s;
                if (tt.Text == "")
                    txt1.Focus();
                else
                txt2.Focus();
             };
            txt2.TextChanged += (s, e) =>
            {
                var tt = (Xamarin.Forms.Entry)s;
                if (tt.Text == "")
                    txt1.Focus();
                else
                    txt3.Focus();
            };
            txt3.TextChanged += (s, e) =>
            {
                var tt = (Xamarin.Forms.Entry)s;
                if (tt.Text == "")
                    txt2.Focus();
                else
                    txt4.Focus();
            };
            txt4.TextChanged += (s, e) =>
            {
                var tt = (Xamarin.Forms.Entry)s;
                if (tt.Text == "")               
                    txt3.Focus();
            };

            txt2.OnBackspace += (s, e) =>
            {
                var tt = (Xamarin.Forms.Entry)s;
                if (tt.Text == "")
                    txt1.Focus();
               
            };
            txt3.OnBackspace += (s, e) =>
            {
                var tt = (Xamarin.Forms.Entry)s;
                if (tt.Text == "")
                    txt2.Focus();

            };
            txt4.OnBackspace += (s, e) =>
            {
                var tt = (Xamarin.Forms.Entry)s;
                if (tt.Text == "")
                    txt3.Focus();
            };

        }

    }
}
