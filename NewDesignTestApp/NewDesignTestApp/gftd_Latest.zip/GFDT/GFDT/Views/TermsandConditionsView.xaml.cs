﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace GFDT.Views
{
	[XamlCompilation(XamlCompilationOptions.Compile)]
	public partial class TermsandConditionsView : ContentPage
	{
		public TermsandConditionsView ()
		{
			InitializeComponent (); 
            App.Locator.PrivacyPolicyViewModel.GetPrivacyPolicy("http://13.234.81.74/gifted/public/index.php/terms-condition");
            BindingContext = App.Locator.PrivacyPolicyViewModel;
            var pp = App.Locator.PrivacyPolicyViewModel.PrivacyPolicyies;
            var htmlSource = new HtmlWebViewSource();
            htmlSource.Html = pp;
            webView.Source = htmlSource;
        }

        void Handle_Tapped(object sender, System.EventArgs e)
        {
            Device.BeginInvokeOnMainThread(() =>
            {
                // App.Locator.HomeViewModel.IsPresented = !App.Locator.HomeViewModel.IsPresented;
                this.Navigation.PopAsync(true);
            });
        }
    }
}