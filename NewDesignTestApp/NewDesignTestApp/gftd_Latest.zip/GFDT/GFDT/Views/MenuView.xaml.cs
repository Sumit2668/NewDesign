﻿using System;
using System.Collections.Generic;

using Xamarin.Forms;
using Xamarin.Forms.PlatformConfiguration.iOSSpecific;

namespace GFDT.Views
{
    public partial class MenuView : ContentPage
    {
        public MenuView()
        {
            InitializeComponent();
            Xamarin.Forms.NavigationPage.SetHasNavigationBar(this, false);
            On<Xamarin.Forms.PlatformConfiguration.iOS>().SetUseSafeArea(true);
            BindingContext  = App.Locator.HomeViewModel;
       }
        //Anupam
        void OpenProfile(object sender, System.EventArgs e)
        {
            Device.BeginInvokeOnMainThread(async() =>
            {
                App.Locator.HomeViewModel.IsPresented = !App.Locator.HomeViewModel.IsPresented;
                App.Locator.EditProfileViewModel.SetProfileInfoCommand.Execute(null);
                try
                {
                    // ((MasterDetailPage)App.Current.MainPage).Detail.Navigation.PushAsync(new HomeView());
                    ((MasterDetailPage)App.Current.MainPage).Detail.Navigation.PushAsync(new Views.ProfileView());
                }
                catch (Exception ex)
                {
                    App.Current.MainPage.Navigation.PushAsync(new Views.ProfileView());
                }


                //   await ((MasterDetailPage)App.Current.MainPage).Detail.Navigation.PushAsync(new Views.ProfileView());
                // await App.SendGiftNavigationPage.Navigation.PushAsync(new Views.ProfileView()); 
                //App.Current.MainPage.Navigation.PushAsync(new ProfileView(), true);

            });
        }
        void Menu_Tapped(object sender, System.EventArgs e)
        {
            Device.BeginInvokeOnMainThread(async() =>
            {
                App.Locator.HomeViewModel.IsPresented = false;

            });
        }
    }
}
