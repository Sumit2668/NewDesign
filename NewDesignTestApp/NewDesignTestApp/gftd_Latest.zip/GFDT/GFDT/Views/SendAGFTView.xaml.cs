﻿


using GFDT.Models.Response;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Xamarin.Forms;
using Xamarin.Forms.PlatformConfiguration.iOSSpecific;
using Xamarin.Forms.Xaml;

namespace GFDT.Views
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class SendAGFTView : ContentPage
    {
        public SendAGFTView()
        {
            InitializeComponent();
            On<Xamarin.Forms.PlatformConfiguration.iOS>().SetUseSafeArea(true);
            BindingContext = App.Locator.SendAGFTViewModel;
        }

        private void pickWishList_Tapped(object sender, EventArgs e)
        {
            pickWishList.Focus();
        }

        private void radioUnselect_Tapped(object sender, EventArgs e)
        {
            var stk = (StackLayout)sender;
            var img = stk.Children[0] as Image;
            FileImageSource source = (FileImageSource)(img).Source;
            string fileName = source.File;
            var vm = App.Locator.SendAGFTViewModel;
            if (fileName == "radio_unselect.png")
            {
                vm.Privacy = "0";
                (img).Source = "radio_select.png";
                radio_select.Source = "radio_unselect.png";

            }
            else
            {
                vm.Privacy = "1";
                (img).Source = "radio_unselect.png";
                radio_select.Source = "radio_select.png";
            }

        }

        private void radioSelect_Tapped(object sender, EventArgs e)
        {
            var stk = (StackLayout)sender;
            var img = stk.Children[0] as Image;
            FileImageSource source = (FileImageSource)(img).Source;
            string fileName = source.File;
            var vm = App.Locator.SendAGFTViewModel;
            if (fileName == "radio_select.png")
            {
                vm.Privacy = "1";
                (img).Source = "radio_unselect.png";
                radio_unselect.Source = "radio_select.png";
            }
            else
            {
                vm.Privacy = "0";
                (img).Source = "radio_select.png";
                radio_unselect.Source = "radio_unselect.png";
            }
        }
        void Handle_Tapped(object sender, System.EventArgs e)
        {
            //App.Locator.HomeViewModel.IsPresented = !App.Locator.HomeViewModel.IsPresented;
            Device.BeginInvokeOnMainThread
                (() => this.Navigation.PopAsync(true));
        }
        private async void AddPicture_Tapped(object sender, EventArgs e)
        {
            var actionSheet = await DisplayActionSheet("", "Cancel", null, new string[] { "Take Picture", "Select Picture" });
            if (actionSheet == "Select Picture")
            {
                App.Locator.SendAGFTViewModel.PickPhotoCommand.Execute(null);
            }
            else if (actionSheet == "Take Picture")
            {
                App.Locator.SendAGFTViewModel.TakePhotoCommand.Execute(null);
            }
        }

        private void PickWishList_SelectedIndexChanged(object sender, EventArgs e)
        {
            var vm = App.Locator.SendAGFTViewModel;
            var itemsSource = ((Xamarin.Forms.Picker)sender).SelectedItem as MyWishStoreList;
            //Anupam
            if (itemsSource != null)
            { 
                vm.ProductId = Convert.ToString(itemsSource.id);
                edkWishList.Text = itemsSource.product_name;
                App.Locator.SendAGFTViewModel.Tax = itemsSource.product_tax == null ? "0" : itemsSource.product_tax;
            }
        }

        private void pickOwnGft_SelectedIndexChanged(object sender, EventArgs e)
        {
            var vm = App.Locator.SendAGFTViewModel;
            var itemsSource = ((Xamarin.Forms.Picker)sender).SelectedItem as GetList;

            vm.WishId = Convert.ToString(itemsSource.id);
            entryPickOwnGft.Text = itemsSource.product_name;

        }

        private void pickTax_SelectedIndexChanged(object sender, EventArgs e)
        {
            var vm = App.Locator.SendAGFTViewModel;
            var itemsSource = ((Xamarin.Forms.Picker)sender).SelectedItem as MyWishStoreList;
            vm.Tax = Convert.ToString(itemsSource.product_tax);
            entrypickTax.Text = itemsSource.product_tax;
        }

        private void pickOwnGft_Tapped(object sender, EventArgs e)
        {
            pickOwnGft.Focus();
        }

        private void pickTax_Tapped(object sender, EventArgs e)
        {
            pickTax.Focus();
        }

        private void pickTip_Tapped(object sender, EventArgs e)
        {
            pickTip.Focus();

        }

        private void txtPrice_TextChanged(object sender, TextChangedEventArgs e)
        {
            double num;
            if (!double.TryParse(e.NewTextValue, out num))
            {
                ((Xamarin.Forms.Entry)sender).Text = e.OldTextValue;
            }
        }
    }
}