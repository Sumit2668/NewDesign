﻿
using Android.App;
using Android.Content.PM;
using Android.OS;
using Acr.UserDialogs;

namespace GFDT.Droid
{
    [Activity(Label = "GFDT", Icon = "@mipmap/icon", Theme = "@style/MainTheme", MainLauncher = true, ConfigurationChanges = ConfigChanges.ScreenSize | ConfigChanges.Orientation)]
    public class MainActivity : global::Xamarin.Forms.Platform.Android.FormsAppCompatActivity
    {
        protected override void OnCreate(Bundle savedInstanceState)
        {
            TabLayoutResource = Resource.Layout.Tabbar;
            ToolbarResource = Resource.Layout.Toolbar;

            base.OnCreate(savedInstanceState);
            global::Xamarin.Forms.Forms.SetFlags("CollectionView_Experimental");
            


            Firebase.FirebaseApp.InitializeApp(this);

            UserDialogs.Init(this);
            global::Xamarin.Forms.Forms.Init(this, savedInstanceState);
            LoadApplication(new App());
        }


        //<!--<meta-data android:name="com.google.android.maps.v2.API_KEY" android:value="AIzaSyB3qkZLipBcG9aC4xJHRUI2i0cx7uW1oXw" />-->
        //<receiver android:name="com.google.firebase.iid.FirebaseInstanceIdInternalReceiver" android:exported="true" />
        //<receiver android:name="com.google.firebase.iid.FirebaseInstanceIdReceiver" android:exported="true" android:permission="com.google.android.c2dm.permission.SEND">
        //    <intent-filter>
        //        <action android:name="com.google.android.c2dm.intent.RECEIVE" />
        //        <action android:name="com.google.android.c2dm.intent.REGISTRATION" />
        //        <category android:name="${applicationId}" />
        //    </intent-filter>
        //</receiver>


        public bool IsPlayServicesAvailable()
        {
            return true;
            //int resultCode = GoogleApiAvailability.Instance.IsGooglePlayServicesAvailable(this);
            //try
            //{
            //    var refreshedToken = Firebase.Iid.FirebaseInstanceId.Instance.Token;
            //    if (!string.IsNullOrEmpty(refreshedToken))
            //        var DeviceId = refreshedToken;
            //}
            //catch (Exception ex)
            //{

            //}
            //if (resultCode != ConnectionResult.Success)
            //{
            //    if (GoogleApiAvailability.Instance.IsUserResolvableError(resultCode))
            //        Log.Debug("GoogleApiAvailability", GoogleApiAvailability.Instance.GetErrorString(resultCode));
            //    else
            //    {
            //        Log.Debug("Avai", "This device is not supported");
            //        Finish();
            //    }
            //    return false;
            //}
            //else
            //{
            //    Log.Debug("GooglePlay", "Google Play Services is available.");
            //    return true;
            //}
        }
    }
}