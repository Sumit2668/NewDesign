﻿using System;
using Android.App;
using Firebase.Iid;
using Android.Util;

namespace TasitoForms.Droid
{
    [Service]
    [IntentFilter(new[] { "com.google.firebase.INSTANCE_ID_EVENT" })]
    public class MyFirebaseIIDService : FirebaseInstanceIdService
    {
        const string TAG = "MyFirebaseIIDService";
        public override void OnTokenRefresh()
         {
            var refreshedToken = FirebaseInstanceId.Instance.Token;
            if (!string.IsNullOrEmpty(refreshedToken))
               // var DeviceId = refreshedToken;

            Log.Debug(TAG, "Refreshed token: " + refreshedToken);
            System.Diagnostics.Debug.WriteLine(TAG, "Refreshed token: " + refreshedToken);
            SendRegistrationToServer(refreshedToken);
        }
        void SendRegistrationToServer(string token)
        {
            // Add custom implementation, as needed.
        }
    }
}