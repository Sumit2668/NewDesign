using System;
using Android.App;
using Android.Content;
using Android.Media;
using Android.Util;
using Firebase.Messaging;
using Android.Graphics;
using Android.Support.V7.App;
using Android.Widget;
using Android.OS;
using Android.Support.V4.App;

namespace GFDT.Droid
{
    [Service]
    [IntentFilter(new[] { "com.google.firebase.MESSAGING_EVENT" })]
    public class MyFirebaseMessagingService : FirebaseMessagingService
    {
        const string TAG = "MyFirebaseMsgService";
        NotificationCompat.Builder notificationBuilder;
        NotificationManager notificationManager;
        public override void OnMessageReceived(RemoteMessage message)
        {
            try
            {
                //Log.Debug(TAG, "From: " + message.From);
                //Log.Debug(TAG, "Notification Message Body: " + message.GetNotification().Body);
                SendNotification(message);
            }
            catch (Exception ex)
            {
              
            }
        }

        async void SendNotification(RemoteMessage message)
        {
            var intent = new Intent(this, typeof(MainActivity));
            intent.AddFlags(ActivityFlags.SingleTop);
            var pendingIntent = PendingIntent.GetActivity(this, 0, intent, PendingIntentFlags.OneShot);

            if (Build.VERSION.SdkInt >= BuildVersionCodes.O)
            {
                string channel_id = Application.PackageName;
                string channel_name = PackageManager.GetApplicationLabel(PackageManager.GetPackageInfo(PackageName, 0).ApplicationInfo);// "Friendly Foods";
                string channel_description = PackageManager.GetApplicationLabel(PackageManager.GetPackageInfo(PackageName, 0).ApplicationInfo);// "Friendly Foods";
                var channel = new NotificationChannel(channel_id, channel_name, NotificationImportance.High)
                {
                    Description = channel_description,
                    LockscreenVisibility = NotificationVisibility.Public,
                };

                notificationManager = (NotificationManager)GetSystemService(NotificationService);
                notificationManager.CreateNotificationChannel(channel);

                notificationBuilder = new NotificationCompat.Builder(this, channel_id)
                        .SetSmallIcon(Resource.Drawable.share_app)
                        .SetContentTitle(message.Data["title"])
                        .SetContentText(message.Data["body"])
                        .SetAutoCancel(true)
                        .SetVibrate(new long[] { 1000, 1000, 1000, 1000, 1000 })
                        .SetContentIntent(pendingIntent);

                NotificationManager nManager =
                        (NotificationManager)GetSystemService(Context.NotificationService);
                nManager.Notify(0, notificationBuilder.Build());
            }
            else
            {               
                    //intent.PutExtra("LiveOrder", "LiveOrder");
                    notificationBuilder = new NotificationCompat.Builder(this)
                       .SetSmallIcon(Resource.Drawable.share_app)
                       .SetContentTitle(message.Data["title"])
                       .SetContentText(message.Data["body"])
                               .SetAutoCancel(false)
                               .SetContentIntent(pendingIntent);
                notificationManager = NotificationManager.FromContext(this);
                notificationManager.Notify(0, notificationBuilder.Build());
            }
        }
    }
}
