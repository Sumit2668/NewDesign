﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Android.App;
using Android.Content;
using Android.Graphics;
using Android.Net;
using Android.OS;
using Android.Runtime;
using Android.Views;
using Android.Widget;
using GFDT.Droid.Dependency;
using GFDT.Services;

[assembly: Xamarin.Forms.Dependency(typeof(MediaService))]
namespace GFDT.Droid.Dependency
{
    public class MediaService : IMediaService
    {
        public MediaService()
        {

        }
        private readonly string _rootDir = System.IO.Path.Combine(Android.OS.Environment.ExternalStorageDirectory.Path, "pdfjs");
        public string ViewMediaInPdf(byte[] fileStream, string fileName)
        {
            try
            {
                if (fileStream != null)
                {
                    string externalStorageState = global::Android.OS.Environment.ExternalStorageState;
                    var externalPath = global::Android.OS.Environment.ExternalStorageDirectory.Path + "/" + fileName + ".pdf";
                    File.WriteAllBytes(externalPath, fileStream);
                    return (externalPath);
                }
                return string.Empty;
            }
            catch
            {
                Toast.MakeText(Xamarin.Forms.Forms.Context, "No Application Available to View PDF", ToastLength.Short).Show();
                return string.Empty;
            }
        }

        public byte[] GetMediaInBytes(string filePath)
        {
            return File.ReadAllBytes(filePath);
        }

        //public SQLiteConnection SQLiteConnection()
        //{
        //    var sqliteFilename = "dbField.db3";
        //    string documentsPath = System.Environment.GetFolderPath(System.Environment.SpecialFolder.Personal); // Documents folder
        //    var path = System.IO.Path.Combine(documentsPath, sqliteFilename);
        //    // Create the connection
        //    //var plat = new  Platform.SQLitePlatformAndroid();
        //    var conn = new SQLiteConnection(path);
        //    // Return the database connection 
        //    return conn;
        //}

        public string ViewMediaInPNG(byte[] fileStream, string fileName)
        {
            try
            {
                if (fileStream != null)
                {
                    string externalStorageState = global::Android.OS.Environment.ExternalStorageState;
                    var externalPath = global::Android.OS.Environment.ExternalStorageDirectory.Path + "/" + fileName + ".png";
                    File.WriteAllBytes(externalPath, fileStream);
                    return (externalPath);
                }
                return string.Empty;
            }
            catch
            {
                Toast.MakeText(Xamarin.Forms.Forms.Context, "No Application Available to View PNG", ToastLength.Short).Show();
                return string.Empty;
            }
        }



        public async Task<string> SaveFileToDisk(Stream pdfStream, string fileName)
        {
            if (!Directory.Exists(_rootDir))
                Directory.CreateDirectory(_rootDir);

            var filePath = System.IO.Path.Combine(_rootDir, fileName);

            using (var memoryStream = new MemoryStream())
            {
                await pdfStream.CopyToAsync(memoryStream);
                File.WriteAllBytes(filePath, memoryStream.ToArray());
            }

            return filePath;
        }

        public byte[] ResizeImage(byte[] imageStream, float width, float height)
        {
            // Load the bitmap
            Bitmap originalImage = BitmapFactory.DecodeByteArray(imageStream, 0, imageStream.Length);
            Bitmap resizedImage = Bitmap.CreateScaledBitmap(originalImage, (int)width, (int)height, false);

            using (MemoryStream ms = new MemoryStream())
            {
                resizedImage.Compress(Bitmap.CompressFormat.Jpeg, 100, ms);
                return ms.ToArray();
            }
        }

        public async Task<bool> CheckNewworkConnectivity()
        {
            var connectivityManager = (ConnectivityManager)Application.Context.GetSystemService(Context.ConnectivityService);
            var activeNetworkInfo = connectivityManager.ActiveNetworkInfo;
            if (activeNetworkInfo != null && activeNetworkInfo.IsConnectedOrConnecting)
            {
                return true;
            }
            return false;
        }


    }
}