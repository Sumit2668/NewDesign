﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;

using Android.App;
using Android.Content;
using System;
using System.Collections.Generic;
using System.IO;
using Xamarin.Forms;
using GFDT.Droid.Dependency;
using GFDT.Services;

[assembly: Dependency(typeof(PathService))]
namespace GFDT.Droid.Dependency
{
    public class PathService : IPathService
    {
        public string GetDatabasePath()
        {
            string path = Environment.GetFolderPath(Environment.SpecialFolder.Personal);
            return Path.Combine(path, "gftd.db3");
        }
    }
}