﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Views;
using Android.Widget;

namespace XamarinShellApp.Droid
{
    [Activity(Theme = "@style/Theme.Splash",  NoHistory = true,
        MainLauncher = true)]
    public class SplashScreenActivity : Activity
    {
        protected async override void OnCreate(Bundle savedInstanceState)
        {
            base.OnCreate(savedInstanceState);

            await Task.Delay(2000); //Let's wait awhile...
            this.StartActivity(typeof(MainActivity));
        }
    }
}