﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;
using Xamarin.Forms;
using Xamarin.Forms.Xaml;
using XamarinShellApp.Models;
using XamarinShellApp.Views;

namespace XamarinShellApp
{
	[XamlCompilation(XamlCompilationOptions.Compile)]
	public partial class AppShell :Shell
    {
        public List<ListItem> DataItems { get; private set; }

        Random rand = new Random();
        Dictionary<string, Type> routes = new Dictionary<string, Type>();
        public ICommand HelpCommand => new Command<string>((url) => Device.OpenUri(new Uri(url)));
        public ICommand RandomPageCommand => new Command(async () => await NavigateToRandomPageAsync());

        public AppShell ()
		{
			InitializeComponent ();
            RegisterRoutes();
            BindingContext = this;
            //BindingContext = new AppShellViewModel();
            DataItems = new List<ListItem>();
            DataItems.Add(new ListItem() { ItemId = 1, ItemTitle = "Detail" });
            DataItems.Add(new ListItem() { ItemId = 2, ItemTitle = "Detail 1" });
            DataItems.Add(new ListItem() { ItemId = 3, ItemTitle = "Detail 2" });
            DataItems.Add(new ListItem() { ItemId = 4, ItemTitle = "Detail 3" });
            DataItems.Add(new ListItem() { ItemId = 5, ItemTitle = "Detail 4" });
            DataItems.Add(new ListItem() { ItemId = 6, ItemTitle = "Review" });
            itemlist.ItemsSource = DataItems;
        }

        void RegisterRoutes()
        {
            //routes.Add("monkeydetails", typeof(MonkeyDetailPage));
            //routes.Add("beardetails", typeof(BearDetailPage));
            //routes.Add("catdetails", typeof(CatDetailPage));
            //routes.Add("dogdetails", typeof(DogDetailPage));
            //routes.Add("elephantdetails", typeof(ElephantDetailPage));

            //foreach (var item in routes)
            //{
            //    Routing.RegisterRoute(item.Key, item.Value);
            //}
        }

        async Task NavigateToRandomPageAsync()
        {
            //string destinationRoute = routes.ElementAt(rand.Next(0, routes.Count)).Key;
            //string animalName = null;

            //switch (destinationRoute)
            //{
            //    case "monkeydetails":
            //        animalName = MonkeyData.Monkeys.ElementAt(rand.Next(0, MonkeyData.Monkeys.Count)).Name;
            //        break;
            //    case "beardetails":
            //        animalName = BearData.Bears.ElementAt(rand.Next(0, BearData.Bears.Count)).Name;
            //        break;
            //    case "catdetails":
            //        animalName = CatData.Cats.ElementAt(rand.Next(0, CatData.Cats.Count)).Name;
            //        break;
            //    case "dogdetails":
            //        animalName = DogData.Dogs.ElementAt(rand.Next(0, DogData.Dogs.Count)).Name;
            //        break;
            //    case "elephantdetails":
            //        animalName = ElephantData.Elephants.ElementAt(rand.Next(0, ElephantData.Elephants.Count)).Name;
            //        break;
            //}

            //ShellNavigationState state = Shell.Current.CurrentState;
            //await Shell.Current.GoToAsync($"{state.Location}/{destinationRoute}?name={animalName}");
            //Shell.Current.FlyoutIsPresented = false;
        }

        void OnNavigating(object sender, ShellNavigatingEventArgs e)
        {
            // Cancel any back navigation
            //if (e.Source == ShellNavigationSource.Pop)
            //{
            //    e.Cancel();
            //}
        }

        void OnNavigated(object sender, ShellNavigatedEventArgs e)
        {
        }

      

        private void Itemlist_ItemTapped(object sender, ItemTappedEventArgs e)
        {
            var sss = (ListView)sender ;
            var abc = sss.SelectedItem as ListItem;
            
            switch (abc.ItemTitle)
            {
                case "Item Detail":
                    Navigation.PushAsync(new DetailPage());
                    return;
                case "Detail 1":
                    Navigation.PushAsync(new DetailPage1());
                    return;
                case "Detail 2":
                    Navigation.PushAsync(new DetailPage2());
                    return;
                case "Detail 3":
                    Navigation.PushAsync(new DetailPage3());
                    return;
                case "Detail 4":
                    Navigation.PushAsync(new DetailPage());
                    return;
                case "Review":
                    {
                        this.IsVisible = false;
                    }
                    return;
            }
            }

        private void Itemlist_ItemSelected(object sender, SelectedItemChangedEventArgs e)
        {

        }
    }
}
public class ListItem
{
    public int ItemId { get; set; }
    public string ItemTitle { get; set; }
}