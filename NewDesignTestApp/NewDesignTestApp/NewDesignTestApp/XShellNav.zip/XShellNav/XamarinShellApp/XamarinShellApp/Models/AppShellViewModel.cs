﻿using Prism.Commands;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using Prism.Mvvm;
using System.Linq;
using Xamarin.Forms.Internals;

namespace XamarinShellApp.Models
{
    public class SelectCategoryViewModel
    {
        public Category Category { get; set; }
        public bool Selected { get; set; }
    }

    public class AppShellViewModel : BindableBase
    {
        public ObservableCollection<Grouping<SelectCategoryViewModel, Item>> Categories { get; set; }

        public DelegateCommand<Grouping<SelectCategoryViewModel, Item>> HeaderSelectedCommand
        {
            get
            {
                return new DelegateCommand<Grouping<SelectCategoryViewModel, Item>>(g =>
                {
                    if (g == null) return;
                    g.Key.Selected = !g.Key.Selected;
                    if (g.Key.Selected)
                    {
                        DataFactory.DataItems.Where(i => (i.Category.CategoryId == g.Key.Category.CategoryId)).ForEach(g.Add);
                    }
                    else
                    {
                        g.Clear();
                    }
                });
            }
        }

        public AppShellViewModel()
        {
            Categories = new ObservableCollection<Grouping<SelectCategoryViewModel, Item>>();
            var selectCategories =
                DataFactory.DataItems.Select(x => new SelectCategoryViewModel { Category = x.Category, Selected = false })
                    .GroupBy(sc => new { sc.Category.CategoryId }).Select(g => g.First()).ToList();
            selectCategories.ForEach(sc => Categories.Add(new Grouping<SelectCategoryViewModel, Item>(sc, new List<Item>())));
        }
    }
}
public class Grouping<TK, T> : ObservableCollection<T>
{
    public TK Key { get; private set; }

    public Grouping(TK key, IEnumerable<T> items)
    {
        Key = key;
        foreach (var item in items)
            Items.Add(item);
    }
}