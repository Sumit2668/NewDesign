﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using FieldDriverApp.CustomRenderer;
using FieldDriverApp.iOS.CustomRenderer;
using Foundation;
using UIKit;
using Xamarin.Forms;
using Xamarin.Forms.Platform.iOS;

[assembly: ExportRenderer(typeof(CustomFrame), typeof(CustomFrameRenderer))]
namespace FieldDriverApp.iOS.CustomRenderer
{
    public class CustomFrameRenderer : FrameRenderer
    {
        protected override void OnElementChanged(ElementChangedEventArgs<Frame> e)
        {
            base.OnElementChanged(e);
            if (e.NewElement != null)
            {
                var frame = e.NewElement as CustomFrame;
                //Layer.BorderColor = frame.ShadowColor.ToCGColor();
                //Layer.CornerRadius = frame.CornerRadius;
                //Layer.MasksToBounds = false;
                //Layer.ShadowOffset = new CGSize(-2, 2);
                //Layer.ShadowRadius = frame.CornerRadius;
                //Layer.ShadowOpacity = 0.4f;
                //Layer.ShadowColor = frame.ShadowColor.ToCGColor();

                Layer.ShadowColor = UIColor.Gray.CGColor;
                Layer.ShadowOffset = new CoreGraphics.CGSize(0, 2);
                Layer.ShadowOpacity = 1.0f;
                Layer.ShadowRadius = 2.5f;
                Layer.MasksToBounds = false;
            }
        }

        protected override void OnElementPropertyChanged(object sender, PropertyChangedEventArgs e)
        {
            base.OnElementPropertyChanged(sender, e);
            NativeView.LayoutIfNeeded();
        } 
    }
}