﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using FieldDriverApp.CustomRenderer;
using FieldDriverApp.iOS.CustomRenderer;
using Foundation;
using UIKit;
using Xamarin.Forms;
using Xamarin.Forms.Platform.iOS;

[assembly: ExportRenderer(typeof(BorderlessEntry), typeof(BorderlessEntryRenderer))]
namespace FieldDriverApp.iOS.CustomRenderer
{
    public class BorderlessEntryRenderer : EntryRenderer
    {
        protected override void OnElementChanged(ElementChangedEventArgs<Entry> e)
        {
            base.OnElementChanged(e);
            Control.BackgroundColor = UIColor.Clear;
            Control.Layer.BorderWidth = 0;
            //Control.TextAlignment = UITextAlignment.Center;
            //Control.Layer.CornerRadius = 5;       //this is for rounded corner
            Control.BorderStyle = UITextBorderStyle.None;
            Control.SpellCheckingType = UITextSpellCheckingType.No;             // No Spellchecking
            Control.AutocorrectionType = UITextAutocorrectionType.No;           // No Autocorrection
            Control.AutocapitalizationType = UITextAutocapitalizationType.None; // No Autocapitalization
        }
    }
}