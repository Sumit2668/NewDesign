﻿using System;
using System.Collections.Generic;
using System.Text;
 
using Xamarin.Forms;

namespace FieldDriverApp.FieldDriverTriggers
{
    public class SwitchTrigger : TriggerAction<ImageButton>
    {
        protected async override void Invoke(ImageButton button)
        {
            Xamarin.Forms.ImageButton img = (Xamarin.Forms.ImageButton)button;
            Xamarin.Forms.FileImageSource objFileImageSource = (Xamarin.Forms.FileImageSource)img.Source;
            if (objFileImageSource.File == "switchon.png")
            {
                button.Source = "switchoff.png";
            }
            else
            {
                button.Source = "switchon.png";
            }

        }
    }
}
