﻿using System;
using System.Collections.Generic;
using System.Text;
using Xamarin.Forms;

namespace FieldDriverApp.CustomControls
{
    public class LoadingImageButton : ImageButton
    {
        public static readonly BindableProperty LoadinImageSourceProperty =
            BindableProperty.Create(nameof(LoadinImageSource),
             typeof(ImageSource),
             typeof(LoadingImageButton),
             defaultBindingMode: BindingMode.TwoWay,
             propertyChanged: (bindable, oldVal, newVal) =>
             {
                 var imgbtn = (LoadingImageButton)bindable;
                
             });

        //BindableProperty.Create<LoadingImageButton, string>(p => p.LoadinImageSource, "fb.png", BindingMode.TwoWay);



        public ImageSource LoadinImageSource
        {
            get { return (ImageSource)GetValue(LoadinImageSourceProperty); }
            set
            {
                SetValue(LoadinImageSourceProperty, value);
            }
        }

    }
}
