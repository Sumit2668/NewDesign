﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace FieldDriverApp.CustomControls
{
	[XamlCompilation(XamlCompilationOptions.Compile)]
	public partial class BackArrowWithTitle : ContentView
	{ 

        public string TitleText
        {
            get { return base.GetValue(titleTextProperty).ToString(); }
            set { base.SetValue(titleTextProperty, value); }
            
        }

        private static BindableProperty titleTextProperty = BindableProperty.Create(
                                                         propertyName: "TitleText",
                                                         returnType: typeof(string),
                                                         declaringType: typeof(BackArrowWithTitle),
                                                         defaultValue: "",
                                                         defaultBindingMode: BindingMode.TwoWay,
                                                         propertyChanged: TitleTextPropertyChanged);


        private static void TitleTextPropertyChanged(BindableObject bindable, object oldValue, object newValue)
        {
            var control = (BackArrowWithTitle)bindable;
            control.title.Text = newValue.ToString(); 
        }

        public static BindableProperty ImageProperty = BindableProperty.Create(
                                                        propertyName: "Image",
                                                        returnType: typeof(string),
                                                        declaringType: typeof(BackArrowWithTitle),
                                                        defaultValue: "",
                                                        defaultBindingMode: BindingMode.TwoWay,
                                                        propertyChanged: ImageSourcePropertyChanged);

        
        public string Image
        {
            get { return base.GetValue(ImageProperty).ToString(); }
            set { base.SetValue(ImageProperty, value); }
        }

        private static void ImageSourcePropertyChanged(BindableObject bindable, object oldValue, object newValue)
        {
            var control = (BackArrowWithTitle)bindable;
            control.image.Source = ImageSource.FromFile(newValue.ToString());
        }
        
		public BackArrowWithTitle ()
		{
			InitializeComponent ();
		}

        private async void Back_Tapped(object sender, EventArgs e)
        {
            await Navigation.PopAsync();
        }
    }
}