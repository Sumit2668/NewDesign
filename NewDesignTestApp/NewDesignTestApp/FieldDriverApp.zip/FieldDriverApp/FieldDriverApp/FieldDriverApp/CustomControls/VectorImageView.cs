﻿using SkiaSharp;
using SkiaSharp.Views.Forms;
using System;
using System.Reflection;
using Xamarin.Forms;

namespace FieldDriverApp.CustomControls
{
    public class VectorImageView : SKCanvasView
    {
        private SkiaSharp.Extended.Svg.SKSvg sKSvg;
        public string Source
        {
            get { return (string)GetValue(SourceProperty); }
            set { SetValue(SourceProperty, value); }
        }

        // Using a DependencyProperty as the backing store for Source.  This enables animation, styling, binding, etc...
        public static readonly BindableProperty SourceProperty =
            BindableProperty.Create("Source", typeof(string), typeof(VectorImageView), null,
                propertyChanged: (bindableObject, oldValue, newValue) =>
                {
                    ((VectorImageView)bindableObject).ItemsSourceChanged();
                });
        public double SourceHeight
        {
            get { return (double)GetValue(SourceHeightProperty); }
            set { SetValue(SourceHeightProperty, value); }
        }

        // Using a DependencyProperty as the backing store for Source.  This enables animation, styling, binding, etc...
        public static readonly BindableProperty SourceHeightProperty =
            BindableProperty.Create("SourceHeight", typeof(double), typeof(VectorImageView), propertyChanged: (bindableObject, oldValue, newValue) =>
            {
                ((VectorImageView)bindableObject).ItemsSourceChanged();
            });
 
        public double SourceWidth
        {
            get { return (double)GetValue(SourceWidthProperty); }
            set { SetValue(SourceWidthProperty, value); }
        }

        // Using a DependencyProperty as the backing store for Source.  This enables animation, styling, binding, etc...
        public static readonly BindableProperty SourceWidthProperty =
            BindableProperty.Create("SourceWidth", typeof(double), typeof(VectorImageView),
                 propertyChanged: (bindableObject, oldValue, newValue) =>
            {
                ((VectorImageView)bindableObject).ItemsSourceChanged();
            });

        private void ItemsSourceChanged()
        {
            if (Source == null) return;
            float height =  (SourceHeight > 0) ? (float)SourceHeight : (float)HeightRequest;
            float width = (SourceWidth > 0) ? (float)SourceWidth : (float)WidthRequest;
            sKSvg = new SkiaSharp.Extended.Svg.SKSvg(new SKSize(width, height));
            var type = typeof(VectorImageView).GetTypeInfo();
            var assembly = type.Assembly;

            using (var stream = assembly.GetManifestResourceStream($"FieldDriverApp.Resources.{Source}"))
                sKSvg.Load(stream);
        }
        
        protected override void OnPaintSurface(SKPaintSurfaceEventArgs e)
        {
            if (Source == null) return;
            var surface = e.Surface;
            var canvas = surface.Canvas;

            var width = e.Info.Width;
            var height = e.Info.Height;

            // clear the surface
            canvas.Clear(SKColors.Transparent);

            // the page is not visible yet
            if (sKSvg == null)
                return;

            // calculate the scaling need to fit to screen
            float canvasMin = Math.Min(width, height);
            float svgMax = Math.Max(sKSvg.Picture.CullRect.Width, sKSvg.Picture.CullRect.Height);
            float scale = canvasMin / svgMax;
            var matrix = SKMatrix.MakeScale(1, 1);

            // draw the svg
            canvas.DrawPicture(sKSvg.Picture, ref matrix);
            base.OnPaintSurface(e);
        }
        public VectorImageView()
        {
            //sKSvg = new SkiaSharp.Extended.Svg.SKSvg(new SKSize((float)SourceWidth, (float)SourceHeight));
            this.PropertyChanged += (s, e) =>
             {
                 switch(e.PropertyName)
                 {
                     case "HeightRequest":
                         ItemsSourceChanged();
                         break;
                     case "WidthRequest":
                         ItemsSourceChanged();
                         break;
                 }
             };
        }
        protected override SizeRequest OnSizeRequest(double widthConstraint, double heightConstraint)
        {
            ItemsSourceChanged();
            return base.OnSizeRequest(widthConstraint, heightConstraint);
        }
        protected override void OnSizeAllocated(double width, double height)
        {
            if (Source == null) return;
            float h = (SourceHeight > 0) ? (float)SourceHeight : (float)height;
            float w = (SourceWidth > 0) ? (float)SourceWidth : (float)width;
            sKSvg = new SkiaSharp.Extended.Svg.SKSvg(new SKSize(w, h));
            var type = typeof(VectorImageView).GetTypeInfo();
            var assembly = type.Assembly;

            using (var stream = assembly.GetManifestResourceStream($"FieldDriverApp.Resources.{Source}"))
                sKSvg.Load(stream);
            base.OnSizeAllocated(width, height);
        }
    }
}
