﻿using FieldDriverApp.Managers.SettingsManager;
using FieldDriverApp.Providers.ApiProvider;
using System;
using System.Collections.Generic;
using System.Text;

namespace FieldDriverApp.Managers.UserManager
{
    public class UserManager : IUserManager
    {
        #region Constructor
        public UserManager(IApiProvider apiProvider, ISettingsManager settingsManager)
        {
            _apiProvider = apiProvider;
            _settingsManager = settingsManager;
        }
        #endregion

        #region Connectivity
        public bool IsConnected()
        {
            // var networkConnection = Xamarin.Forms.DependencyService.Get<Services.IMediaService>().CheckNewworkConnectivity().Result; //CrossConnectivity.Current.IsConnected;
            return true;// networkConnection;
        }
        #endregion

        #region Property
        private readonly IApiProvider _apiProvider;
        private readonly ISettingsManager _settingsManager;
        #endregion

        #region

        //private LoginResponse loginResponse { get; set; }
        //public LoginResponse LoginResponse => loginResponse;
         
        #endregion

        #region Header
        public Dictionary<string, string> GetHeaders()
        {
            //Authorization: Bearer ZEmEQtlZ8uSmAjDSTkSPiCkRPesno0GB5
            Dictionary<string, string> header = new Dictionary<string, string>();
            header.Add("Authorization", $"{"Bearer "}ZEmEQtlZ8uSmAjDSTkSPiCkRPesno0GB5");
            // header.Add("auth-secret", "Ak12mr27Xwg@d89ul");
            return header;
        }
        #endregion

        #region Api Calling
        //public async void Login(LoginRequest loginRequest, Action success, Action<BaseResponseModel> failed)
        //{
        //    bool IsNetwork = IsConnected();
        //    if (IsNetwork)
        //    {
        //        try
        //        {
        //            var url = string.Format("{0}login", _settingsManager.ApiHost);
        //            var result = await _apiProvider.Post<LoginResponse, LoginRequest>(url, loginRequest);
        //            if (result.Result.status == true)
        //            {
        //                if (success != null)
        //                {
        //                    loginResponse = result.Result;
        //                    success.Invoke();
        //                }
        //                else
        //                {
        //                    failed.Invoke(result.Result);
        //                }
        //            }
        //            else
        //            {
        //                failed.Invoke(result.Result);
        //            }
        //        }
        //        catch (Exception ex)
        //        {

        //        }
        //    }
        //    else
        //    {
        //        BaseResponseModel error = new BaseResponseModel { message = "Please check your internet connection!" };
        //        failed.Invoke(error);
        //    }
        //}
        #endregion
    }
}
