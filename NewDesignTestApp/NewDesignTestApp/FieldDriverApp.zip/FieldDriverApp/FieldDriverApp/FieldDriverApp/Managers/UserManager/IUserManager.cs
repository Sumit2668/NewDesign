﻿using System;
using System.Collections.Generic;
using System.Text;

namespace FieldDriverApp.Managers.UserManager
{
    public interface IUserManager
    {
        #region All Response
        //LoginResponse LoginResponse { get; }
        #endregion

        #region All Api
        //void Login(LoginRequest loginRequest, Action success, Action<BaseResponseModel> failed);
        #endregion
    }
}
