﻿using System;
using System.Collections.Generic;
using System.Text;

namespace FieldDriverApp.Managers.SettingsManager
{
    public interface ISettingsManager
    {
        string ApiHost { get; }
        string Token { get; }
    }
}
