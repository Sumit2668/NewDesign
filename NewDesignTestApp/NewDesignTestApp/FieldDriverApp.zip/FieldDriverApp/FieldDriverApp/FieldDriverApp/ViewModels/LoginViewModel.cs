﻿using Acr.UserDialogs;
using System;
using System.Collections.Generic;
using System.Text;
using Xamarin.Forms;

namespace FieldDriverApp.ViewModels
{
    public class LoginViewModel : BaseViewModel
    {
        public LoginViewModel()
        {
            //SigninEmail = "sumit@gmail.com";
            //Password = "1234567";
            //Device.StartTimer(TimeSpan.FromSeconds(1), () =>
            //{
            //    // this.DateTime = DateTime.Now;
            //    if (OTPCount == 0)
            //    {
            //        OTPCount--;
            //        return false;
            //    }
            //    else
            //        return true;
            //});
        }

        #region Property for Signin View
        private string signinemail { get; set; }
        public string SigninEmail
        {
            get => signinemail;
            set
            {
                signinemail = value;
                RaisePropertyChanged(() => SigninEmail);
            }
        }
        private string password { get; set; }
        public string Password
        {
            get => password;
            set
            {
                password = value;
                RaisePropertyChanged(() => Password);
            }
        }
        #endregion

        #region Property for SignUp View
        private string fullname { get; set; }
        public string Fullname
        {
            get => fullname;
            set
            {
                fullname = value;
                RaisePropertyChanged(() => Fullname);
            }
        }
        private string signupemail { get; set; }
        public string SignupEmail
        {
            get => signupemail;
            set
            {
                signupemail = value;
                RaisePropertyChanged(() => SignupEmail);
            }
        }
        private string mobile { get; set; }
        public string Mobile
        {
            get => mobile;
            set
            {
                mobile = value;
                RaisePropertyChanged(() => Mobile);
            }
        }
        private string signuppassword { get; set; }
        public string SignupPassword
        {
            get => signuppassword;
            set
            {
                signuppassword = value;
                RaisePropertyChanged(() => SignupPassword);
            }
        }
        private string signupconfpassword { get; set; }
        public string SignupConfPassword
        {
            get => signupconfpassword;
            set
            {
                signupconfpassword = value;
                RaisePropertyChanged(() => SignupConfPassword);
            }
        }
        #endregion

        #region Property for OTP Verify View
        private string otp { get; set; }
        public string OTP
        {
            get => otp;
            set
            {
                otp = value;
                RaisePropertyChanged(() => OTP);
            }
        }

        //private decimal otpcount = 60;

        //public decimal OTPCount
        //{
        //    get { return otpcount; }
        //    set
        //    {
        //        otpcount = value;
        //        RaisePropertyChanged(() => OTPCount);
        //    }
        //}

        #endregion




        #region Command Declaration for Signin View
        public Command SigninCommand => new Command(SigninCommandExecution);
        public Command NavigateSignupCommand => new Command(NavigateSignupCommandExecution);
        public Command ForgotPassCommand => new Command(ForgotPassCommandExecution);


        public Command FBCommand => new Command(fbCommandExecution);
        public Command GoogleplusCommand => new Command(googleplusCommandExecution);
        public Command TwitterCommand => new Command(twitterCommandExecution);

        #endregion

        #region Command Declaration for Signup View
        public Command SignupCommand => new Command(SignupCommandExecution);


        #endregion

        #region Command Declaration for OTP Verify View
        public Command OTPCommand => new Command(OTPCommandExecution);


        #endregion




        #region Command Execution for SigninView
        private void SigninCommandExecution(object obj)
        {
            UserDialogs.Instance.Alert("Message", "App is under cunstruction", "Ok");
        }
        private void NavigateSignupCommandExecution(object obj)
        {
            Device.BeginInvokeOnMainThread(() =>
            {
                App.Current.MainPage = new NavigationPage(new Views.RegisterView());
            });
        }
        private void ForgotPassCommandExecution(object obj)
        {
            UserDialogs.Instance.Alert("App is Under Cunstruction");
        }

        private void twitterCommandExecution(object obj)
        {
            UserDialogs.Instance.Alert("Message", "App is under cunstruction", "Ok");
        }
        private void googleplusCommandExecution(object obj)
        {
            UserDialogs.Instance.Alert("Message", "App is under cunstruction", "Ok");
        }
        private void fbCommandExecution(object obj)
        {
            UserDialogs.Instance.Alert("Message", "App is under cunstruction", "Ok");
        }
        #endregion

        #region Command Execution for SignupView
        private void SignupCommandExecution(object obj)
        {
            //UserDialogs.Instance.Alert("App is Under Cunstruction");
            Device.BeginInvokeOnMainThread(() =>
            {
                App.Current.MainPage = new NavigationPage(new Views.OTPVerification());
            });
        }
        #endregion

        #region Command Execution for OTP
        private void OTPCommandExecution(object obj)
        {
            //UserDialogs.Instance.Alert("App is Under Cunstruction");
            Device.BeginInvokeOnMainThread(() =>
            {
                App.Current.MainPage = new NavigationPage(new Views.FiledDriverTabbedPage());
            });
            //UserDialogs.Instance.HideLoading();
        }
        #endregion
    }
}
