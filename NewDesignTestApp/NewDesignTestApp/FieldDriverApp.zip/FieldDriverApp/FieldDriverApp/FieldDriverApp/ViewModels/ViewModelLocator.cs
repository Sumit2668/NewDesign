﻿using CommonServiceLocator;
using FieldDriverApp.Managers.SettingsManager;
using FieldDriverApp.Managers.UserManager;
using FieldDriverApp.Providers.ApiProvider;
using GalaSoft.MvvmLight.Ioc;

namespace FieldDriverApp.ViewModels
{
    /// <summary>
    /// This class contains static references to all the view models in the
    /// application and provides an entry point for the bindings.
    /// </summary>
    public class ViewModelLocator
    {
        /// <summary>
        /// Initializes a new instance of the ViewModelLocator class.
        /// </summary>
        public ViewModelLocator()
        {
            CommonServiceLocator.ServiceLocator.SetLocatorProvider(() => SimpleIoc.Default);

            SimpleIoc.Default.Register<ISettingsManager, SettingsManager>();
            SimpleIoc.Default.Register<IApiProvider, ApiProvider>();
            SimpleIoc.Default.Register<IUserManager, UserManager>();

            
            SimpleIoc.Default.Register<LoginViewModel>();
            
        }

        public LoginViewModel LoginViewModel => ServiceLocator.Current.GetInstance<LoginViewModel>();

        public static void Cleanup()
        {
            // TODO Clear the ViewModels
        }
    }
}
