﻿using System;
using System.Collections.Generic;
using System.Text;
using Xamarin.Forms;

namespace FieldDriverApp.ViewModels
{
    public class ClockViewModel : BaseViewModel
    {
        public ClockViewModel()
        {
            Device.StartTimer(TimeSpan.FromSeconds(1), () =>
                {
                // this.DateTime = DateTime.Now;
                if (OTPCount != 0)
                    {
                        OTPCount--;
                        return true;
                    }
                    else
                        return false;
                });
        }

        private decimal otpcount = 60;

        public decimal OTPCount
        {
            get { return otpcount; }
            set
            {
                otpcount = value;
                RaisePropertyChanged(() => OTPCount);
            }
        }

    }
}
