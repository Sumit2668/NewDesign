﻿using System.Collections.ObjectModel;

namespace FieldDriverApp.ViewModels
{
    public class EarnViewModel : BaseViewModel
    {
        private ObservableCollection<EarnPrice> earnpricelst;
        public ObservableCollection<EarnPrice> EarnPricelst
        {
            get { return earnpricelst; }
            set
            {
                earnpricelst = value;
                RaisePropertyChanged(() => EarnPricelst);
            }
        }
        public EarnViewModel()
        { 
            EarnPricelst = new ObservableCollection<EarnPrice>(earnpricelst);
        }
    }
}

public class EarnPrice
{
    public int Id { get; set; }
    public string PropertyName { get; set; }
    public string OrderNumber { get; set; }
    public string ReachedTime { get; set; }
    public string Price { get; set; }
    public string ProfitePrice { get; set; }
}