﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Text;

namespace FieldDriverApp.ViewModels
{
    public class OrderDetailViewModel : BaseViewModel
    {
        public OrderDetailViewModel()
        {
            orderdetails = new ObservableCollection<OrderDetailModel>();
            orderdetails.Add(new OrderDetailModel { Id = 1, Price = 40, Size = "20 X 2", Title = "Vegitable Plain SAndwich", IsLast = true });
            orderdetails.Add(new OrderDetailModel { Id = 2, Price = 20, Size = "10 X 2", Title = "Gulab Jamun", IsLast = true });
            orderdetails.Add(new OrderDetailModel { Id = 3, Price = 30, Size = "15 X 2", Title = "Cheese Corn Bhaji", IsLast = true });
            orderdetails.Add(new OrderDetailModel { Id = 4, Price = 30, Size = "15 X 2", Title = "Honey Chili Potato", IsLast = false });



            OrderDetail = new ObservableCollection<OrderDetailModel>(orderdetails);
        }

        private ObservableCollection<OrderDetailModel> orderdetails;
        public ObservableCollection<OrderDetailModel> OrderDetail
        {
            get { return orderdetails; }
            set
            {
                orderdetails = value;
                RaisePropertyChanged(() => OrderDetail);
            }
        }
    }
}

public class OrderDetailModel
{
    public int Id { get; set; }
    public string Title { get; set; }
    public string Size { get; set; }
    public double Price { get; set; }
    public string VegImage { get; set; } = "Veg.png";
    public bool IsLast { get; set; }

}