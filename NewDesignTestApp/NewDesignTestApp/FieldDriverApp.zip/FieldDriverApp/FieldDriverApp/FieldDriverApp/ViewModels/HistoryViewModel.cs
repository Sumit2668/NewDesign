﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Text;

namespace FieldDriverApp.ViewModels
{
    public class HistoryViewModel : BaseViewModel
    {
        public HistoryViewModel()
        {
            historymodel = new ObservableCollection<HistoryModel>();
            historymodel.Add(new HistoryModel { Id = 1, Name = "Vegitable Plain SAndwich"});
            historymodel.Add(new HistoryModel { Id = 2, Name = "Gulab Jamun"});
            historymodel.Add(new HistoryModel { Id = 3, Name = "Cheese Corn Bhaji"});
            historymodel.Add(new HistoryModel { Id = 4, Name = "Honey Chili Potato"});



            History = new ObservableCollection<HistoryModel>(historymodel);
        }
        private ObservableCollection<HistoryModel> historymodel;
        public ObservableCollection<HistoryModel> History
        {
            get { return historymodel; }
            set
            {
                historymodel = value;
                RaisePropertyChanged(() => History);
            }
        }

    }
}

public class HistoryModel
{
    public int Id { get; set; }
    public string Name { get; set; }
    public DateTime Date { get; set; }
    
}