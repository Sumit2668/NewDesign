﻿using FieldDriverApp.Managers.SettingsManager;
using FieldDriverApp.Managers.UserManager;
using GalaSoft.MvvmLight;
using GalaSoft.MvvmLight.Ioc;
using System;
using System.Collections.Generic;
using System.Text;

namespace FieldDriverApp.ViewModels
{
    public class BaseViewModel : ViewModelBase
    {
        protected readonly IUserManager userManager;
        internal readonly ISettingsManager settingsManager;
        public BaseViewModel()
        {
            userManager = SimpleIoc.Default.GetInstance<IUserManager>();
            settingsManager = SimpleIoc.Default.GetInstance<ISettingsManager>();
        }
    }
}
