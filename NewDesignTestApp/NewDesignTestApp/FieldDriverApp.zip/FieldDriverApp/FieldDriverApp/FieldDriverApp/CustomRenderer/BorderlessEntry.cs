﻿using System;
using System.Collections.Generic;
using System.Text;
using Xamarin.Forms;

namespace FieldDriverApp.CustomRenderer
{
    public class BorderlessEntry : Entry
    {
        //public static readonly BindableProperty TextSpacingProperty = BindableProperty.Create(
        //   propertyName: nameof(TextSpacing),
        //   returnType: typeof(float),
        //   declaringType: typeof(BorderlessEntry),
        //   defaultValue: 0.0f,
        //   defaultBindingMode: BindingMode.TwoWay);

        //public float TextSpacing
        //{
        //    get { return (float)GetValue(TextSpacingProperty); }
        //    set { SetValue(TextSpacingProperty, value); }
        //}
    }
}
