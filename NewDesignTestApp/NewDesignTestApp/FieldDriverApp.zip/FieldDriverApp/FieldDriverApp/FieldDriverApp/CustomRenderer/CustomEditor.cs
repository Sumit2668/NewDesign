﻿using System;
using System.Collections.Generic;
using System.Text;
using Xamarin.Forms;

namespace FieldDriverApp.CustomRenderer
{
    public class CustomEditor : Editor
    {
        public static BindableProperty HasRoundedCornerProperty
        = BindableProperty.Create(nameof(HasRoundedCorner), typeof(bool), typeof(CustomEditor), false);

        public bool HasRoundedCorner
        {
            get { return (bool)GetValue(HasRoundedCornerProperty); }
            set { SetValue(HasRoundedCornerProperty, value); }
        }

        public Color BorderColor { get; set; }
    }
}
