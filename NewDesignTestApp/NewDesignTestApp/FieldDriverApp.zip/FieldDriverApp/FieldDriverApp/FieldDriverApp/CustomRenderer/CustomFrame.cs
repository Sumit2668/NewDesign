﻿using System;
using System.Collections.Generic;
using System.Text;
using Xamarin.Forms;

namespace FieldDriverApp.CustomRenderer
{
    public class CustomFrame : Frame
    {
        public static readonly BindableProperty ShadowColorProperty =
     BindableProperty.Create(nameof(ShadowColor), typeof(Color), typeof(CustomFrame));

        public Color ShadowColor
        {
            get
            {
                return (Color)GetValue(ShadowColorProperty);
            }
            set
            {
                SetValue(ShadowColorProperty, value);
            }
        }
    }
}
