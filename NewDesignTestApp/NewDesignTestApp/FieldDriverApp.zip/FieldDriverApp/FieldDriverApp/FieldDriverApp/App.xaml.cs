﻿using CommonServiceLocator;
using FieldDriverApp.ViewModels;
using FieldDriverApp.Views;
using GalaSoft.MvvmLight.Ioc;
using System;
using Xamarin.Forms;
using Xamarin.Forms.Xaml;
using Tab = FieldDriverApp.Views.Tab;

[assembly: XamlCompilation(XamlCompilationOptions.Compile)]
namespace FieldDriverApp
{
    public partial class App : Application
    {
        #region Set App Properties
        private static ViewModelLocator locator { get; set; }
        public static ViewModelLocator Locator => locator;
        #endregion
        public App()
        {
            InitializeComponent();
            ServiceLocator.SetLocatorProvider(() => SimpleIoc.Default);
            SimpleIoc.Default.Register<ViewModelLocator>();
            locator = ServiceLocator.Current.GetInstance<ViewModelLocator>();

            //MainPage = new NavigationPage(new SignInView());
            MainPage = new OrderDetailsView();
            //MainPage = new OTPVerification();
            //MainPage = new MainPage();
            //MainPage = new FiledDriverTabbedPage();
           // MainPage = new MainPage();
        }

        protected override void OnStart()
        {
            // Handle when your app starts
        }

        protected override void OnSleep()
        {
            // Handle when your app sleeps
        }

        protected override void OnResume()
        {
            // Handle when your app resumes
        }
    }
}
