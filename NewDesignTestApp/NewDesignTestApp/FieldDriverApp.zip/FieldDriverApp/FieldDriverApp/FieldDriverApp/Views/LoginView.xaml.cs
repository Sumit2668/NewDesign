﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace FieldDriverApp.Views
{
	[XamlCompilation(XamlCompilationOptions.Compile)]
	public partial class LoginView : ContentPage
	{
		public LoginView ()
		{
			InitializeComponent ();
		}
        protected async override void OnAppearing()
        {
            base.OnAppearing();
            await Task.WhenAll(
            grdSignin.TranslateTo(0, mainGrid.Height, 200, Easing.Linear),
            grdSignup.TranslateTo(0, -grdSignin.Height - 15, 200, Easing.Linear));
        }


        private async void mainsignin_Tapped(object sender, EventArgs e)
        {
            mainsignin.FontAttributes = FontAttributes.Bold;
            mainsignup.FontAttributes = FontAttributes.None;

            await Task.WhenAll(
            mainbox.TranslateTo(0, 0, 120, Easing.SinOut),
            grdSignin.TranslateTo(0, mainGrid.Height, 500, Easing.SinOut),
            grdSignup.TranslateTo(0, -grdSignin.Height - 15, 500, Easing.SinOut),
            grdSignup.FadeTo(1, 500));
            EmptyEntry();
            //this.Title = btn.Text = "Sign In";
        }

        private async void mainsignup_Tapped(object sender, EventArgs e)
        {
            mainsignup.FontAttributes = FontAttributes.Bold;
            mainsignin.FontAttributes = FontAttributes.None;
            await Task.WhenAll(
            mainbox.TranslateTo(mainbox.Width, 0, 120, Easing.SinOut),
            grdSignin.TranslateTo(0, 0, 500, Easing.SinOut),
            grdSignup.TranslateTo(0, 0, 500, Easing.SinOut),
            grdSignup.FadeTo(0, 100));
            EmptyEntry();
            //this.Title = btn.Text = "Sign Up";
        }
        private void EmptyEntry()
        {
            //txtuser.Text = txtpass.Text = grdSignin.Text = "";
            //txtuser.Unfocus();
            //txtpass.Unfocus();
            //grdSignin.Unfocus();
        }
    }
}