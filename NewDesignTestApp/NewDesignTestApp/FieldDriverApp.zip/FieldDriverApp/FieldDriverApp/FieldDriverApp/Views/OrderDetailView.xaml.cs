﻿using FieldDriverApp.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace FieldDriverApp.Views
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class OrderDetailView : ContentPage
    {
        public IList<OrderDetail> OrderDetails { get; private set; }
        public OrderDetailView()
        {
            InitializeComponent();

            OrderDetails = new List<OrderDetail> {
                new OrderDetail { ItemName = "Alex Silveira", Price=20,Quantity=2 ,TotalPrice=40 },
                new OrderDetail { ItemName = "Wilson Martin",  Price=20,Quantity=2 ,TotalPrice=40 },
                new OrderDetail { ItemName = "Osmar Moss",  Price=20,Quantity=2 ,TotalPrice=40 },
                new OrderDetail { ItemName = "Yasmim Dudley", Price=20,Quantity=2 ,TotalPrice=40 },
                new OrderDetail { ItemName = "Yoshio Anthony", Price=20,Quantity=2 ,TotalPrice=40 },

                new OrderDetail { ItemName = "Alex Silveira", Price=20,Quantity=2 ,TotalPrice=40 },
                new OrderDetail { ItemName = "Wilson Martin",  Price=20,Quantity=2 ,TotalPrice=40 },
                new OrderDetail { ItemName = "Osmar Moss",  Price=20,Quantity=2 ,TotalPrice=40 },
                new OrderDetail { ItemName = "Yasmim Dudley", Price=20,Quantity=2 ,TotalPrice=40 },
                new OrderDetail { ItemName = "Yoshio Anthony", Price=20,Quantity=2 ,TotalPrice=40 },
            };

            lstOrderDetails.ItemsSource = OrderDetails;


        }
    }
}