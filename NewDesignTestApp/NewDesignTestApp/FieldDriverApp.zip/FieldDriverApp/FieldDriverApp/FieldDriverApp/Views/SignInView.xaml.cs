﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace FieldDriverApp.Views
{
	[XamlCompilation(XamlCompilationOptions.Compile)]
	public partial class SignInView : ContentPage
	{
		public SignInView ()
		{
			InitializeComponent ();
		}

        private void Signupbtn_Clicked(object sender, EventArgs e)
        {
            Navigation.PushAsync(new RegisterView());
        }
    }
}