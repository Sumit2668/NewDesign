﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace FieldDriverApp.Views
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class AccountView : ContentPage
    {
        public AccountView()
        {
            InitializeComponent();
        }

        private async void Button_Clicked(object sender, EventArgs e)
        {
            var sss = (Button)sender;
            if (sss.Text == "Support")
            {
                frmAccount.IsVisible = false;
                frmProfile.IsVisible = false;
                frmSupport.IsVisible = true;

                tabIndicator.IsVisible = false;
                tabIndicator1.IsVisible = false;
                tabIndicator2.IsVisible = true;
            }
            else if (sss.Text == "Account")
            {
                frmAccount.IsVisible = true;
                frmProfile.IsVisible = false;
                frmSupport.IsVisible = false;

                tabIndicator.IsVisible = false;
                tabIndicator1.IsVisible = true;
                tabIndicator2.IsVisible = false;
            }
            else
            {
                frmAccount.IsVisible = false;
                frmProfile.IsVisible = true;
                frmSupport.IsVisible = false;

                tabIndicator.IsVisible = true;
                tabIndicator1.IsVisible = false;
                tabIndicator2.IsVisible = false;
            }

        }

        private void Updatebtn_Clicked(object sender, EventArgs e)
        {
            Navigation.PushAsync(new EarnView());
        }
    }
}