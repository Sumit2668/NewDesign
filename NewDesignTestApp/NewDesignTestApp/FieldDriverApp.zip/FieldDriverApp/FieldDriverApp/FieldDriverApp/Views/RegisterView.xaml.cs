﻿using System;

using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace FieldDriverApp.Views
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class RegisterView : ContentPage
    {
        public RegisterView()
        {
            InitializeComponent();
        }

        private void Signinbtn_Clicked(object sender, EventArgs e)
        {
            Navigation.PushAsync(new OTPVerification());
        }
    }
}