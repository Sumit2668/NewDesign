﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Xamarin.Forms;
using Xamarin.Forms.PlatformConfiguration.AndroidSpecific;
using Xamarin.Forms.Xaml;

namespace FieldDriverApp.Views
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class FiledDriverTabbedPage : Xamarin.Forms.TabbedPage
    {
        public FiledDriverTabbedPage ()
        {
            InitializeComponent();
            //On<Xamarin.Forms.PlatformConfiguration.Android>().SetToolbarPlacement(ToolbarPlacement.Bottom);
            //BarBackgroundColor = Color.Red;
            //BarTextColor = Color.Yellow;
            //SelectedTabColor = Color.Blue;
            //UnselectedTabColor = Color.Yellow;

        }
    }
}