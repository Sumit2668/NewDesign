﻿using System;
using System.Collections.Generic;
using System.Text;
using Xamarin.Forms;
using Xamarin.Forms.PlatformConfiguration.AndroidSpecific;

namespace FieldDriverApp.Views
{
    public partial class Tab : Xamarin.Forms.TabbedPage
    {
        public Tab()
        {
            
            var tab = new Xamarin.Forms.TabbedPage();
            tab.Children.Add(new NavigationPage(new ContentPage() { Content = new Label { Text = "One" } }) { Title = "Tab 1" });
            tab.Children.Add(new NavigationPage(new ContentPage() { Content = new Label { Text = "Two" } }) { Title = "Tab 2" });
            tab.Children.Add(new NavigationPage(new ContentPage() { Content = new Label { Text = "Three" } }) { Title = "Tab 3" });



            this.Children.Add(new NavigationPage(new ContentPage()  {  Content = new Label { Text = "One" }, }) { Title = "Tab 1" });
            this.Children.Add(new NavigationPage(new ContentPage() { Content = new Label { Text = "Two" } }) { Title = "Tab 2" });
            this.Children.Add(new NavigationPage(new ContentPage() { Content = new Label { Text = "Three" } }) { Title = "Tab 3" });
            this.Children.Add(new NavigationPage(tab) { Title = "Tab 4" });
            On<Xamarin.Forms.PlatformConfiguration.Android>().SetToolbarPlacement(ToolbarPlacement.Bottom);
            this.BarBackgroundColor = Color.Green;
            this.BarTextColor = Color.White;
            this.SelectedTabColor = Color.Red;
            this.UnselectedTabColor = Color.Blue;
            
            NavigationPage.SetHasNavigationBar(this, false);
        }
    }
}
