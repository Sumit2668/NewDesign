﻿using System;
using System.Collections.Generic;
using System.Text;

namespace FieldDriverApp.Models
{
    public class OrderDetail
    {
        public string ItemName { get; set; }
        public int Quantity{ get; set; }
        public decimal Price { get; set; }
        public decimal TotalPrice { get; set; } 
    }

    public class Order
    {
        public string OrderItems { get; set; }
        public string Price { get; set; }
        public DateTime? Time{ get; set; }
        public decimal Distance { get; set; }
        public List<OrderDetail> OrderDetails { get; set; }

    }
}
