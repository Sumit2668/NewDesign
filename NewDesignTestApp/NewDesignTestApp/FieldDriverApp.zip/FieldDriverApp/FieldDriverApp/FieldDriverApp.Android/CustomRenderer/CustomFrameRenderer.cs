﻿using Xamarin.Forms.Platform.Android;
using Xamarin.Forms;
using Android.Content;
using Android.Graphics;
using FieldDriverApp.CustomRenderer;
using FieldDriverApp.Droid.CustomRenderer;
using Android.Views;

[assembly: ExportRenderer(typeof(CustomFrame), typeof(CustomFrameRenderer))]
namespace FieldDriverApp.Droid.CustomRenderer
{
    public class CustomFrameRenderer : Xamarin.Forms.Platform.Android.AppCompat.FrameRenderer//: FrameRenderer
    {
        public CustomFrameRenderer(Context context) : base(context)
        {

        }
        protected override void OnElementChanged(ElementChangedEventArgs<Frame> e)
        {
            base.OnElementChanged(e);
            if (e.NewElement != null)
            {
                var frame = e.NewElement as CustomFrame;
                // this.SetBackgroundResource(Resource.Drawable.FrameShape);
                SetBackgroundResource(Resource.Drawable.shadow);
                //GradientDrawable drawable = (GradientDrawable)this.Background;
                //drawable.SetCornerRadii(new float[] { frame.CornerRadius, frame.CornerRadius, frame.CornerRadius, frame.CornerRadius, frame.CornerRadius, frame.CornerRadius, frame.CornerRadius, frame.CornerRadius });
                //this.Elevation = frame.HasShadow ? 10 : 0;
                //drawable.SetStroke(2, Android.Graphics.Color.ParseColor("#00FFFF"), 5, 6); 


            }
        }
        protected override void OnDraw(Canvas canvas)
        {
            base.OnDraw(canvas);
        }
    }
}