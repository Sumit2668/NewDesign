﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;

using Android.App;
using Android.Content;
using Android.Graphics.Drawables;
using Android.OS;
using Android.Runtime;
using Android.Support.Design.Widget;
using Android.Views;
using Android.Widget;
using Xamarin.Forms;
using Xamarin.Forms.Platform.Android;
using Xamarin.Forms.Platform.Android.AppCompat;
using XamarinShellApp.Controls;
using XamarinShellApp.Droid.AndroidRenderer;

[assembly: ExportRenderer(typeof(CustomTabbedPage), typeof(CustomTabbedPageRenderer))]
namespace XamarinShellApp.Droid.AndroidRenderer
{
    public static class Extensions
    {
        public static List<Android.Views.View> GetViewsByType(this Android.Views.View view, Type viewType = null)
        {
            if (!(view is ViewGroup group))
                return new List<Android.Views.View>();

            var result = new List<Android.Views.View>();

            for (int i = 0; i < group.ChildCount; i++)
            {
                var child = group.GetChildAt(i);
                result.AddRange(child.GetViewsByType(viewType));

                if (viewType == null || child.GetType() == viewType)
                    result.Add(child);
            }

            return result.Distinct().ToList();
        }

        public static void FindAndRemoveById(this Android.Views.View view, int id)
        {
            var childView = view.FindViewById(id);
            ((ViewGroup)childView.Parent).RemoveView(childView);
        }
    }

    public class CustomTabbedPageRenderer : TabbedPageRenderer, TabLayout.IOnTabSelectedListener
    {
        public CustomTabbedPageRenderer(Context context) : base(context)
        {
        }
        

        protected override void OnElementPropertyChanged(object sender, PropertyChangedEventArgs e)
        {
            base.OnElementPropertyChanged(sender, e);

            if (e.PropertyName.Equals(CustomTabbedPage.IsHiddenProperty.PropertyName) && Element is CustomTabbedPage customTabbed)
            {
                var views = ViewGroup.GetViewsByType(typeof(BottomNavigationView));
                
                if (views != null && views.Any())
                {
                    var bottomView = views.FirstOrDefault() as BottomNavigationView;
                    //var bottomView2 = views.FirstOrDefault() as BottomNavigationView;
                    //var tnavigation = FindViewById(Resource.Id.navigation) as BottomNavigationView;
                    //bottomView.Visibility = customTabbed.IsHidden ? ViewStates.Invisible : ViewStates.Visible;
                    //bottomView.TranslationY = customTabbed.IsHidden ? bottomView.TranslationY + bottomView.Height : bottomView.TranslationY - bottomView.Height;

                    //TODO: Glenn - Hmm hiding bottom tabbar leaves empty space in Android
                    if (customTabbed.IsHidden)
                    {
                        //bottomView.Animate().TranslationY(bottomView.Height);
                        bottomView.Visibility = ViewStates.Gone;
                        //navigation.Animate().TranslationY(0);
                        //bottomView.SetBackgroundColor(customTabbed.BackGroundcolor.ToAndroid());
                    }
                    else
                    {
                        //navigation.Animate().TranslationY(bottomView.Height);
                        //bottomView.Animate().TranslationY(0);
                        bottomView.Visibility = ViewStates.Visible;
                        //bottomView.SetBackgroundColor(customTabbed.BackGroundcolor.ToAndroid());
                        //TODO: Glenn - check : https://github.com/xamarin/Xamarin.Forms/issues/4222
                        //var parameters = bottomView.LayoutParameters;
                        //parameters.Height = 0;
                        //bottomView.LayoutParameters = parameters;
                    }
                }
            }
        }
    }
}