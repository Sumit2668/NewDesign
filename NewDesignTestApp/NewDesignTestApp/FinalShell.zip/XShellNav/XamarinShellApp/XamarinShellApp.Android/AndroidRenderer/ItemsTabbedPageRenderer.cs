﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Support.Design.Widget;
using Android.Views;
using Android.Widget;
using Xamarin.Forms;
using Xamarin.Forms.Platform.Android;
using Xamarin.Forms.Platform.Android.AppCompat;
using XamarinShellApp.Droid.AndroidRenderer;
using XamarinShellApp.Views;

[assembly: ExportRenderer(typeof(ItemsTabbedPage), typeof(ItemsTabbedPageRenderer))]
namespace XamarinShellApp.Droid.AndroidRenderer
{
   public class ItemsTabbedPageRenderer : TabbedPageRenderer, TabLayout.IOnTabSelectedListener
    {
        ItemsTabbedPage _page;

        public ItemsTabbedPageRenderer(Context context) : base(context) { }

        protected override void OnElementChanged(ElementChangedEventArgs<TabbedPage> e)
        {
            base.OnElementChanged(e);

            if (e.NewElement != null)
                _page = e.NewElement as ItemsTabbedPage;
            else
                _page = e.OldElement as ItemsTabbedPage;
        }

        void TabLayout.IOnTabSelectedListener.OnTabReselected(TabLayout.Tab tab)
        {
            System.Diagnostics.Debug.WriteLine("Tab Reselected");
            //Handle Tab Reselected
        }
    }
}