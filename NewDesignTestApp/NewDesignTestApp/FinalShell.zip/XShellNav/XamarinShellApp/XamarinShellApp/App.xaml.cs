﻿using System;
using Xamarin.Forms;
using Xamarin.Forms.Xaml;
using XamarinShellApp.Views;

[assembly: XamlCompilation(XamlCompilationOptions.Compile)]
namespace XamarinShellApp
{
    public partial class App : Application
    {
        public App()
        {
            InitializeComponent();

            //var navPage = new TabbedPage();
            //navPage.Children.Add(new NavigationPage(new ContentPage()
            //{
            //    Title = "Tab1",
            //    Content = new Label
            //    {
            //        Text = "Tab 1",
            //        HorizontalOptions = LayoutOptions.Center,
            //        VerticalOptions = LayoutOptions.Center
            //    }
            //})
            //{ Title = "Tab1", BarTextColor = Color.Black });
            //navPage.Children.Add(new NavigationPage(new ContentPage()
            //{
            //    Title = "Tab2",
            //    Content = new Label
            //    {
            //        Text = "Tab 2",
            //        HorizontalOptions = LayoutOptions.Center,
            //        VerticalOptions = LayoutOptions.Center
            //    }
            //})
            //{ Padding = new Thickness(0, 20, 0, 0), Title = "Tab2", BarTextColor = Color.Black });

            //var menuPage = new MasterDetailPage()
            //{
            //    Title = "Menu",
            //};
            //string[] features = { "Connections", "Settings" };
            //ListView listView = new ListView
            //{
            //    ItemsSource = features
            //};
            //menuPage.Master = new ContentPage()
            //{
            //    Padding = new Thickness(0, 20, 0, 0),
            //    Title = "Options",
            //    Content = listView,
            //    BackgroundColor = Color.FromHex("333333"),
            //    Icon = "menu.png",
            //};

            //ContentPage gotoPage = null;
            //listView.ItemTapped += (sender, e) =>
            //{
            //    switch (e.Item.ToString())
            //    {
            //        case "Connections":
            //            gotoPage = new ContentPage() { Padding = new Thickness(0, 20, 0, 0), Content = new Label() { Text = "Connections" } };
            //            break;
            //        case "Settings":
            //            gotoPage = new ContentPage() { Padding = new Thickness(0, 20, 0, 0), Content = new Label() { Text = "Connections" } };
            //            break;
            //    }
            //    menuPage.Detail = gotoPage;
            //    ((ListView)sender).SelectedItem = null;
            //    menuPage.IsPresented = false;
            //};

            //menuPage.Detail = navPage;
            //MainPage =new TabbedPage1();
            MainPage = new AppShell();
        }

        protected override void OnStart()
        {
            // Handle when your app starts
        }

        protected override void OnSleep()
        {
            // Handle when your app sleeps
        }

        protected override void OnResume()
        {
            // Handle when your app resumes
        }
    }
}
