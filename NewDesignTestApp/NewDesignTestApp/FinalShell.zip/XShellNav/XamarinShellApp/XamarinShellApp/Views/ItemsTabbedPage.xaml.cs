﻿using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Xamarin.Forms;
using Xamarin.Forms.Xaml;
using XamarinShellApp.Controls;

namespace XamarinShellApp.Views
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class ItemsTabbedPage : TabbedPage
    {

        //public static NavigationPage DetailPage;
        //public static NavigationPage DetailPage1;
        //public static NavigationPage DetailPage2;
        //public static NavigationPage DetailPage3;

        //https://stackoverflow.com/questions/45250485/how-can-i-detect-the-clicking-of-a-tab-button-in-xamarin-forms/45315321

        public ItemsTabbedPage()
        {
            InitializeComponent();

            //DetailPage = new NavigationPage(new Views.DetailPage());
            //DetailPage1 = new NavigationPage(new Views.DetailPage1());
            //DetailPage2 = new NavigationPage(new Views.DetailPage2());
            //DetailPage3 = new NavigationPage(new Views.DetailPage3());


            //AddContents();
            this.CurrentPageChanged += (s, e) =>
            {

                if (CurrentPage != null)
                {
                    if (CurrentPage.Title == "Test")
                    {
                        Device.BeginInvokeOnMainThread(() =>
                        {
                            var ct = Children.Count;

                            while (Children.Count > 1)
                            {
                                this.Children.RemoveAt(0);
                            }
                            this.Children.Insert(0, new Review() { Title = "Review", IconImageSource = "menu.png" });
                            var ss = this.Children.LastOrDefault();
                            ss.Title = "";
                            ss.IconImageSource = "";
                            this.CurrentPage = ss;
                        });
                    }

                    FileImageSource source = (FileImageSource)(this.Children[0].IconImageSource);
                    if (source == null) return;
                    if (source.File == "menu.png")
                    {
                        while (Children.Count > 1)
                        {
                            this.Children.RemoveAt(0);
                        }
                        this.Children.Add(new DetailPage()

                        { Title = "Tab1", IconImageSource = "itemdetail.png" });
                        this.Children.RemoveAt(0);
                        this.Children.Add(new DetailPage1()

                        { Title = "Tab2", IconImageSource = "items.png" });
                        this.Children.Add(new DetailPage2()

                        { Title = "Tab3", IconImageSource = "items.png" });
                        this.Children.Add(new DetailPage3()

                        { Title = "Tab4", IconImageSource = "items.png" });

                        this.Children.Insert(4, new Review() { Title = "Test", IconImageSource = "menu.png" });
                    }
                }
                else
                {
                    this.Children.Add(new Review()

                    { Title = "Review", IconImageSource = "menu.png" });

                }
            };
        }

        private void AddContents()
        {
            this.Children.Add(new NavigationPage(new DetailPage()
            {
                Title = "Tab1",
                Content = new Label
                {
                    Text = "Tab 1",
                    HorizontalOptions = LayoutOptions.Center,
                    VerticalOptions = LayoutOptions.Center
                }
            })
            { Title = "Tab1", IconImageSource = "itemdetail.png" });
            this.Children.Add(new NavigationPage(new DetailPage1()
            {
                Title = "Tab2",
                Content = new Label
                {
                    Text = "Tab 2",
                    HorizontalOptions = LayoutOptions.Center,
                    VerticalOptions = LayoutOptions.Center
                }
            })
            { Title = "Tab2", IconImageSource = "items.png" });
            this.Children.Add(new NavigationPage(new DetailPage2()
            {
                Title = "Tab 3",
                Content = new Label
                {
                    Text = "Tab 3",
                    HorizontalOptions = LayoutOptions.Center,
                    VerticalOptions = LayoutOptions.Center
                }
            })
            { Title = "Tab3", IconImageSource = "items.png" });
            this.Children.Add(new NavigationPage(new DetailPage3()
            {
                Title = "Tab4",
                Content = new Label
                {
                    Text = "Tab 4",
                    HorizontalOptions = LayoutOptions.Center,
                    VerticalOptions = LayoutOptions.Center
                }
            })
            { Title = "Tab4", IconImageSource = "items.png" });
            this.Children.Insert(4, new Review() { Title = "Test", IconImageSource = "cat.png" });
        }
    }
}