﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace XamarinShellApp.Views
{
	[XamlCompilation(XamlCompilationOptions.Compile)]
	public partial class DetailPage3 : ContentPage
	{
		public DetailPage3 ()
		{
			InitializeComponent ();
		}
        private void Menu_Tapped(object sender, EventArgs e)
        {
            App.Current.MainPage = new AppShell();

        }
    }
}